package testscript;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Test;

public class ResultRetrunList {
	@Test
	public void getText() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		LinkedList<String> Exmp = exin.BowlerList();

		for (int i = 0; i < Exmp.size(); i++) {

			String Bowler = Exmp.get(i).toString();
			System.out.println(Bowler);
		}

	}
}
