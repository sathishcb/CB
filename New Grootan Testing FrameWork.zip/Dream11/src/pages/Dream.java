package pages;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import testscript.PlayerExcelList;

public class Dream extends BasePOMpage {

	@AndroidFindBy(xpath = "//*[@text='REGISTER'")
	public WebElement register;

	@AndroidFindBy(xpath = "//*[@text='Mobile no.']")
	public WebElement mobile;

	@AndroidFindBy(xpath = "//*[@text='Email']")
	public WebElement email;

	@AndroidFindBy(xpath = "//*[@text='Password']")
	public WebElement password;

	@AndroidFindBy(xpath = "(//*[@class='android.widget.ListView']/*/*/*[@class='android.widget.LinearLayout' and ./*[@text]])[1]")
	public WebElement index1;

	@AndroidFindBy(xpath = "(//*[@class='androidx.recyclerview.widget.RecyclerView']/*[./*[./*[@id='view']]])")
	public List<WebElement> matchList;

	@AndroidFindBy(xpath = "//*[@id='content' and @class='android.widget.RelativeLayout']")
	public WebElement otp;

	@AndroidFindBy(xpath = "(//*[@class='android.widget.RelativeLayout' and ./parent::*[@id='com.app.dream11Pro:id/']]/*[@class='android.widget.Button'])[2]")
	public WebElement letsplay;

	@AndroidFindBy(xpath = "//*[@text='Cricket']")
	public WebElement cricket;

	@AndroidFindBy(xpath = "//*[@text='Log In']")
	public WebElement login;

	@AndroidFindBy(xpath = "//*[@text='Email or mobile no']")
	public WebElement title;

	@AndroidFindBy(xpath = "//*[@text='CREATE TEAM']")
	public WebElement createTeam;

	// tv_report_wrong_info
	@AndroidFindBy(xpath = "//*[@text='Email or mobile no']")
	public WebElement loginDetails;
	@AndroidFindBy(xpath = "//*[@text='WK']")
	public WebElement wK;
	@AndroidFindBy(xpath = "(//*[@class='androidx.recyclerview.widget.RecyclerView']/*[./*[@class='android.widget.ImageView'] and ./*[@class='android.view.View']])")
	public List<WebElement> playerList;
	@AndroidFindBy(xpath = "//*[@text='BAT']")
	public WebElement bat;

	@AndroidFindBy(xpath = "//*[@text='AR']")
	public WebElement alr;

	@AndroidFindBy(xpath = "//*[@text='BOWL']")
	public WebElement bol;

	@AndroidFindBy(xpath = "//*[@text='TEAM PREVIEW']")
	public WebElement perviewteam;
	@AndroidFindBy(xpath = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[2]//*[@class='android.view.ViewGroup']")
	public List<WebElement> teambatList;
	@AndroidFindBy(xpath = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[3]//*[@class='android.view.ViewGroup']")
	public List<WebElement> teamAlrList;

	@AndroidFindBy(xpath = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.RelativeLayout']]/*[@id='com.app.dream11Pro:id/' and @class='android.widget.ImageView'])[3]")
	public WebElement closePreview;
	@AndroidFindBy(xpath = "//*[@text='CONTINUE']")
	public WebElement contu;

	@AndroidFindBy(xpath = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[1]")
	public List<WebElement> teamkeeperList;
	@AndroidFindBy(xpath = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[4]//*[@class='android.view.ViewGroup']")
	public List<WebElement> teambowlerList;

	@AndroidFindBy(xpath = "((//*[@class='androidx.recyclerview.widget.RecyclerView']/*[@class='android.view.ViewGroup']))")
	public List<WebElement> caps;

	@AndroidFindBy(xpath = "//*[@text='Entry Fee']")
	public WebElement fee;
	@AndroidFindBy(xpath = "//*[@text='SAVE TEAM']")
	public WebElement save;
	@AndroidFindBy(xpath = "//*[@text='ENTRY']")
	public WebElement entry;
	@AndroidFindBy(xpath = "(//*[@class='androidx.recyclerview.widget.RecyclerView']/*/*/*/*/*[@id='com.app.dream11Pro:id/' and @class='android.widget.LinearLayout' and ./*[@id='com.app.dream11Pro:id/' and ./*[./*[@text]]] and ./*[./*[./*[@class='android.widget.FrameLayout']]]])[1]//*[@text='JOIN']")
	public WebElement join;

	public Dream(AppiumDriver<MobileElement> driver) {
		super(driver);
	}

	@AndroidFindBy(xpath = "//*[@text='JOIN']")
	public WebElement teamjoin;

	WebDriverWait wait = new WebDriverWait(driver, 5);

	public void teamJoin() {
		wait.until(ExpectedConditions.visibilityOf(teamjoin));
		teamjoin.click();
		System.out.println("Click Team Join Button");
	}

	public void saveClick() {
		wait.until(ExpectedConditions.visibilityOf(save));
		save.click();
		System.out.println("Click Save Button");
	}

	public void entryFilterClick() {
		wait.until(ExpectedConditions.visibilityOf(entry));
		entry.click();
		System.out.println("Click Entry Filter Button");
	}

	public void firstJoinClick() {
		wait.until(ExpectedConditions.visibilityOf(join));
		join.click();
		System.out.println("Click Join Button");
	}

	public void entryFeeClick() {
		wait.until(ExpectedConditions.visibilityOf(fee));
		fee.click();
		System.out.println("Click Save Button");
	}

	public void registerClick() {
		wait.until(ExpectedConditions.visibilityOf(register));
		register.click();
		System.out.println("Click Register Button");
	}

	public void mobileNo(String MobileNo) {
		wait.until(ExpectedConditions.visibilityOf(mobile));
		mobile.click();
		driver.getKeyboard().sendKeys(MobileNo);
		System.out.println("Enter Mobile No");
	}

	public void email(String Email) {
		email.click();
		driver.getKeyboard().sendKeys(Email);
		System.out.println("Enter Email");
	}

	public void password(String Password) {

		password.click();
		driver.getKeyboard().sendKeys(Password);
		System.out.println("Enter Password");
	}

	public void clickContinue() {
		wait.until(ExpectedConditions.visibilityOf(contu));
		contu.click();
		System.out.println("Click Continue");
	}

	public void selectTeam(int team) {
		wait.until(ExpectedConditions.visibilityOfAllElements(teamjoin));
		String tt = "(//*[@class='androidx.recyclerview.widget.RecyclerView']/*/*[@id='com.app.dream11Pro:id/' and @class='android.widget.ImageView' and (./preceding-sibling::* | ./following-sibling::*)[@class='android.widget.FrameLayout']])";
		driver.findElement(By.xpath(tt + "[" + team + "]")).click();

	}

	public void screenshot(String Sh) throws IOException, InterruptedException {
		try{
		File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Thread.sleep(2000);
		// String file = System.getProperty("user.dir")+"\\Dream 11 Test
		// Data.xlsx";4
		FileUtils.copyFile(file, new File(("user.dir") + "\\Dream11\\" + Sh + ".jpg"));
		}
		catch(Exception ed){
			
		}
		

	}

	public void matchList(String MatchType, String Team1, String Team2) {
		wait.until(ExpectedConditions.visibilityOfAllElements(matchList));
		String status = null;
		for (int i = 1; i <= 30; i++) {
			// driver.executeScript("seetest:client.swipe(\"Down\", 650, 20)");
			String mm = "(//*[@class='androidx.recyclerview.widget.RecyclerView']/*[./*[./*[@id='view']]])";
			String rem = "//*[@class='android.view.ViewGroup']//*[@class='android.widget.TextView']";
			List<MobileElement> matchList = driver.findElements(By.xpath(mm));
			for (int k = 1; k <= matchList.size(); i++) {
				WebElement r = driver.findElement(By.xpath(mm + "[" + i + "]" + rem + "[1]"));
				String Result = r.getText().trim();

				WebElement r2 = driver.findElement(By.xpath(mm + "[" + i + "]" + rem + "[2]"));
				String Result1 = r2.getText().trim();
				String Result2 = driver.findElement(By.xpath(mm + "[" + i + "]" + rem + "[3]")).getText().trim();
				if (Result.contains(MatchType)) {
					if (Result1.contains(Team1)) {
						if (Result2.contains(Team2)) {
							r2.click();
							status = "pass";
						}
					}

				}
				if (status != null) {
					driver.executeScript("seetest:client.swipe(\"Down\", 100, 100)");
				} else {

				}
				if (status == "pass") {
					break;
				}

			}
			if (status != null) {
				driver.executeScript("seetest:client.swipe(\"Down\", 100, 100)");
			} else {

			}
			if (status == "pass") {
				break;
			}

		}
		System.out.println("Select Match In List");
	}

	public void playerList(String MatchType, String Team1, String Team2) {

	}

	public void autoOtp() {
		otp.click();
		System.out.println("Auto OTP");
	}

	public void letsPlay() {
		letsplay.click();
		System.out.println("Click Let's Play");
	}

	public void cricket() {
		cricket.click();
		System.out.println("Click Cricket");
	}

	public void clickLogin() {
		login.click();
		System.out.println("Click Login");
	}

	public void clickCreateTeam() {
		createTeam.click();
		System.out.println("Click Create Team");
	}

	public void clickTeamPreview() {
		perviewteam.click();
		System.out.println("Click Team Preview");
	}

	public void closeTeamPreview() {
		closePreview.click();
		System.out.println("Click Team Preview");
	}

	public void selectWicketKeeper() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		wK.click();
		String wx = "(//*[@class='androidx.recyclerview.widget.RecyclerView']/*[./*[@class='android.widget.ImageView'] and ./*[@class='android.view.View']])";
		String wx2 = "//*[@class='android.widget.TextView'][1]";
		LinkedList<String> Exmp = exin.WicketKeeprList();
		String status = null;
		for (int i = 0; i < Exmp.size(); i++) {
			status = null;
			System.out.println(Exmp.size());
			String Player = Exmp.get(i).toString().replace(".", "");
			System.out.println(Player);
			for (int k = 1; k <= 3; i++) {

				for (int t = 1; t <= playerList.size(); t++) {
					WebElement Pname = driver.findElement(By.xpath(wx + "[" + t + "]" + wx2));
					String Result = Pname.getText().trim();
					if (Result.contains(Player.trim())) {
						Pname.click();
						status = "pass";
						break;
					}
				}
				if (status != "pass") {
					driver.executeScript("seetest:client.swipe(\"Down\", 100, 100)");
				} else {

				}
				if (status == "pass") {
					break;
				}
			}
			if (status == "pass") {
				break;
			}
		}
		System.out.println("Select Wicket Keeper");
	}

	public void selectBatsMan() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		bat.click();
		String wx = "((//*[@class='androidx.recyclerview.widget.RecyclerView']/*[@class='android.view.ViewGroup'])";
		String wx2 = "/*[@text and @id='com.app.dream11Pro:id/'])[1]";
		LinkedList<String> Exmp = exin.BatsmenList();
		String status = null;
		for (int i = 0; i < Exmp.size(); i++) {
			status = null;
			System.out.println(Exmp.size());
			String Player = Exmp.get(i).toString().replace(".", "");
			System.out.println(Player);
			for (int k = 1; k <= 3; k++) {

				for (int t = 1; t <= playerList.size(); t++) {
					WebElement Pname = driver.findElement(By.xpath(wx + "[" + t + "]" + wx2));
					String Result = Pname.getText().trim();
					System.out.println(Result);
					System.out.println(playerList.size());
					if (Result.contains(Player)) {
						driver.findElement(By.xpath(wx + "[" + t + "]" + wx2)).click();
						status = "pass";
						break;
					}
				}
				if (status != "pass") {
					driver.executeScript("seetest:client.swipe(\"Down\", 600, 10)");
				} else {

				}
				if (status == "pass") {
					break;
				}
			}
			if (i == Exmp.size()) {
				break;
			}
		}
		System.out.println("Select Batsman");
	}

	public void selectCaptains(String cap) throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String sm = "((//*[@class='androidx.recyclerview.widget.RecyclerView']/*[@class='android.view.ViewGroup'])";
		String rm = "/*[@text and @id='com.app.dream11Pro:id/'])[2]";

		switch (cap) {
		case "cap":
			LinkedList<String> Exmp = exin.CaptainList();
			for (int i = 0; i < Exmp.size(); i++) {
				String Player = Exmp.get(i).toString().replace(".", "");
				for (int t = 1; t < caps.size(); t++) {
					WebElement gt = driver.findElement(By.xpath(sm + "[" + t + "]" + rm));
					String screenpPlayer = gt.getText();
					try {
						Assert.assertEquals(screenpPlayer, Player);
						driver.findElement(By.xpath(sm + "[" + t + "])//*[@text='C']")).click();
						break;
					} catch (AssertionError ex) {

					}

				}
				
			}
			System.out.println("Select Captain");
			break;
		case "vcap":
			LinkedList<String> Exmp1 = exin.VCaptainList();

			for (int i = 0; i < Exmp1.size(); i++) {
				String Player = Exmp1.get(i).toString().replace(".", "");
				for (int t = 1; t <= caps.size(); t++) {
					WebElement gt = driver.findElement(By.xpath(sm + "[" + t + "]" + rm));
					String screenpPlayer = gt.getText();
					System.out.println(Player);
					System.out.println(screenpPlayer);
					try {
						Assert.assertEquals(screenpPlayer, Player);
						driver.findElement(By.xpath(sm + "[" + t + "])//*[@text='VC']")).click();

						break;
					} catch (AssertionError ex) {

					}

				}

			}
			System.out.println("Select Captain");
			break;
		}

	}

	public void selectAllRounder() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		alr.click();
		String wx = "(//*[@class='androidx.recyclerview.widget.RecyclerView']/*[./*[@class='android.widget.ImageView'] and ./*[@class='android.view.View']])";
		String wx2 = "//*[@class='android.widget.TextView'][1]";
		LinkedList<String> Exmp = exin.AllrounderList();
		String status;
		for (int i = 0; i < Exmp.size(); i++) {
			status = null;
			String Player = Exmp.get(i).toString().replace(".", "");
			System.out.println(Player);
			for (int k = 1; k <= 3; i++) {

				for (int t = 1; t <= playerList.size(); t++) {
					WebElement Pname = driver.findElement(By.xpath(wx + "[" + t + "]" + wx2));
					String Result = Pname.getText().trim();
					System.out.println(Result);
					System.out.println(Player);
					if (Result.contains(Player)) {
						Pname.click();
						status = "pass";
						break;
					}
				}
				if (status != "pass") {
					driver.executeScript("seetest:client.swipe(\"Down\", 100, 100)");
				} else {

				}
				if (status == "pass") {
					break;
				}
			}
			if (i == Exmp.size()) {
				break;
			}
		}
		System.out.println("Select All Rounder");
	}

	public void selectBowler() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		bol.click();
		String wx = "(//*[@class='androidx.recyclerview.widget.RecyclerView']/*[./*[@class='android.widget.ImageView'] and ./*[@class='android.view.View']])";
		String wx2 = "//*[@class='android.widget.TextView'][1]";
		LinkedList<String> Exmp = exin.BowlerList();
		String status;
		for (int i = 0; i < Exmp.size(); i++) {
			status = null;
			String Player = Exmp.get(i).toString().replace(".", "");
			System.out.println(Player);
			for (int k = 1; k <= 3; i++) {

				for (int t = 1; t <= playerList.size(); t++) {
					WebElement Pname = driver.findElement(By.xpath(wx + "[" + t + "]" + wx2));
					String Result = Pname.getText().trim();
					if (Result.contains(Player)) {
						Pname.click();
						status = "pass";
						break;
					}
				}
				if (status != "pass") {
					driver.executeScript("seetest:client.swipe(\"Down\", 100, 100)");
				} else {

				}
				if (status == "pass") {
					break;
				}
			}
			if (i == Exmp.size()) {
				break;
			}
		}
		System.out.println("Select Bowler");
	}

	public void verifyBowler() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String rm = "//*[@class='android.widget.TextView'][1]";
		String tt = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[4]//*[@class='android.view.ViewGroup']";
		LinkedList<String> Exmp = exin.BowlerList();
		for (int i = 0; i < Exmp.size(); i++) {
			String Player = Exmp.get(i).toString();
			for (int t = 1; t <= teambowlerList.size(); t++) {
				WebElement getPlayer = driver.findElement(By.xpath(tt + "[" + t + "]" + rm));
				String screenpPlayer = getPlayer.getText().trim();
				try {
					Assert.assertEquals(screenpPlayer, Player);
					System.out.println(Player + "= Keeper Verified");
					break;

				} catch (AssertionError ex) {

				}

			}

		}
		System.out.println("Verfiy Bowler");
	}

	public void verifyBatsMan() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String tt = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[2]//*[@class='android.view.ViewGroup']";
		String rm = "//*[@class='android.widget.TextView'][1]";
		LinkedList<String> Exmp = exin.BatsmenList();
		for (int i = 0; i < Exmp.size(); i++) {
			String Player = Exmp.get(i).toString();
			for (int t = 1; t < teambatList.size(); t++) {
				WebElement getPlayer = driver.findElement(By.xpath(tt + "[" + t + "]" + rm));
				String screenpPlayer = getPlayer.getText().trim();
				try {
					Assert.assertEquals(screenpPlayer, Player);
					System.out.println(Player + "= Batsman Verified");
					break;

				} catch (AssertionError ex) {

				}

			}

		}
		System.out.println("Verfiy Batsman");
	}

	public void verifyAllRounder() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String tt = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[3]//*[@class='android.view.ViewGroup']";
		String rm = "//*[@class='android.widget.TextView'][1]";
		LinkedList<String> Exmp = exin.AllrounderList();
		for (int i = 0; i < Exmp.size(); i++) {
			String Player = Exmp.get(i).toString();
			for (int t = 1; t < teamAlrList.size(); t++) {
				WebElement getPlayer = driver.findElement(By.xpath(tt + "[" + t + "]" + rm));
				String screenpPlayer = getPlayer.getText().trim();
				try {
					Assert.assertEquals(screenpPlayer, Player);
					System.out.println(Player + "= All Rounder Verified");
					break;

				} catch (AssertionError ex) {

				}

			}

		}
		System.out.println("Verfiy AllRounder");
	}

	public void verifyKeeper() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String tt = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[1]//*[@class='android.view.ViewGroup']";
		LinkedList<String> Exmp = exin.AllrounderList();
		for (int i = 0; i < Exmp.size(); i++) {
			String Player = Exmp.get(i).toString();
			for (int t = 1; t < teamkeeperList.size(); t++) {
				WebElement getPlayer = driver
						.findElement(By.xpath(tt + "[" + t + "]//*[@class='android.widget.TextView'][1]"));
				String screenpPlayer = getPlayer.getText().trim();
				System.out.println(screenpPlayer);
				System.out.println(Player);
				try {
					Assert.assertEquals(screenpPlayer, Player);
					System.out.println(Player + "= keeper Verified");
					break;

				} catch (AssertionError ex) {

				}

			}

		}
		System.out.println("Verfiy keeper");
	}

}
