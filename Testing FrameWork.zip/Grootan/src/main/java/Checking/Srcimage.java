package Checking;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.xmlbeans.impl.xb.ltgfmt.TestCase.Files;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import Automation.CommonFunction.DataCollection;
import Automation.CommonFunction.SelWebDriverMethods;
import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Srcimage {
	private static WebDriver driver;

	public static WebDriver getDriver() {
		return driver;
	}
	//*[@id="built-tech"]/div[1]
	//*[@id="features"]/div/div/div/div/h2
	String applicationLink = ("https://www.grootan.com/");
	String Browser = "chrome".toLowerCase();
	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	String reportFilepath = System.getProperty("user.dir");
	String readexcel = reportFilepath + "\\WalkexXpath.xls";

	File files = new File(reportFilepath + "\\Exception");

	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Grootan");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Grootan");

	@Test(priority = 0)
	public void BrowserLaunch() throws BiffException, IOException, InterruptedException, AWTException {
		String Browser = "chrome";
		switch (Browser) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			options.setExperimentalOption("prefs", prefs);
			options.addArguments("disable-infobars");
			options.addArguments("--disable-popup-blocking");
			options.addArguments("--disable-web-security");
			options.addArguments("--allow-running-insecure-content");
			options.setExperimentalOption("useAutomationExtension", false);
			options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			options.addArguments("--start-maximized");
			driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.get(applicationLink);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.get(applicationLink);

		}

	}

	@Test(priority = 1)
	public void getSrcImageScreenshot() throws EncryptedDocumentException, IOException, BiffException {

		String ScreenMenu;
		if (files.mkdir()) {
			List<WebElement> lis = sel.getList(controlname.get("List Menu"), elelocators.get("List Menu"));
			for (int i = 1; i <= lis.size(); i++) {
				ScreenMenu = sel.getText(controlname.get("List Menu"), "xpath",
						elelocators.get("List Menu") + "[" + i + "]");
				String result = sel.assertequalandwriteresult(ScreenMenu, "Team");
				if (result == "Pass") {
					sel.Waituntilvisibility(controlname.get("List Menu"), "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");
					sel.seleniumAction(controlname.get("List Menu"), "Click", "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");

				}

			}
		}
		List<WebElement> element = sel.getList(controlname.get("Team List"), elelocators.get("Team List"));
		String File = readexcel;
		String sheet = "ImageName";
		FileInputStream file = new FileInputStream(new File(File));
		Workbook w;
		w = Workbook.getWorkbook(file);

		Sheet sheets = w.getSheet(sheet);
		// Sheet sheet = w.getSheet("User Login");

		for (int k = 1; k < sheets.getRows(); k++) {
			String username = sheets.getCell(0, k).getContents();
			String pass = null;
			for (int i = 1; i <= element.size(); i++) {
				List<WebElement> element1 = sel.getList(controlname.get("Team List"),
						elelocators.get("Team List") + "[" + i + "]/div");
				/*
				 * List<WebElement> element1 =
				 * NewAutomation.getDriver().findElements( By.xpath(
				 * "//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div" +
				 * "[" + i + "]/div"));
				 */
				for (int j = 1; j <= element1.size(); j++) {
					try {

						String Result = sel.getvaluewithattribute(controlname.get("Team List"), "xpath",
								elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/img", "src");

						if (Result.contains(username)) {
							System.out.println(Result + "---->" + username);
							System.out.println(Result);
							pass = "Yes";
							driver.get(Result);
							Thread.sleep(2000);
							File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(screenshotFile, new File(files.toString() + "\\" + username + ".png"));
							driver.navigate().back();
							break;
						}
					}

					catch (Exception ex) {

					}
				}
				if (pass == "Yes") {
					break;
				}

			}
		}
	}
}
