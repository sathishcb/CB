package Automation.Grootan;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.testng.annotations.Test;

public class ExcelChecking {
	@Test()
	public void get() throws EncryptedDocumentException, IOException {
		String reportFilepath = System.getProperty("user.dir");
		String path = reportFilepath+"\\TestingReport.xlsx";
		FileInputStream fileinp = new FileInputStream(path);
		HSSFWorkbook workbook = new HSSFWorkbook(fileinp);
		//workbook.createSheet("Checking");
		//Sheet sheet3 = workbook.createSheet("Febs");
		
		Sheet sheet3 = workbook.getSheet("TSR");
		// creating the 0th row using the createRow() method
		//Row rowhead = sheet3.createRow((short) 4);
		Row rowhead = sheet3.createRow((short) sheet3.getLastRowNum() + 1);
		// creating cell by using the createCell() method and setting the values to the
		// cell by using the setCellValue() method
		rowhead.createCell(0).setCellValue("S.No.");
		rowhead.createCell(1).setCellValue("Customer Name");
		rowhead.createCell(2).setCellValue("Account Number");
		rowhead.createCell(3).setCellValue("e-mail");
		rowhead.createCell(4).setCellValue("Balance"); 
		FileOutputStream fileOut = new FileOutputStream(path);
		workbook.write(fileOut);
		fileOut.close();
		System.out.println("File is written successfully");
	}
}
