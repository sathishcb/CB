package Automation.Grootan;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Automation.CommonFunction.CommonImageCompare;
import Automation.CommonFunction.DataCollection;
import Automation.CommonFunction.SelWebDriverMethods;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class GetSrcImage {

	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	String reportFilepath = System.getProperty("user.dir");
	String readexcel = reportFilepath + "\\WalkexXpath.xls";
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Grootan");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Grootan");
	

	File files = new File(reportFilepath + "\\Exception");

	@Test(priority = 1)
	public void getSrcImageScreenshot() throws Exception {

		String ScreenMenu;
		if (files.mkdir()) {
			List<WebElement> lis = sel.getList(controlname.get("List Menu"), elelocators.get("List Menu"));
			for (int i = 1; i <= lis.size(); i++) {
				ScreenMenu = sel.getText(controlname.get("List Menu"), "xpath",
						elelocators.get("List Menu") + "[" + i + "]");
				String result = sel.assertequalandwriteresult(ScreenMenu, "Team");
				if (result == "Pass") {
					sel.Waituntilvisibility(controlname.get("List Menu"), "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");
					sel.seleniumAction(controlname.get("List Menu"), "Click", "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");

				}

			}
		}
		List<WebElement> element = sel.getList(controlname.get("Team List"), elelocators.get("Team List"));
		String File = readexcel;
		String sheet = "ImageName";
		FileInputStream file = new FileInputStream(new File(File));
		Workbook w;
		w = Workbook.getWorkbook(file);

		Sheet sheets = w.getSheet(sheet);
		// Sheet sheet = w.getSheet("User Login");
		ArrayList<String> imagelist = new ArrayList<String>();
		for (int k = 1; k < sheets.getRows(); k++) {
			String username = sheets.getCell(0, k).getContents();
			String pass = null;
			for (int i = 1; i <= element.size(); i++) {
				List<WebElement> element1 = sel.getList(controlname.get("Team List"),
						elelocators.get("Team List") + "[" + i + "]/div");

				for (int j = 1; j <= element1.size(); j++) {
					try {

						String Result = sel.getvaluewithattribute(controlname.get("Team List"), "xpath",
								elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/img", "src");

						if (Result.contains(username)) {
							System.out.println(Result + "---->" + username);
							System.out.println(Result);
							pass = "Yes";
							GrootanAutomation.getDriver().get(Result);
							Thread.sleep(2000);
							File screenshotFile = ((TakesScreenshot) GrootanAutomation.getDriver())
									.getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(screenshotFile, new File(files.toString() + "\\" + username + ".png"));
							GrootanAutomation.getDriver().navigate().back();
							imagelist.add(username);
							break;
						}
					}

					catch (Exception ex) {

					}
				}
				if (pass == "Yes") {
					break;
				}

			}
		}
		//
		CommonImageCompare compare=new CommonImageCompare();
		compare.CompareImage("Exception", imagelist);
		
	}
}
