package testscript;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Test;

import baseClass.BaseClass;
import pages.ExcelReader;
import pages.NoBroker;

public class WrongInformation extends BaseClass {
	String file = System.getProperty("user.dir")+"\\TestData.xlsx";
	/*\String file = "C:\\Users\\Sathish CB\\Desktop\\TestData.xlsx";*/
	String city = "City List";
	String area = "Area List";
	String note = "Note";
	String house = "House List";
	String feedback = "Feed Back";

	@Test
	public void verifyAbuseReport() throws InterruptedException, EncryptedDocumentException, InvalidFormatException, IOException {
		NoBroker cs = new NoBroker(driver);
		ExcelReader exs = new ExcelReader(driver);
		cs.buyClick();
		cs.searchButtonClick();
		cs.cityButtonClick();
		exs.loopExcel(file, city);
		exs.loopExcel(file, area);
		cs.nearByCheckboxClick();
		cs.click2bhk();
		cs.click3bhk();
		cs.clickSearchProperty();
		exs.loopExcel(file, house);
		cs.scrollToText();
		cs.clickWrongInfo();
		cs.clickBhkType();
		cs.clickDate();
		cs.clickLocation();
		cs.clickOther();
		cs.clickPhoto();
		cs.clickPrice();
		cs.clickReport();
		cs.singleScroll();
		cs.clickB3();
		cs.clickB4();
		exs.loopExcel(file, note);
		cs.clickSave();
		exs.loopExcel(file, feedback);

	}

}
