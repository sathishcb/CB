package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

import io.appium.java_client.pagefactory.AndroidFindBy;

public class NoBroker extends BasePOMpage {

	@AndroidFindBy(id = "com.nobroker.app:id/buyLayoutText")
	public WebElement buy;

	@AndroidFindBy(id = "com.nobroker.app:id/searchEditHome")
	public WebElement searchButton;

	@AndroidFindBy(id = "com.nobroker.app:id/localityAutoCompleteTxt")
	public WebElement search;

	@AndroidFindBy(id = "android:id/text1")
	public WebElement city;

	@AndroidFindBy(xpath = "(//*[@class='android.widget.ListView']/*/*/*[@class='android.widget.LinearLayout' and ./*[@text]])[1]")
	public WebElement index1;

	@AndroidFindBy(xpath = " (//*[@class='android.widget.ListView']/*[@id='text1'])")
	public List<WebElement> cityList;

	@AndroidFindBy(id = "nearByRadio")
	public WebElement checkbox;

	@AndroidFindBy(id = "bhktwo")
	public WebElement bhk2;

	@AndroidFindBy(id = "bhkthree")
	public WebElement bhk3;

	@AndroidFindBy(id = "searchProperty")
	public WebElement searchProperty;

	@AndroidFindBy(id = "title")
	public WebElement title;

	@AndroidFindBy(id = "com.android.calculator2:id/eq")
	public WebElement scrollText;

	// tv_report_wrong_info
	@AndroidFindBy(id = "tv_report_wrong_info")
	public WebElement wrongInfo;
	@AndroidFindBy(id = "cb_location")
	public WebElement location;
	@AndroidFindBy(id = "cb_fake_photos")
	public WebElement photo;
	@AndroidFindBy(id = "cb_bhk_type")
	public WebElement bhkType;

	@AndroidFindBy(id = "cb_availability_date")
	public WebElement date;

	@AndroidFindBy(id = "cb_price")
	public WebElement price;

	@AndroidFindBy(id = "cb_other")
	public WebElement other;
	@AndroidFindBy(id = "btn_report")
	public WebElement report;

	@AndroidFindBy(xpath = "//*[@text='3 BHK']")
	public WebElement b3;
	@AndroidFindBy(xpath = "//*[@text='4 BHK']")
	public WebElement b4;

	@AndroidFindBy(id = "btn_save")
	public WebElement save;

	@AndroidFindBy(id = "edt_others")
	public WebElement note;

	@AndroidFindBy(xpath = "//*[@text='Thank you for the feedback']")
	public WebElement verify;
	@AndroidFindBy(xpath = "//*[@text='Suggest an edit']")
	public WebElement suggest;

	public NoBroker(AppiumDriver<MobileElement> driver) {
		super(driver);
	}

	WebDriverWait wait = new WebDriverWait(driver, 5);

	public void buyClick() {
		buy.click();
		System.out.println("Step 2: Click Buy");
	}

	public void searchButtonClick() {
		wait.until(ExpectedConditions.visibilityOf(searchButton));
		searchButton.click();
		System.out.println("Step 3: Click Search Button");
	}

	public void searchField(String Area) {
		// wait.until(ExpectedConditions.visibilityOf(search));
		// search.sendKeys(Area);
		driver.getKeyboard().sendKeys(Area);
		wait.until(ExpectedConditions.visibilityOf(index1));
		index1.click();
		System.out.println("Select City");
	}

	public void cityButtonClick() {
		wait.until(ExpectedConditions.visibilityOf(city));
		city.click();
		System.out.println("Step 4: Click City Search Button");
	}

	public void cityList(String City) {
		// wait.until(ExpectedConditions.visibilityOfAllElements(cityList));
		for (WebElement element : cityList) {

			String ResultCity = element.getText();
			if (ResultCity.contentEquals(City)) {
				element.click();
				break;
			}
		}
		System.out.println("Step 6: Select City");
	}

	public void nearByCheckboxClick() {
		checkbox.click();
		System.out.println("Step 7: Click Check Box");
	}

	public void click2bhk() {
		bhk2.click();
		System.out.println("Step 8: Select 2 BHK");
	}

	public void click3bhk() {
		bhk3.click();
		System.out.println("Step 9: Select 3 BHK");
	}

	public void clickSearchProperty() {
		searchProperty.click();
		System.out.println("Step 10: Click Search Property");
	}

	public void scrollToTitleText(String text) {
		for (int i = 1; i <= 10; i++) {
			try {
				String Acresult = title.getText();
				if (Acresult.contentEquals(text)) {
					title.click();
				} else {
					driver.executeScript("mobile: scroll", ImmutableMap.of("direction", "down"));
				}
			} catch (Exception ex) {
				break;
			}
		}
		System.out.println("Step 11: Select 4th house");
	}

	public void scrollToText() throws InterruptedException {
		Thread.sleep(1000);
		for (int i = 1; i <= 5; i++) {
			try {
				driver.executeScript("mobile: scroll", ImmutableMap.of("direction", "down"));
			} catch (Exception ex) {
				break;
			}
		}
	}

	public void singleScroll() throws InterruptedException {
		Thread.sleep(1000);
		driver.executeScript("mobile: scroll", ImmutableMap.of("direction", "down"));

	}

	public void clickWrongInfo() {

		wait.until(ExpectedConditions.visibilityOfAllElements(wrongInfo));

		wrongInfo.click();
		System.out.println("Step 12: Wrong Info");
	}

	public void clickLocation() {
		location.click();
		System.out.println("Step 15: Click Location");
	}

	public void clickPrice() {
		price.click();
		System.out.println("Step 18: Click Price");
	}

	public void clickPhoto() {
		photo.click();
		System.out.println("Step 17: Click Photo");
	}

	public void clickDate() {
		date.click();
		System.out.println("Step 14: Click Avialabilty Date");
	}

	public void clickBhkType() {
		bhkType.click();
		System.out.println("Step 13: Click BHK Type");
	}

	public void clickOther() {
		System.out.println("Step 16: Click Other");
		other.click();
	}

	public void clickReport() {
		report.click();
		System.out.println("Step 19: Click Report");
	}

	public void clickB3() {
		wait.until(ExpectedConditions.visibilityOfAllElements(suggest));
		b3.click();
		System.out.println("Step 21: Click 3BHK");
	}

	public void clickB4() {
		wait.until(ExpectedConditions.visibilityOfAllElements(b4));
		b4.click();
		System.out.println("Step 20: Change 3BHK To 4 BHK");
	}

	public void clickSave() {
		save.click();
		System.out.println("Step 21: Click Save Button");
	}

	public void sendNote(String Note) {

		note.click();
		driver.getKeyboard().sendKeys(Note);
		System.out.println("Step 22: Type Note");
	}

	public void verifyMsg(String Msg) {

		String gm = verify.getText();
		try {
			Assert.assertEquals(gm, Msg);
			System.out.println("Step 23: Verfiy Feed Back");

		} catch (AssertionError ex) {

		}

	}

}
