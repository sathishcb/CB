package pages;

import java.io.File;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ExcelReader extends BasePOMpage {
	public ExcelReader(AppiumDriver<MobileElement> driver) {
		super(driver);
	}

	@Test
	public void loopExcel(String file, String sheet) {
		String result;
		NoBroker cs = new NoBroker(driver);
		try {
			Workbook wb = WorkbookFactory.create(new File(file));
			Sheet st1 = wb.getSheet(sheet);
			for (int i = 1; i <= st1.getLastRowNum(); i++) {
				Row row = st1.getRow(i);
				int colunmIndex = 0;
				Cell City = row.getCell(++colunmIndex);
				result = City.toString();
				if (sheet.contentEquals("City List")) {
					cs.cityList(result);
					break;
				} else if (sheet.contentEquals("Area List")) {
					cs.searchField(result);
				} else if (sheet.contentEquals("House List")) {
					cs.	scrollToTitleText(result);
				} else if (sheet.contentEquals("Note")) {
					cs.sendNote(result);
				} else if (sheet.contentEquals("Feed Back")) {
					cs.verifyMsg(result);
				} else {

				}
			}

		} catch (Exception ex) {

		}
	}

}
