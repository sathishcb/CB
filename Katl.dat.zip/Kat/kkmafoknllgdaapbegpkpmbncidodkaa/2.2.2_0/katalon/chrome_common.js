var katalonServerPortStorage = "katalonServerPortStorage";

function setKatalonServerPort(port) {
    chrome.storage.local.set({ katalonServerPortStorage : port },  
    function() {
        if (chrome.runtime.error) {
            console.log("Runtime error setting server port to storage.");
            return;
        }
        console.log("Katalon server port set to " + port);
    });
}

function getKatalonServerPort(callback) {
    chrome.storage.local.get(katalonServerPortStorage, function(result) {
        var port;
        if (!(katalonServerPortStorage in result)) {
            port = (bowser.name == "Chrome") ? (katalonServerPort ? katalonServerPort : katalonServerPortForChrome) : katalonServerPortForFirefox;
            setKatalonServerPort(port);
        } else {
            port = result[katalonServerPortStorage];
        }
        callback(port);
    })
}

/**
 * `setToggleButtonState` and `getToggleButtonState` used to track and record the state of the toggle button
 */
var katalonToggleButtonStateStorage = "katalonToggleButtonStateStorage";

function setToggleButtonState(state, callback) {
    chrome.storage.local.set({ katalonToggleButtonStateStorage : state },  
    function() {
        if (chrome.runtime.error) {
            console.log("Runtime error while setting toggle button state to chrome.storage.");
            return;
        }
        console.log("Set toggle button state to: " + state);

        katalonToggleXPathDivState = state;

        if (callback !== null) {
            callback();
        }
    });
}

function getToggleButtonState(callback) {
    chrome.storage.local.get(katalonToggleButtonStateStorage, function(result) {
        var state;
        if (!(katalonToggleButtonStateStorage in result)) {
            state = katalonToggleXPathDivState;
            setToggleButtonState(state, null);
        }
        else {
            state = result[katalonToggleButtonStateStorage];
        }

        callback(state);
    });
}

function chromePostData(url, data, callback) {
    chrome.runtime.sendMessage({
        method: XHTTP_POST_METHOD,
        action: XHTTP_ACTION,
        url: url,
        data: data
    }, callback);
}