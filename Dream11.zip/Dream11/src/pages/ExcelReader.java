package pages;

import java.io.File;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ExcelReader extends BasePOMpage {
	public ExcelReader(AppiumDriver<MobileElement> driver) {
		super(driver);
	}

	@Test
	public void loopExcel(String file, String sheet) {
		String result1;
		String result2 = null;
		String result3 = null;
		String result4 = null;
		Dream cs = new Dream(driver);
		try {
			Workbook wb = WorkbookFactory.create(new File(file));
			Sheet st1 = wb.getSheet(sheet);
			for (int i = 1; i <= st1.getLastRowNum(); i++) {
				Row row = st1.getRow(i);
				int colunmIndex = 0;
				Cell v1 = row.getCell(++colunmIndex);
				Cell v2 = row.getCell(++colunmIndex);
				Cell v3 = row.getCell(++colunmIndex);
				Cell v4 = row.getCell(++colunmIndex);
				result1 = v1.toString();
				if (v2 != null) {
					result2 = v2.toString();

				}
				if (v3 != null) {

					result3 = v3.toString();

				}
				if (v4 != null) {

					result4 = v4.toString();
				}
				if (v2 != null && v3 != null && v4 != null) {
					result2 = v2.toString();
					result3 = v3.toString();
					result4 = v4.toString();
				}
				if (sheet.contentEquals("Match Details")) {
					cs.matchList(result1, result2, result3);
					break;
				} else if (sheet.contentEquals("Area List")) {
					// cs.searchField(result);
				} else if (sheet.contentEquals("House List")) {
					// cs. scrollToTitleText(result);
				} else if (sheet.contentEquals("Note")) {
					// cs.sendNote(result);
				} else if (sheet.contentEquals("Feed Back")) {
					// cs.verifyMsg(result1);
				} else {

				}
			}

		} catch (Exception ex) {

		}
	}

	@Test()
	public void listExcel(String file, String sheet) {

	}

}
