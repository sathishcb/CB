package testscript;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.experitest.appium.SeeTestClient;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import pages.Dream;

public class Checking {
	private String reportDirectory = "reports";
	private String reportFormat = "xml";
	private String testName = "Untitled";
	protected AppiumDriver<MobileElement> driver = null;

	DesiredCapabilities dc = new DesiredCapabilities();

	@BeforeMethod
	public void setUp() throws MalformedURLException {
		dc.setCapability("reportDirectory", reportDirectory);
		dc.setCapability("reportFormat", reportFormat);
		dc.setCapability("testName", testName);
		dc.setCapability(MobileCapabilityType.UDID, "J7AAGF07V3149EX");
		/*
		 * dc.setCapability(AndroidMobileCapabilityType.APP_PACKAGE,
		 * "com.application.bitcoiva");
		 * dc.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY,
		 * ".Activity.SplashScreen");
		 */
		driver = new AndroidDriver<>(new URL("http://localhost:4723/wd/hub"), dc);
		driver.setLogLevel(Level.INFO);
		SeeTestClient seetest = new SeeTestClient(driver);

	}

	@Test(enabled = false)
	public void verifyKeeper() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();

		String tt = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[1]//*[@class='android.view.ViewGroup']";
		List<MobileElement> teamkeeperList = driver.findElementsByXPath(
				"(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[1]");
		LinkedList<String> Exmp = exin.WicketKeeprList();
		for (int i = 0; i < Exmp.size(); i++) {
			String Player = Exmp.get(i).toString();
			for (int t = 1; t <= teamkeeperList.size(); t++) {
				WebElement getPlayer = driver
						.findElement(By.xpath(tt + "[" + t + "]//*[@class='android.widget.TextView'][1]"));
				String screenpPlayer = getPlayer.getText().trim();
				try {
					Assert.assertEquals(screenpPlayer, Player);
					System.out.println(Player + "= Keeper Verified");
					break;

				} catch (AssertionError ex) {

				}

			}

		}

	}

	@Test(enabled = false)
	public void verifyBowler() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String rm = "//*[@class='android.widget.TextView'][1]";
		String tt = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[4]//*[@class='android.view.ViewGroup']";
		List<MobileElement> teambowlerList = driver.findElementsByXPath(
				"(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[4]//*[@class='android.view.ViewGroup']");
		LinkedList<String> Exmp = exin.BowlerList();
		for (int i = 0; i < Exmp.size(); i++) {
			String Player = Exmp.get(i).toString();
			for (int t = 1; t <= teambowlerList.size(); t++) {
				WebElement getPlayer = driver.findElement(By.xpath(tt + "[" + t + "]" + rm));
				String screenpPlayer = getPlayer.getText().trim();
				System.out.println(screenpPlayer);
				System.out.println(Player);
				try {
					Assert.assertEquals(screenpPlayer, Player);
					System.out.println(Player + "= Keeper Verified");
					break;

				} catch (AssertionError ex) {

				}

			}

		}

	}

	@Test(enabled=false)
	public void verifyBatsMan() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String tt = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[2]//*[@class='android.view.ViewGroup']";
		String rm = "//*[@class='android.widget.TextView'][1]";
		List<MobileElement> teambatList = driver.findElementsByXPath(
				"(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[2]//*[@class='android.view.ViewGroup']");

		LinkedList<String> Exmp = exin.BatsmenList();
		for (int i = 0; i < Exmp.size(); i++) {
			String Player = Exmp.get(i).toString();
			for (int t = 1; t < teambatList.size(); t++) {
				WebElement getPlayer = driver.findElement(By.xpath(tt + "[" + t + "]" + rm));
				String screenpPlayer = getPlayer.getText().trim();
				try {
					Assert.assertEquals(screenpPlayer, Player);
					System.out.println(Player + "= Batsman Verified");
					break;

				} catch (AssertionError ex) {

				}

			}

		}

	}
	@Test(enabled=false)
	public void verifyAllRounder() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String tt = "(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[3]//*[@class='android.view.ViewGroup']";
		String rm = "//*[@class='android.widget.TextView'][1]";
		List<MobileElement> teamAlrList = driver.findElementsByXPath(
				"(//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.ScrollView']]/*/*[@class='android.view.ViewGroup' and ./*[@class='android.view.ViewGroup']])[3]//*[@class='android.view.ViewGroup']");

		LinkedList<String> Exmp = exin.AllrounderList();
		for (int i = 0; i < Exmp.size(); i++) {
			String Player = Exmp.get(i).toString();
			for (int t = 1; t <=teamAlrList.size(); t++) {
				WebElement getPlayer = driver.findElement(By.xpath(tt + "[" + t + "]" + rm));
				String screenpPlayer = getPlayer.getText().trim();
				System.out.println(screenpPlayer);
				System.out.println(Player);
				try {
					Assert.assertEquals(screenpPlayer, Player);
					System.out.println(Player + "= All Rounder Verified");
					break;

				} catch (AssertionError ex) {

				}

			}

		}

	}
	@Test()
	public void selectTeam() throws IOException, InterruptedException {
		int team=1;
		//wait.until(ExpectedConditions.visibilityOfAllElements(matchList));
		String tt="(//*[@class='androidx.recyclerview.widget.RecyclerView']/*/*[@id='com.app.dream11Pro:id/' and @class='android.widget.ImageView' and (./preceding-sibling::* | ./following-sibling::*)[@class='android.widget.FrameLayout']])";
		driver.findElement(By.xpath(tt+"["+team+"]")).click();
		Dream cs = new Dream(driver);
		cs.screenshot("Select Team");
		
	}
	@Test(enabled=false)
	public void selectCaptains() throws EncryptedDocumentException, InvalidFormatException, IOException {
		PlayerExcelList exin = new PlayerExcelList();
		String sm = "((//*[@class='androidx.recyclerview.widget.RecyclerView']/*[@class='android.view.ViewGroup'])";
		String rm = "/*[@text and @id='com.app.dream11Pro:id/'])[2]";
		
		List<MobileElement> caps = driver.findElementsByXPath(
				"((//*[@class='androidx.recyclerview.widget.RecyclerView']/*[@class='android.view.ViewGroup']))");
		String cap="vcap";
		switch (cap) {
		case "cap":
			LinkedList<String> Exmp = exin.CaptainList();
			for (int i = 0; i < Exmp.size(); i++) {
				String Player = Exmp.get(i).toString().replace(".", "");
				for (int t = 1; t < caps.size(); t++) {
					WebElement gt = driver.findElement(By.xpath(sm + "[" + t + "]" + rm));
					String screenpPlayer = gt.getText();
					try {
						Assert.assertEquals(screenpPlayer, Player);
						driver.findElement(By.xpath(sm + "[" + t + "])//*[@text='C']")).click();
						break;
					} catch (AssertionError ex) {
						File screenshotFile1 = driver.getScreenshotAs(OutputType.FILE);


					}

				}

			}
			break;
		case "vcap":
			LinkedList<String> Exmp1 = exin.VCaptainList();
			
			for (int i = 0; i < Exmp1.size(); i++) {
				String Player = Exmp1.get(i).toString().replace(".", "");
				for (int t = 1; t <=caps.size(); t++) {
					WebElement gt = driver.findElement(By.xpath(sm + "[" + t + "]" + rm));
					String screenpPlayer = gt.getText();
					System.out.println(Player);
					System.out.println(screenpPlayer);
					try {
						Assert.assertEquals(screenpPlayer, Player);
						driver.findElement(By.xpath(sm + "[" + t + "])//*[@text='VC']")).click();
						
						break;
					} catch (AssertionError ex) {

					}

				}

			}
			break;
		}

	}


}
