package testscript;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Test;

import baseClass.BaseClass;
import pages.ExcelReader;
import pages.Dream;

public class DreamTeam extends BaseClass {
	String file = System.getProperty("user.dir")+"\\Dream 11 Test Data.xlsx";
//	String file = "C:\\Users\\Sathish CB\\Desktop\\Dream 11 Test Data.xlsx";
	String sheet = "Match Details";

	@Test
	public void joinFreeContest()
			throws InterruptedException, EncryptedDocumentException, InvalidFormatException, IOException {
		Dream cs = new Dream(driver);
		ExcelReader exs = new ExcelReader(driver);
		
		exs.loopExcel(file, sheet);
		cs.clickCreateTeam();
		cs.selectWicketKeeper();
		cs.screenshot("Select Wicket Keeper");
		cs.selectBatsMan();
		cs.screenshot("Select Batsman");
		cs.selectAllRounder();
		cs.screenshot("Select AllRounder");
		cs.selectBowler();
		cs.screenshot("Select Bowler");
		cs.clickTeamPreview();
		cs.screenshot("Team Preview");
		cs.verifyKeeper();
		cs.verifyBatsMan();
		cs.verifyAllRounder();
		cs.verifyBowler();
		cs.closeTeamPreview();
		cs.clickContinue();
		cs.screenshot("Select Captain");
		cs.selectCaptains("cap");
		cs.selectCaptains("vcap");
		cs.clickTeamPreview();
		cs.screenshot("Captain Details");
		cs.closeTeamPreview();
		cs.saveClick();
		cs.entryFeeClick();
		cs.entryFilterClick();
		cs.firstJoinClick();
		cs.selectTeam(2);
		//cs.teamJoin();
	}

}
