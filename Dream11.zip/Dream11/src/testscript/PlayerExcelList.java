package testscript;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

public class PlayerExcelList {
	LinkedList<String> WkList = new LinkedList<String>();
	LinkedList<String> BATList = new LinkedList<String>();
	LinkedList<String> ARList = new LinkedList<String>();
	LinkedList<String> BOWLList = new LinkedList<String>();
	LinkedList<String> CAPList = new LinkedList<String>();
	LinkedList<String> VCAPList = new LinkedList<String>();

	@Test()
	public LinkedList<String> WicketKeeprList() throws EncryptedDocumentException, InvalidFormatException, IOException {
		//String file = "C:\\Users\\Sathish CB\\Desktop\\Dream 11 Test Data.xlsx";
		String file = System.getProperty("user.dir")+"\\Dream 11 Test Data.xlsx";
		Workbook wb = WorkbookFactory.create(new File(file));
		Sheet st1 = wb.getSheet("Team List");
		for (int i = 1; i <= st1.getLastRowNum(); i++) {
			Row row = st1.getRow(i);
			int colunmIndex = 0;
			Cell player = row.getCell(++colunmIndex);
			Cell team = row.getCell(++colunmIndex);
			Cell creditPoint = row.getCell(++colunmIndex);
			Cell playerType = row.getCell(++colunmIndex);
			String ResultPlayerName = player.toString();

			String ResultPlayerType = playerType.toString();
			if (ResultPlayerType.contentEquals("WK")) {

				WkList.add(ResultPlayerName);

			} else {

			}

		}

		return WkList;

	}

	@Test
	public LinkedList<String> BatsmenList() throws EncryptedDocumentException, InvalidFormatException, IOException {
		String file = System.getProperty("user.dir")+"\\Dream 11 Test Data.xlsx";
		//String file = "C:\\Users\\Sathish CB\\Desktop\\Dream 11 Test Data.xlsx";
		Workbook wb = WorkbookFactory.create(new File(file));
		Sheet st1 = wb.getSheet("Team List");

		for (int i = 1; i <= st1.getLastRowNum(); i++) {
			Row row = st1.getRow(i);
			int colunmIndex = 0;
			Cell player = row.getCell(++colunmIndex);
			Cell team = row.getCell(++colunmIndex);
			Cell creditPoint = row.getCell(++colunmIndex);
			Cell playerType = row.getCell(++colunmIndex);
			String ResultPlayerName = player.toString();

			String ResultPlayerType = playerType.toString();
			if (ResultPlayerType.contentEquals("BAT")) {

				BATList.add(ResultPlayerName);

			} else {

			}

		}

		return BATList;
	}

	@Test
	public LinkedList<String> AllrounderList() throws EncryptedDocumentException, InvalidFormatException, IOException {
		String file = System.getProperty("user.dir")+"\\Dream 11 Test Data.xlsx";
		//String file = "C:\\Users\\Sathish CB\\Desktop\\Dream 11 Test Data.xlsx";
		Workbook wb = WorkbookFactory.create(new File(file));
		Sheet st1 = wb.getSheet("Team List");

		for (int i = 1; i <= st1.getLastRowNum(); i++) {
			Row row = st1.getRow(i);
			int colunmIndex = 0;
			Cell player = row.getCell(++colunmIndex);
			Cell team = row.getCell(++colunmIndex);
			Cell creditPoint = row.getCell(++colunmIndex);
			Cell playerType = row.getCell(++colunmIndex);
			String ResultPlayerName = player.toString();

			String ResultPlayerType = playerType.toString();
			if (ResultPlayerType.contentEquals("AR")) {

				ARList.add(ResultPlayerName);

			} else {

			}

		}

		return ARList;

	}

	@Test
	public LinkedList<String> BowlerList() throws EncryptedDocumentException, InvalidFormatException, IOException {
		//String file = "C:\\Users\\Sathish CB\\Desktop\\Dream 11 Test Data.xlsx";
		String file = System.getProperty("user.dir")+"\\Dream 11 Test Data.xlsx";
		Workbook wb = WorkbookFactory.create(new File(file));
		Sheet st1 = wb.getSheet("Team List");

		for (int i = 1; i <= st1.getLastRowNum(); i++) {
			Row row = st1.getRow(i);
			int colunmIndex = 0;
			Cell player = row.getCell(++colunmIndex);
			Cell team = row.getCell(++colunmIndex);
			Cell creditPoint = row.getCell(++colunmIndex);
			Cell playerType = row.getCell(++colunmIndex);
			String ResultPlayerName = player.toString();

			String ResultPlayerType = playerType.toString();
			if (ResultPlayerType.contentEquals("BOWL")) {

				BOWLList.add(ResultPlayerName);

			} else {

			}

		}

		return BOWLList;

	}

	@Test
	public LinkedList<String> CaptainList() throws EncryptedDocumentException, InvalidFormatException, IOException {
		String file = System.getProperty("user.dir")+"\\Dream 11 Test Data.xlsx";
		//String file = "C:\\Users\\Sathish CB\\Desktop\\Dream 11 Test Data.xlsx";
		Workbook wb = WorkbookFactory.create(new File(file));
		Sheet st1 = wb.getSheet("Captain List");

		for (int i = 1; i <= st1.getLastRowNum(); i++) {
			Row row = st1.getRow(i);
			int colunmIndex = 0;
			Cell player = row.getCell(++colunmIndex);
			Cell playerType = row.getCell(++colunmIndex);
			String ResultPlayerName = player.toString();

			String ResultPlayerType = playerType.toString();
			if (ResultPlayerType.contentEquals("Captain")) {

				CAPList.add(ResultPlayerName);

			} else {

			}

		}

		return CAPList;
	}
	@Test
	public LinkedList<String> VCaptainList() throws EncryptedDocumentException, InvalidFormatException, IOException {
		//String file = "C:\\Users\\Sathish CB\\Desktop\\Dream 11 Test Data.xlsx";
		String file = System.getProperty("user.dir")+"\\Dream 11 Test Data.xlsx";
		Workbook wb = WorkbookFactory.create(new File(file));
		Sheet st1 = wb.getSheet("Captain List");

		for (int i = 1; i <= st1.getLastRowNum(); i++) {
			Row row = st1.getRow(i);
			int colunmIndex = 0;
			Cell player = row.getCell(++colunmIndex);
			Cell playerType = row.getCell(++colunmIndex);
			String ResultPlayerName = player.toString();

			String ResultPlayerType = playerType.toString();
			if (ResultPlayerType.contentEquals("VCaptain")) {

				VCAPList.add(ResultPlayerName);

			} else {

			}

		}

		return VCAPList;
	}
}
