package datadriven;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.testng.annotations.Test;

public class HtmlUnitBrowser {
	@Test
	public  void Thai() {
		// Creating a new instance of the HTML unit driver

		WebDriver driver = new HtmlUnitDriver();

		// Navigate to Google
		driver.get("https://translate.google.co.in/#view=home&op=translate&sl=auto&tl=th&text=Home");

		// Locate the searchbox using its name
		WebElement element = driver.findElement(By
				.xpath("html/body/div[3]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[3]/div[1]/div[2]/div/span[1]"));

		// Enter a search query
		String Word = element.getText();

		System.out.println(Word);
		driver.quit();
	}
}
