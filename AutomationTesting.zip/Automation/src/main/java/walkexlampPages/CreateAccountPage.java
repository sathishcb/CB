package walkexlampPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CreateAccountPage {
	private WebDriver driver;
	String Reg = "//*[@id=\"register_form\"]/h4";

	private By headerPageTxt = By.xpath(Reg);
	

	public CreateAccountPage(WebDriver driver) {
		this.driver = driver;
	}

	public String getPageTitle() {
		String title = driver.getTitle();
		System.out.println(title);
		return title;
	}

	public boolean verifyPageTitle() {
		String pageTitle = "Walkex";
		return getPageTitle().contains(pageTitle);
	}

	public boolean verifyCreateAccountPageText() throws InterruptedException {
	//	wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(Reg))));
		WebElement element = driver.findElement(headerPageTxt);
		
		String pageText = "REGISTER";
		return element.getText().trim().contains(pageText);
	}

	public void createAccount() {
		// need to write steps for creating an account
	}
}