package Osiz.Automation;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;

public class CheckDropdown {
// static ExtentTest test;
// static ExtentReports report;
	static ExtentReports extent = new ExtentReports();
	static WebDriver driver;

	@Test
	public static void browserLaunch() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://walkexlamp.osiztechnologies.in/register");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(2000);
		Actions act = new Actions(driver);

		driver.findElement(By.xpath("//*[@id=\"kycModal\"]/div/div/div[2]/div/div/button")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"usercountry\"]")).click();
		Thread.sleep(2000);
		List<WebElement> selectElement = driver.findElements(By.xpath("//*[@id=\"usercountry\"]/option"));
		// Select select = new Select(selectElement);

		// List<WebElement> ls = select.getAllSelectedOptions();
		// System.out.println(selectElement.size());
		for (WebElement option : selectElement) {
			act.moveToElement(option);
			System.out.println(option.getText().trim());
			String res = option.getText().trim();
			try {
				Assert.assertEquals(res, "India");
				System.out.println(res);
				option.click();
				break;
			} catch (AssertionError ex) {

			}
		}

	}

}
