package NewFrameWork;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;

public class GetSrcImage {

	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	String reportFilepath = System.getProperty("user.dir");
	String readexcel = reportFilepath + "\\WalkexXpath.xls";
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Grootan");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Grootan");

	File files = new File(reportFilepath + "\\Exception");

	@Test(priority = 3)
	public void getSrcImageScreenshot() throws Exception {

		String ScreenMenu;
		File file2 = new File(reportFilepath + "\\Folder 2");
		if (!file2.exists()) {
			System.out.println("Folder Is Not Present");
		} else {
			if (files.mkdir()) {
				List<WebElement> lis = sel.getList(controlname.get("List Menu"), elelocators.get("List Menu"));
				for (int i = 1; i <= lis.size(); i++) {
					ScreenMenu = sel.getText(controlname.get("List Menu"), "xpath",
							elelocators.get("List Menu") + "[" + i + "]");
					String result = sel.assertequalandwriteresult(ScreenMenu, "Team");
					if (result == "Pass") {
						sel.Waituntilvisibility(controlname.get("List Menu"), "xpath",
								elelocators.get("List Menu") + "[" + i + "]", "");
						sel.seleniumAction(controlname.get("List Menu"), "Click", "xpath",
								elelocators.get("List Menu") + "[" + i + "]", "");

					}

				}
			}
			List<WebElement> element = sel.getList(controlname.get("Team List"), elelocators.get("Team List"));
			String File = readexcel;
			String sheet = "ImageName";
			FileInputStream file = new FileInputStream(new File(File));
			Workbook w;
			w = Workbook.getWorkbook(file);

			Sheet sheets = w.getSheet(sheet);
			// Sheet sheet = w.getSheet("User Login");
			ArrayList<String> imagelist = new ArrayList<String>();
			for (int k = 1; k < sheets.getRows(); k++) {
				String username = sheets.getCell(0, k).getContents();
				String pass = null;
				for (int i = 1; i <= element.size(); i++) {
					List<WebElement> element1 = sel.getList(controlname.get("Team List"),
							elelocators.get("Team List") + "[" + i + "]/div");

					for (int j = 1; j <= element1.size(); j++) {
						try {

							String Result = sel.getvaluewithattribute(controlname.get("Team List"), "xpath",
									elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/img", "src");

							if (Result.contains(username)) {
								System.out.println(Result + "---->" + username);
								System.out.println(Result);
								pass = "Yes";
								NewAutomation.getDriver().get(Result);
								Thread.sleep(2000);
								File screenshotFile = ((TakesScreenshot) NewAutomation.getDriver())
										.getScreenshotAs(OutputType.FILE);
								FileUtils.copyFile(screenshotFile,
										new File(files.toString() + "\\" + username + ".png"));
								NewAutomation.getDriver().navigate().back();
								imagelist.add(username);
								break;
							}
						}

						catch (Exception ex) {

						}
					}
					if (pass == "Yes") {
						break;
					}

				}
			}
			//
			CommonImageCompare compare = new CommonImageCompare();
			compare.CompareImage("Exception", imagelist);

		}
	}
}