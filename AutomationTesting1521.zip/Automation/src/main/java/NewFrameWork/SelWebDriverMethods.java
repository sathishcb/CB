package NewFrameWork;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

/**
 * @author Sathish Kumar C.B
 */

public class SelWebDriverMethods {

	static WebDriverWait wait;
	// NewErrorReport er = new NewErrorReport();
	// AutomateTestReuslt automateTestReuslt = new AutomateTestReuslt();

	/**
	 * This method performs Selenium actions and return Pass or Fail according to
	 * execution success Handles the exception or error encountered during the
	 * course of execution Invokes the function to insert data to test result in
	 * case of exception or error
	 */

	/**
	 * 25/10 - Included TCname and parameter for VA report enhancement
	 **/

	/**
	 * @param controlname
	 * @param actionType
	 * @param locatorType
	 * @param elelocator
	 * @param inputData
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return String
	 */

	@Test
	public String seleniumAction(String controlname, String actionType, String locatorType, String elelocator,
			String inputData) {

		String assertmsg = "";
		String writeresult = "No";

		System.out.println("------------------------------------------");
		System.out.println("Control Name:" + controlname);
		System.out.println("Action Name:" + actionType);
		System.out.println("Locator Type:" + locatorType);
		System.out.println("Element Locator:" + elelocator);
		System.out.println("Input Data:" + inputData);

		System.out.println("------------------------------------------");

		try {
			if (actionType.equalsIgnoreCase("Open")) {
				NewAutomation.getDriver().get(inputData);
			} else if (actionType.equalsIgnoreCase("Clear")) {
				if (locatorType.equalsIgnoreCase("xpath")) {
					NewAutomation.getDriver().findElement(By.xpath(elelocator)).clear();
				} else if (locatorType.equalsIgnoreCase("id")) {
					NewAutomation.getDriver().findElement(By.id(elelocator)).clear();
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					NewAutomation.getDriver().findElement(By.linkText(elelocator)).clear();
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).clear();
				}
				writeresult = "No";
			} else if (actionType.equalsIgnoreCase("Sleep")) {
				int input = Integer.parseInt(inputData);
				Thread.sleep(input);
				writeresult = "No";
			}
			/*** Wait until presenceOfElementLocated ***/
			else if (actionType.equalsIgnoreCase("Wait")) {
				By element_locator = null;
				wait = new WebDriverWait(NewAutomation.getDriver(), Integer.parseInt(inputData));
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				wait.until(ExpectedConditions.presenceOfElementLocated(element_locator));
				writeresult = "No";
			}
			/*** Wait until visibilityOfElementLocated ***/
			else if (actionType.equalsIgnoreCase("Waituntilvisibility")) {
				By element_locator = null;
				wait = new WebDriverWait(NewAutomation.getDriver(), Integer.parseInt(inputData));
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(element_locator));
				writeresult = "No";
			}
			/*** Click Action ***/
			else if (actionType.equalsIgnoreCase("Click")) {
				if (locatorType.equalsIgnoreCase("xpath")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "10");
					NewAutomation.getDriver().findElement(By.xpath(elelocator)).click();
				} else if (locatorType.equalsIgnoreCase("id")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "10");
					NewAutomation.getDriver().findElement(By.id(elelocator)).click();
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "10");
					NewAutomation.getDriver().findElement(By.linkText(elelocator)).click();
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "10");
					NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).click();
				}
				writeresult = "No";
			}
			/*** Click Action using JavascriptExecutor ***/
			else if (actionType.equalsIgnoreCase("ClickusingJSExecutor")) {
				WebElement ele = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				JavascriptExecutor js = (JavascriptExecutor) NewAutomation.getDriver();
				js.executeScript("arguments[0].click();", ele);
				writeresult = "No";
			}
			/*** Type/Sendkeys Action ***/
			else if (actionType.equalsIgnoreCase("Typewithoutclear")) {
				if (locatorType.equalsIgnoreCase("xpath")) {
					NewAutomation.getDriver().findElement(By.xpath(elelocator)).sendKeys(inputData);
				} else if (locatorType.equalsIgnoreCase("id")) {

					NewAutomation.getDriver().findElement(By.id(elelocator)).sendKeys(inputData);
				} else if (locatorType.equalsIgnoreCase("name")) {

					NewAutomation.getDriver().findElement(By.name(elelocator)).sendKeys(inputData);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {

					NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).sendKeys(inputData);
				}
			}
			/*** Type/Sendkeys Action - Clears the field & enters input ***/
			else if (actionType.equalsIgnoreCase("Type")) {
				if (locatorType.equalsIgnoreCase("xpath")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "10");
					NewAutomation.getDriver().findElement(By.xpath(elelocator)).clear();
					// Thread.sleep(2000);
					NewAutomation.getDriver().findElement(By.xpath(elelocator)).sendKeys(inputData);
					// Thread.sleep(1000);
				} else if (locatorType.equalsIgnoreCase("id")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "10");
					NewAutomation.getDriver().findElement(By.id(elelocator)).clear();
					// Thread.sleep(2000);
					NewAutomation.getDriver().findElement(By.id(elelocator)).sendKeys(inputData);
					// Thread.sleep(1000);
				} else if (locatorType.equalsIgnoreCase("name")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "10");
					NewAutomation.getDriver().findElement(By.name(elelocator)).clear();
					// Thread.sleep(2000);
					NewAutomation.getDriver().findElement(By.name(elelocator)).sendKeys(inputData);
					// Thread.sleep(1000);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "10");
					NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).clear();
					// Thread.sleep(2000);
					NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).sendKeys(inputData);
					// Thread.sleep(1000);
				}
			}
			/***
			 * Type/Sendkeys Action - Clears the field & enters input Invokes a method to
			 * validate if the excel value is entered in the application
			 ***/
			else if (actionType.equalsIgnoreCase("Typeandvalidate")) {
				if (locatorType.equalsIgnoreCase("xpath")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					NewAutomation.getDriver().findElement(By.xpath(elelocator)).clear();
					NewAutomation.getDriver().findElement(By.xpath(elelocator)).sendKeys(inputData);
					// Thread.sleep(1500);
					validateenteredinput(controlname, locatorType, elelocator, inputData);
				} else if (locatorType.equalsIgnoreCase("id")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					NewAutomation.getDriver().findElement(By.id(elelocator)).clear();
					NewAutomation.getDriver().findElement(By.id(elelocator)).sendKeys(inputData);
					// Thread.sleep(1500);
					validateenteredinput(controlname, locatorType, elelocator, inputData);
				} else if (locatorType.equalsIgnoreCase("name")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					NewAutomation.getDriver().findElement(By.name(elelocator)).clear();
					NewAutomation.getDriver().findElement(By.name(elelocator)).sendKeys(inputData);
					// Thread.sleep(1500);
					validateenteredinput(controlname, locatorType, elelocator, inputData);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).clear();
					NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).sendKeys(inputData);
					// Thread.sleep(1500);
					validateenteredinput(controlname, locatorType, elelocator, inputData);
				}
			}
			/***
			 * Invokes a method to validate if the excel value is entered in the application
			 ***/
			else if (actionType.equalsIgnoreCase("Validate")) {
				validateenteredinput(controlname, locatorType, elelocator, inputData);
			}
			/***
			 * Invokes a method to validate if the excel value is entered in the application
			 ***/
			else if (actionType.equalsIgnoreCase("Compare")) {
				verifyautopostvalue(controlname, locatorType, elelocator, inputData);
			}
			/***
			 * Invokes a method to validate if the value in the application contains the
			 * value in excel
			 ***/
			else if (actionType.equalsIgnoreCase("Assertcontains")) {
				verifycontains(controlname, locatorType, elelocator, inputData);
			}
			/***
			 * Select value from auto populate list by value - Invokes method with
			 * validation using li tag and click
			 ***/
			else if (actionType.equalsIgnoreCase("Autolist_Selectbyvalue")) {
				autolist_selectbyvalue(controlname, locatorType, elelocator, inputData);
			}
			/***
			 * Select value from auto populate list by value - Invokes method with key press
			 * event and validation
			 ***/
			else if (actionType.equalsIgnoreCase("selectfromautolist")) {
				selectfromautolist(controlname, locatorType, elelocator, inputData);
				// Thread.sleep(1000);
			}
			/*** Perform Double Click ***/
			else if (actionType.equalsIgnoreCase("DoubleClick")) {
				WebElement ele = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("name")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.name(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				Waituntilvisibility(controlname, locatorType, elelocator, "10");
				Actions act = new Actions(NewAutomation.getDriver());
				// act.doubleClick(ele);
				act.doubleClick(ele).perform();
				writeresult = "No";
			}
			/*** Select value from drop down ***/
			else if (actionType.equalsIgnoreCase("Select")) {
				if (locatorType.equalsIgnoreCase("xpath")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					new Select(NewAutomation.getDriver().findElement(By.xpath(elelocator)))
							.selectByVisibleText(inputData);
				} else if (locatorType.equalsIgnoreCase("id")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					new Select(NewAutomation.getDriver().findElement(By.id(elelocator))).selectByVisibleText(inputData);
				} else if (locatorType.equalsIgnoreCase("name")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					new Select(NewAutomation.getDriver().findElement(By.name(elelocator)))
							.selectByVisibleText(inputData);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					new Select(NewAutomation.getDriver().findElement(By.cssSelector(elelocator)))
							.selectByVisibleText(inputData);
				}
			}
			/*** Verify if element is displayed ***/
			else if (actionType.equalsIgnoreCase("IsElementDisplayed")) {
				WebElement ele = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("name")) {
					ele = NewAutomation.getDriver().findElement(By.name(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				ele.isDisplayed();
				writeresult = "No";
			}
			/*** Assert Toast Message content ***/
			else if (actionType.equalsIgnoreCase("AssertToastMsg")) {
				String value = null;
				// String status = "Fail";
				Waituntilvisibility(controlname, locatorType, elelocator, "15");
				if (locatorType.equalsIgnoreCase("xpath")) {
					value = NewAutomation.getDriver().findElement(By.xpath(elelocator)).getText().trim();
				} else if (locatorType.equalsIgnoreCase("id")) {
					value = NewAutomation.getDriver().findElement(By.id(elelocator)).getText().trim();
				} else if (locatorType.equalsIgnoreCase("name")) {
					value = NewAutomation.getDriver().findElement(By.name(elelocator)).getText().trim();
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					value = NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).getText().trim();
				}
				assertmsg = value;
				Boolean sd = value.contains(inputData);
				assertEquals(sd.toString(), "true");
				/** Commented to remove inserting result for assertion pass **/
				/*
				 * status = "Pass"; testresult(status, "", , suite, line, inputData, value);
				 */
			}
			/*** Assert element displayed ***/
			else if (actionType.equalsIgnoreCase("AssertEleDisplayed")) {
				WebElement ele = null;
				// String status = "Fail";
				if (locatorType.equalsIgnoreCase("xpath")) {
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("name")) {
					ele = NewAutomation.getDriver().findElement(By.name(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				assertmsg = "false";
				Boolean sd = ele.isDisplayed();
				assertEquals(sd.toString(), "true");
				/** Commented to remove inserting result for assertion pass **/
				/*
				 * status = "Pass"; testresult(status, "", , suite, line, null, null);
				 */
			}
			/*** Perform Mousehover action ***/
			else if (actionType.equalsIgnoreCase("Mousehover")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).perform();
				writeresult = "No";
			}
			/*** Perform Mousehover and click action ***/
			else if (actionType.equalsIgnoreCase("Mousehoverandclick")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).perform();
				ele.click();
				writeresult = "No";
			}
			/*** Perform Mousehover Click action ***/
			else if (actionType.equalsIgnoreCase("Mousehoverclick")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.click(ele).perform();
				writeresult = "No";
			}
			/*** Move to element ***/
			else if (actionType.equalsIgnoreCase("Movetoelement")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).build().perform();
				writeresult = "No";
			}
			/*** Move to element and click action ***/
			else if (actionType.equalsIgnoreCase("Movetoelement&Click")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).build().perform();
				ele.click();
				writeresult = "No";
			}
			/*** Move to element and type action ***/
			else if (actionType.equalsIgnoreCase("Movetoelement&Type")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).build().perform();
				ele.clear();
				ele.sendKeys(inputData);
				validateenteredinput(controlname, locatorType, elelocator, inputData);
				writeresult = "Yes";
			}
			/*** Move to element,deletall and type action ***/
			else if (actionType.equalsIgnoreCase("MovetoelementDeleteAll&Type")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).build().perform();
				ele.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE), inputData);
				validateenteredinput(controlname, locatorType, elelocator, inputData);
				writeresult = "Yes";
			} else if (actionType.equalsIgnoreCase("DeleteAllType")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).build().perform();
				ele.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE), inputData);
			} else if (actionType.equalsIgnoreCase("MovetoelementDeleteAll&Type")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).build().perform();
				ele.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE), inputData);
				validateenteredinput(controlname, locatorType, elelocator, inputData);
				writeresult = "Yes";
			}
			/*** Move to element and select ***/
			else if (actionType.equalsIgnoreCase("Movetoelement&Select")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).build().perform();
				ele.clear();
				ele.sendKeys(inputData);
				ele.sendKeys(Keys.TAB);
				String value = ele.getAttribute("value");
				if (value.equalsIgnoreCase(inputData)) {
					// do nothing
				} else {

				}
				writeresult = "Yes";
			}
			/*** Move to element,deletall and select action ***/
			else if (actionType.equalsIgnoreCase("MovetoelementDeleteAll&Select")) {
				By element_locator = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					element_locator = By.xpath(elelocator);
				} else if (locatorType.equalsIgnoreCase("id")) {
					element_locator = By.id(elelocator);
				} else if (locatorType.equalsIgnoreCase("linkText")) {
					element_locator = By.linkText(elelocator);
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					element_locator = By.cssSelector(elelocator);
				}
				WebElement ele = NewAutomation.getDriver().findElement(element_locator);
				Actions actions = new Actions(NewAutomation.getDriver());
				actions.moveToElement(ele).build().perform();
				ele.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE), inputData);
				ele.sendKeys(Keys.TAB);
				String value = ele.getAttribute("value");
				if (value.equalsIgnoreCase(inputData)) {
					// do nothing
				} else {

				}
				writeresult = "Yes";
			}
			/*** Switch to frame by index ***/
			else if (actionType.equalsIgnoreCase("Switchtoframebyindex")) {
				NewAutomation.getDriver().switchTo().frame(Integer.parseInt(inputData));
				writeresult = "No";
			}
			/*** Switch to frame by name ***/
			else if (actionType.equalsIgnoreCase("Switchtoframebyname")) {
				NewAutomation.getDriver().switchTo().frame(inputData);
				writeresult = "No";
			}
			/*** Switch to frame by name ***/
			else if (actionType.equalsIgnoreCase("Switchtoframe")) {
				if (locatorType.equalsIgnoreCase("id")) {
					NewAutomation.getDriver().switchTo()
							.frame(NewAutomation.getDriver().findElement(By.id(elelocator)));
				} else if (locatorType.equalsIgnoreCase("xpath")) {
					NewAutomation.getDriver().switchTo()
							.frame(NewAutomation.getDriver().findElement(By.xpath(elelocator)));
				}
				writeresult = "No";
			}
			/*** Switch to Parent frame ***/
			else if (actionType.equalsIgnoreCase("Switchtoparent")) {
				NewAutomation.getDriver().switchTo().parentFrame();
				writeresult = "No";
			}
			/*** Switch to default content ***/
			else if (actionType.equalsIgnoreCase("Switchtodfltcontent")) {
				NewAutomation.getDriver().switchTo().defaultContent();
				writeresult = "No";
			}
			/*** Switch to New window ***/
			else if (actionType.equalsIgnoreCase("switchtoNewwindow")) {
				for (String winHandle : NewAutomation.getDriver().getWindowHandles()) {
					NewAutomation.getDriver().switchTo().window(winHandle);
				}
				writeresult = "No";
			}
			/*** Switch to Parent Window ***/
			else if (actionType.equalsIgnoreCase("switchtoparentwindow")) {
				NewAutomation.getDriver().switchTo().window(inputData);
				writeresult = "No";
			}
			/*** To perform Enter action ***/
			else if (actionType.equalsIgnoreCase("Enter")) {
				WebElement ele = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				ele.sendKeys(Keys.ENTER);
				writeresult = "No";
			}
			/*** To Perform Tab action ***/
			else if (actionType.equalsIgnoreCase("Tab")) {
				WebElement ele = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				ele.sendKeys(Keys.TAB);
				writeresult = "No";
			}
			/*** To perform Select all and Delete ***/
			else if (actionType.equalsIgnoreCase("DeleteAll")) {
				WebElement ele = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				ele.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));

			}
			/*** To delete all and send input ***/
			else if (actionType.equalsIgnoreCase("DeleteAll&Enterinput")) {
				WebElement ele = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					// Thread.sleep(2000);
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					// Thread.sleep(2000);
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					// Thread.sleep(2000);
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				ele.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE), inputData);
				/** Included verification of input value - Surya 31/10 **/
				ele.sendKeys(Keys.TAB);
				// Thread.sleep(2000);
				String value = ele.getAttribute("value");
				if (value.equalsIgnoreCase(inputData)) {
					// do nothing
				} else {
				}
			}
			/*** To delete all and select input from list ***/
			else if (actionType.equalsIgnoreCase("DeleteAll&Selectinput")) {
				WebElement ele = null;
				if (locatorType.equalsIgnoreCase("xpath")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					Waituntilvisibility(controlname, locatorType, elelocator, "5");
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				ele.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE), inputData);
				// Thread.sleep(1000);
				/** Included verification of input value in autolist - Surya 31/10 **/
				ele.sendKeys(Keys.TAB);
				String value = ele.getAttribute("value");
				// Thread.sleep(1000);
				if (value.equalsIgnoreCase(inputData)) {
					// do nothing
				} else {

				}
			}
			/*** Key Press events - robot ***/
			/*** Pageup ***/
			else if (actionType.equalsIgnoreCase("KeypressPageup")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_PAGE_UP);
				writeresult = "No";
			}
			/*** Page down ***/
			else if (actionType.equalsIgnoreCase("KeypressPagedown")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_PAGE_DOWN);
				writeresult = "No";
			}
			/*** Escape ***/
			else if (actionType.equalsIgnoreCase("KeypressEsc")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ESCAPE);
				r.keyRelease(KeyEvent.VK_ESCAPE);
				writeresult = "No";
			}
			/*** SHIFT + F12 ***/
			else if (actionType.equalsIgnoreCase("KeypressShiftF12")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_SHIFT);
				r.keyPress(KeyEvent.VK_F12);
				r.keyRelease(KeyEvent.VK_SHIFT);
				r.keyRelease(KeyEvent.VK_F12);
				writeresult = "No";
			}
			/*** SHIFT + F11 ***/
			else if (actionType.equalsIgnoreCase("KeypressShiftF11")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_SHIFT);
				r.keyPress(KeyEvent.VK_F11);
				r.keyRelease(KeyEvent.VK_SHIFT);
				r.keyRelease(KeyEvent.VK_F11);
				writeresult = "No";
			}
			/*** CTRL + V ***/
			else if (actionType.equalsIgnoreCase("KeypressCtrlV")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_CONTROL);
				r.keyPress(KeyEvent.VK_V);
				r.keyRelease(KeyEvent.VK_CONTROL);
				r.keyRelease(KeyEvent.VK_V);
				r.setAutoDelay(3000);
				writeresult = "No";
			}
			/*** TAB ***/
			else if (actionType.equalsIgnoreCase("KeypressTab")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_TAB);
				r.keyRelease(KeyEvent.VK_TAB);
				writeresult = "No";
			}
			/*** TAB ***/
			else if (actionType.equalsIgnoreCase("KeypressF5")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_F5);
				r.keyRelease(KeyEvent.VK_F5);

			}

			/*** Recursive TAB action until the provided count ***/
			else if (actionType.equalsIgnoreCase("KeypressTabRecursive")) {
				Robot r = new Robot();
				int i = 1;
				int count = Integer.parseInt(inputData);
				while (i <= count) {
					r.keyPress(KeyEvent.VK_TAB);
					r.keyRelease(KeyEvent.VK_TAB);
					i++;
				}
				writeresult = "No";
			}
			/*** ENTER ***/
			else if (actionType.equalsIgnoreCase("KeypressEnter")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				writeresult = "No";
			}
			/*** ALT + F4 ***/
			else if (actionType.equalsIgnoreCase("KeypressAltF4")) {
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ALT);
				r.keyPress(KeyEvent.VK_F4);
				r.keyRelease(KeyEvent.VK_ALT);
				r.keyRelease(KeyEvent.VK_F4);
				writeresult = "No";
			}
			/*** Close driver ***/
			else if (actionType.equalsIgnoreCase("Close")) {
				NewAutomation.getDriver().close();
				writeresult = "No";
			}

			/***
			 * Pass if Selenium Action Executed Successfully Invokes method to write the
			 * testresult if writeresult is "Yes"
			 ***/
			String status = "Pass";
			if (writeresult.equalsIgnoreCase("Yes")) {
			}
			return status;
		} catch (Exception e) {
			/*** Fail if Selenium Action failed ***/
			String status = "Fail";
			System.out.println("Selenium Action Failed");
			e.printStackTrace();
			System.out.println("Error captured:" + splitstacktrace(e.toString()));
			return status;
		} catch (AssertionError ex) {
			/*** Fail if Assertion failed ***/
			String Status = "Fail";
			System.out.println("Selenium Action Failed");
			ex.printStackTrace();
			return "Fail";
		}
	}

	/*** This method retrieves the title of window ***/

	public String getwindowtitle() {

		String wintitle = NewAutomation.getDriver().getWindowHandle();
		return wintitle;
	}

	/*** This method gets all the tabs opened and returns the size of the same ***/
	public int gettotaltabsopened() {
		int size = 0;
		size = NewAutomation.getDriver().getWindowHandles().size();
		System.out.println("No. of tabs opened:" + size);
		return size - 1;
	}

	/***
	 * This method gets all the tabs opened until the tab count provided is reached
	 ***/
	/**
	 * @param count
	 */

	public void waitfortabstoopen(int count) {
		int tabs = 0;
		while (tabs < count) {
			tabs = gettotaltabsopened();
		}
	}

	/*** This method gets the tabs opened and returns the same ***/
	/**
	 * @param count
	 * @param waittime
	 * @return tabcount
	 */

	public int returnactualtabsopen(int count, int waittime) throws InterruptedException {
		int tabs = 0;
		Thread.sleep(waittime);
		tabs = gettotaltabsopened();
		return tabs - 1;
	}

	/***
	 * This method waits until the visibility of an element and returns true/false
	 ***/
	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param inputData
	 * @return boolean
	 */
	public boolean Waituntilvisibility(String controlname, String locatorType, String elelocator, String inputData) {
		try {
			By element_locator = null;
			wait = new WebDriverWait(NewAutomation.getDriver(), Integer.parseInt(inputData));
			if (locatorType.equalsIgnoreCase("xpath")) {
				element_locator = By.xpath(elelocator);
			} else if (locatorType.equalsIgnoreCase("id")) {
				element_locator = By.id(elelocator);
			} else if (locatorType.equalsIgnoreCase("linkText")) {
				element_locator = By.linkText(elelocator);
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				element_locator = By.cssSelector(elelocator);
			}
			wait.until(ExpectedConditions.visibilityOfElementLocated(element_locator));
			return true;
		} catch (NoSuchElementException ee) {
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * This method performs Selenium click actions and return Pass or Fail
	 */

	/**
	 * @param controlname
	 * @param actionType
	 * @param locatorType
	 * @param elelocator
	 * @param inputData
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return String
	 */

	public String seleniumClickAction(String controlname, String actionType, String locatorType, String elelocator) {
		try {
			if (locatorType.equalsIgnoreCase("xpath")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				NewAutomation.getDriver().findElement(By.xpath(elelocator)).click();
			} else if (locatorType.equalsIgnoreCase("id")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				NewAutomation.getDriver().findElement(By.id(elelocator)).click();
			} else if (locatorType.equalsIgnoreCase("linkText")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				NewAutomation.getDriver().findElement(By.linkText(elelocator)).click();
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).click();
			}
			return "Pass";
		} catch (Exception e) {
			return "Fail";
		}

	}

	/*** This method finds an element and returns it as a WebElement ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return WebElement
	 * 
	 */
	public WebElement findelement(String controlname, String locatorType, String elelocator) {
		WebElement result = null;
		try {
			if (locatorType.equalsIgnoreCase("xpath")) {
				result = NewAutomation.getDriver().findElement(By.xpath(elelocator));
			} else if (locatorType.equalsIgnoreCase("id")) {
				result = NewAutomation.getDriver().findElement(By.id(elelocator));
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				result = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
			}
			return result;
		} catch (Exception e) {
			String Status = "Fail";
			System.out.println("Selenium Action Failed");
			e.printStackTrace();
			System.out.println("Error captured:" + splitstacktrace(e.toString()));
		}
		return result;
	}

	/***
	 * This method gets the webelement, clears,enters value and returns Pass/Fail
	 ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param inputvalue
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return String
	 * 
	 */
	public String findelementandtype(String controlname, String locatorType, String elelocator, String inputvalue) {
		try {
			By element_locator = null;
			if (locatorType.equalsIgnoreCase("xpath")) {
				element_locator = By.xpath(elelocator);
			} else if (locatorType.equalsIgnoreCase("id")) {
				element_locator = By.id(elelocator);
			} else if (locatorType.equalsIgnoreCase("linkText")) {
				element_locator = By.linkText(elelocator);
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				element_locator = By.cssSelector(elelocator);
			}
			WebElement ele = NewAutomation.getDriver().findElement(element_locator);
			ele.clear();
			ele.sendKeys(inputvalue);
			validateenteredinput(controlname, locatorType, elelocator, inputvalue);
			return "Pass";
		} catch (Exception e) {
			String Status = "Fail";
			System.out.println("Selenium Action Failed");
			e.printStackTrace();
			System.out.println("Error captured:" + splitstacktrace(e.toString()));

		}
		return inputvalue;
	}

	/***
	 * This method gets the webelement, clicks, enters value, clicks and invoke
	 * Enter keypress and returns Pass/Fail
	 ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param inputvalue
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return String
	 * 
	 */
	public String findeleclicktypeandenter(String controlname, String locatorType, String elelocator,
			String inputvalue) {
		try {
			By element_locator = null;
			if (locatorType.equalsIgnoreCase("xpath")) {
				element_locator = By.xpath(elelocator);
			} else if (locatorType.equalsIgnoreCase("id")) {
				element_locator = By.id(elelocator);
			} else if (locatorType.equalsIgnoreCase("linkText")) {
				element_locator = By.linkText(elelocator);
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				element_locator = By.cssSelector(elelocator);
			}
			WebElement ele = NewAutomation.getDriver().findElement(element_locator);
			ele.click();
			ele.sendKeys(inputvalue);
			Thread.sleep(2500);
			ele.click();
			ele.sendKeys(Keys.ENTER);
			return "Pass";
		} catch (Exception e) {
			String Status = "Fail";
			System.out.println("Selenium Action Failed");
			e.printStackTrace();
			System.out.println("Error captured:" + splitstacktrace(e.toString()));
			return "Fail";
		}
	}

	/*** This method retrieves elements by tagName and returns it as a list ***/

	/**
	 * @param inputdata
	 * @return list
	 * 
	 */
	public List<WebElement> findelements(String inputdata) {
		List<WebElement> options = NewAutomation.getDriver().findElements(By.tagName("iframe"));
		return options;
	}

	/*** This method retrieves the value of the element and returns the same ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return String
	 */

	public String getattributevalue(String controlname, String locatorType, String elelocator) {
		try {
			String value = null;
			if (locatorType.equalsIgnoreCase("xpath")) {
				value = NewAutomation.getDriver().findElement(By.xpath(elelocator)).getAttribute("value").trim();
			} else if (locatorType.equalsIgnoreCase("id")) {
				value = NewAutomation.getDriver().findElement(By.id(elelocator)).getAttribute("value").trim();
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				value = NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).getAttribute("value").trim();
			}
			/** returns retrieved value **/
			return value;
		} catch (Exception e) {
			/*** Fail if Selenium Action failed ***/
			String Status = "Fail";
			System.out.println(splitstacktrace(e.toString()));
			return null;
		}
	}

	/***
	 * This method retrieves the value of the element with respect to the attribute
	 * passed and returns the same
	 ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param inputdata
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return String
	 */

	public String getvaluewithattribute(String controlname, String locatorType, String elelocator, String inputdata) {
		try {
			String value = null;
			if (locatorType.equalsIgnoreCase("xpath")) {
				value = NewAutomation.getDriver().findElement(By.xpath(elelocator)).getAttribute(inputdata).trim();
			} else if (locatorType.equalsIgnoreCase("id")) {
				value = NewAutomation.getDriver().findElement(By.id(elelocator)).getAttribute(inputdata).trim();
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				value = NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).getAttribute(inputdata)
						.trim();
			}
			/** returns retrieved value **/
			return value;
		} catch (Exception e) {
			/*** Fail if Selenium Action failed ***/
			String Status = "Fail";
			System.out.println(splitstacktrace(e.toString()));
			return null;
		}
	}

	/***
	 * This method retrieves the value of the element with respect to the CSS
	 * attribute passed and returns the same
	 ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param inputdata
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return String
	 */

	public String getvaluebyCssattribute(String controlname, String locatorType, String elelocator, String inputdata) {
		try {
			String value = null;
			if (locatorType.equalsIgnoreCase("xpath")) {
				value = NewAutomation.getDriver().findElement(By.xpath(elelocator)).getCssValue(inputdata).trim();
			} else if (locatorType.equalsIgnoreCase("id")) {
				value = NewAutomation.getDriver().findElement(By.id(elelocator)).getCssValue(inputdata).trim();
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				value = NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).getCssValue(inputdata).trim();
			}
			/** returns retrieved value **/
			return value;
		} catch (Exception e) {
			/*** Fail if Selenium Action failed ***/
			String Status = "Fail";
			System.out.println(splitstacktrace(e.toString()));
			return null;
		}
	}

	/*** This method retrieves the text of the element and returns the same ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return String
	 */

	public String getText(String controlname, String locatorType, String elelocator) {
		try {
			String value = null;
			WebElement ele = null;
			Actions action = new Actions(NewAutomation.getDriver());
			if (locatorType.equalsIgnoreCase("xpath")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				action.moveToElement(ele).perform();
				value = ele.getText().trim();
			} else if (locatorType.equalsIgnoreCase("id")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				action.moveToElement(ele).perform();
				value = ele.getText().trim();
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				action.moveToElement(ele).perform();
				value = ele.getText().trim();
			}
			/** returns retrieved value **/
			return value;
		} catch (Exception e) {
			/*** Fail if Selenium Action failed ***/
			String Status = "Fail";
			System.out.println(splitstacktrace(e.toString()));
			return null;
		}
	}

	/***
	 * This method is to validate & select value from auto-populate list by input
	 * value
	 ***/
	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param valuetoselect
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 */

	public void autolist_selectbyvalue(String controlname, String locatorType, String elelocator,
			String valuetoselect) {
		String result = "Fail";
		WebElement autoOptions = null;
		try {
			wait = new WebDriverWait(NewAutomation.getDriver(), 2);
			if (locatorType.equalsIgnoreCase("xpath")) {
				autoOptions = NewAutomation.getDriver().findElement(By.xpath(elelocator));
			} else if (locatorType.equalsIgnoreCase("id")) {
				autoOptions = NewAutomation.getDriver().findElement(By.id(elelocator));
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				autoOptions = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
			}
			wait.until(ExpectedConditions.visibilityOf(autoOptions));
			List<WebElement> optionsToSelect = autoOptions.findElements(By.tagName("li"));
			for (WebElement option : optionsToSelect) {
				if (option.getText().trim().equals(valuetoselect.trim())) {
					option.click();
					result = "Pass";
					break;
				}
			}
			if (result.equals("Fail")) {
			}

		} catch (Exception e) {
			System.out.println(splitstacktrace(e.toString()));
		}
	}

	/***
	 * This method is to validate & select value from auto-populate list by input
	 * value
	 ***/
	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param valuetoselect
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 */
	/** Included condition to validate empty test data 29/10 **/
	public void selectfromautolist(String controlname, String locatorType, String elelocator, String valuetoselect) {
		String result = "Fail";
		WebElement ele = null;
		try {
			if (locatorType.equalsIgnoreCase("xpath")) {
				ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
			} else if (locatorType.equalsIgnoreCase("id")) {
				ele = NewAutomation.getDriver().findElement(By.id(elelocator));
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
			}
			ele.clear();

			System.out.println(valuetoselect);
			// Actions act = new Actions(NewAutomation.getDriver());
			// act.sendKeys(ele, valuetoselect) ;
			// ele.sendKeys(valuetoselect);
			/*
			 * Author : Sathish Kumar C.B
			 * 
			 * The below change is to slowdown the entry of a string in to the dropdown box
			 * for selection which will prevent the dropdown not getting slected if the text
			 * gets typed faster in to the text box
			 * 
			 * This will append each character to an empty string and send it to the text
			 * box which will simulate typing at a human pace
			 */
			for (int i = 0; i < valuetoselect.length(); i++) {
				char c = valuetoselect.charAt(i);
				String s = new StringBuilder().append(c).toString();
				Thread.sleep(100);
				ele.sendKeys(s);
			}

			/*
			 * ele.sendKeys(Keys.DOWN); ele.sendKeys(Keys.ENTER);
			 */
			ele.sendKeys(Keys.TAB);
			String value = ele.getAttribute("value");
			if (valuetoselect.equals("") || valuetoselect.equals(" ") || valuetoselect == null) {
				assertEquals(value, "");
			}
			if (value.equalsIgnoreCase(valuetoselect)) {
				ele.sendKeys(Keys.ENTER);
			} else {
			}

		} catch (Exception e) {
			System.out.println(splitstacktrace(e.toString()));
		} catch (AssertionError ex) {
			System.out.println(splitstacktrace(ex.toString()));
		}
	}

	/***
	 * This method is to validate the input value (from excel) and the output value
	 * (from application) are equal
	 ***/
	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param excelinput
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 */

	public void validateenteredinput(String controlname, String locatorType, String elelocator, String excelinput) {
		String result = null;
		String valuefrmapp = null;
		try {
			if (locatorType.equalsIgnoreCase("xpath")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.xpath(elelocator)).getAttribute("value").trim();
			} else if (locatorType.equalsIgnoreCase("id")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.id(elelocator)).getAttribute("value").trim();
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).getAttribute("value")
						.trim();
			}
			/**
			 * Included condition to check if exceldata is empty or null - Sathish Kumar
			 * 5/11 Included trim for excelinput - Sathish Kumar 7/11
			 **/
			if (excelinput.equals("") || excelinput.equals(" ") || excelinput == null) {
				assertEquals(valuefrmapp, "");
			} else {
				assertEquals(valuefrmapp, excelinput.trim());
			}

		} catch (Exception e) {
			e.printStackTrace();
		} catch (AssertionError e) {
			System.out.println(splitstacktrace(e.toString()));
		}

	}

	/***
	 * This method is to verify the input value (from excel) and the value auto
	 * posted (in application) are the same
	 ***/
	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param excelinput
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 */
	/** Included condition to validate empty test data 29/10 **/

	public void verifyautopostvalue(String controlname, String locatorType, String elelocator, String excelinput) {
		String result = null;
		String valuefrmapp = null;
		try {
			if (locatorType.equalsIgnoreCase("xpath")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.xpath(elelocator)).getAttribute("value").trim();
			} else if (locatorType.equalsIgnoreCase("id")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.id(elelocator)).getAttribute("value").trim();
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).getAttribute("value")
						.trim();
			}
			if (excelinput.equals("") || excelinput.equals(" ") || excelinput == null) {
			} else {
				assertEquals(valuefrmapp, excelinput);
				// testresult("Pass", "", , suite, line, inputData, valuefrmapp);
			}
		} catch (Exception | AssertionError e) {
			System.out.println(splitstacktrace(e.toString()));
		}
	}

	/***
	 * This method is to verify if the value in application contains the value in
	 * excel
	 ***/
	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param excelinput
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 */

	public void verifycontains(String controlname, String locatorType, String elelocator, String excelinput) {
		String result = null;
		String valuefrmapp = null;
		try {
			if (locatorType.equalsIgnoreCase("xpath")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.xpath(elelocator)).getAttribute("value").trim();
			} else if (locatorType.equalsIgnoreCase("id")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.id(elelocator)).getAttribute("value").trim();
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				valuefrmapp = NewAutomation.getDriver().findElement(By.cssSelector(elelocator)).getAttribute("value")
						.trim();
			}
			assertTrue(valuefrmapp.contains(excelinput));
			// testresult("Pass", "", , suite, line, inputData, valuefrmapp);

		} catch (Exception | AssertionError e) {
			System.out.println(splitstacktrace(e.toString()));
		}
	}

	/***
	 * This method verifies if an element is displayed and returns true if displayed
	 ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return boolean
	 */

	public boolean verifyelementdisplayed(String controlname, String locatorType, String elelocator) {
		try {
			WebElement ele = null;
			boolean result = false;
			boolean res = Waituntilvisibility(controlname, locatorType, elelocator, "5");
			if (res == true) {
				if (locatorType.equalsIgnoreCase("xpath")) {
					ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
				} else if (locatorType.equalsIgnoreCase("id")) {
					ele = NewAutomation.getDriver().findElement(By.id(elelocator));
				} else if (locatorType.equalsIgnoreCase("name")) {
					ele = NewAutomation.getDriver().findElement(By.name(elelocator));
				} else if (locatorType.equalsIgnoreCase("cssSelector")) {
					ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
				}
				result = ele.isDisplayed();
				return result;
			} else {
				return result;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/***
	 * This method verifies if an element is enabled and returns true if enabled
	 ***/

	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return boolean
	 */

	public boolean verifyelementenable(String controlname, String locatorType, String elelocator) {
		try {
			WebElement ele = null;
			if (locatorType.equalsIgnoreCase("xpath")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
			} else if (locatorType.equalsIgnoreCase("id")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				ele = NewAutomation.getDriver().findElement(By.id(elelocator));
			} else if (locatorType.equalsIgnoreCase("name")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				ele = NewAutomation.getDriver().findElement(By.name(elelocator));
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				Waituntilvisibility(controlname, locatorType, elelocator, "5");
				ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
			}
			boolean result = ele.isEnabled();
			return result;
		} catch (Exception e) {
			return false;
		}
	}

	/*** This method writes test result of duplicate ID ***/

	/**
	 * @param inputdata
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 */

	public void duplicateidcheck(String inputdata) {

		if (geterrorfrmapplication().contains("Given ID details are already provided as Self for the patient")) {
			String errorMsg = "Given ID details are already provided as Self for the patient:" + " " + inputdata;
		}

	}

	/*** This method writes test result of duplicate patient details ***/

	/**
	 * @param inputdata
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 */

	public void duplicatecheck(String inputdata) {
		String Status = "Fail";
		String errorMsg = "Given Patient details are already provided for a patient:" + " " + inputdata;
	}

	/***
	 * This method is to check for error toast msg and writes fail if toast msg
	 * exists
	 ***/
	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return boolean
	 */

	public boolean checkerrtoastmsgexists(String controlname, String locatorType, String elelocator) {
		String result = null;
		WebElement ele = null;
		String errmsg;
		Boolean visible = false;
		try {
			if (locatorType.equalsIgnoreCase("xpath")) {
				ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
			} else if (locatorType.equalsIgnoreCase("id")) {
				ele = NewAutomation.getDriver().findElement(By.id(elelocator));
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
			}
			visible = ele.isDisplayed();
			assertEquals(visible.toString(), "true");
			errmsg = ele.getText().trim();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/***
	 * This method is to check for error modal container and writes fail if error
	 * exists
	 ***/
	/**
	 * @param controlname
	 * @param locatorType
	 * @param elelocator
	 * @param
	 * @param suite
	 * @param line
	 * @param TCname
	 * @param
	 * @return boolean
	 */

	public boolean checkerrmodalcontainer(String controlname, String locatorType, String elelocator) {
		String result = null;
		WebElement ele = null;
		String errmsg;
		Boolean visible = false;
		try {
			Waituntilvisibility(controlname, locatorType, elelocator, "2");
			if (locatorType.equalsIgnoreCase("xpath")) {
				ele = NewAutomation.getDriver().findElement(By.xpath(elelocator));
			} else if (locatorType.equalsIgnoreCase("id")) {
				ele = NewAutomation.getDriver().findElement(By.id(elelocator));
			} else if (locatorType.equalsIgnoreCase("cssSelector")) {
				ele = NewAutomation.getDriver().findElement(By.cssSelector(elelocator));
			}
			visible = ele.isDisplayed();
			assertEquals(visible.toString(), "true");
			// errmsg = ele.getText().trim();
			errmsg = geterrorfrmapplication();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/***
	 * This method gets all the error messages from the error container and returns
	 * the same
	 ***/

	/**
	 * @return String
	 */

	public String geterrorfrmapplication() {
		WebElement errorcont = null;
		String error = "";
		errorcont = NewAutomation.getDriver()
				.findElement(By.xpath("//*[@class=\"errorlog-modal-container-box errmodal\"]"));
		List<WebElement> totalerr = errorcont.findElements(By.tagName("tr"));
		for (int j = 1; j < totalerr.size(); j++) {
			error += NewAutomation.getDriver()
					.findElement(
							By.xpath("//*[@class=\"errorlog-modal-custom-content\"]/table/tbody/tr[" + j + "]/td[4]"))
					.getText() + ",";
		}
		System.out.println(error);
		return error;

	}

	/***
	 * This method takes screenshot of the failed screen and invokes a function to
	 * insert result into the DB
	 ***/

	/**
	 * @param status
	 * @param errorMsg
	 * @param
	 * @param suite
	 * @param line
	 * @param ip
	 * @param op
	 * @param TCname
	 * @param
	 * @return String
	 */

	public void testresultwithipandop(String status, String errorMsg, String ip, String op, String TCname) {
		String errscreenshot = null;
		if (status.equalsIgnoreCase("Fail")) {
			System.out.println("Selenium Action Failed");
		} else {
		}

	}

	/***
	 * This method takes screenshot of the failed screen and invokes a function to
	 * insert result into the DB
	 ***/

	/**
	 * @param status
	 * @param errorMsg
	 * @param
	 * @param suite
	 * @param line
	 * @param ip
	 * @param op
	 * @param TCname
	 * @param
	 * @return String
	 */
	/**
	 * Included else block to pass o/p as empty if status is Pass & is Data
	 * Validation - 29/10
	 **/

	public void testresult(String status, String errorMsg, String ip, String op, String TCname) {
		String errscreenshot = null;
		if (status.equalsIgnoreCase("Fail")) {
			System.out.println("Selenium Action Failed");

		} else if (status.equalsIgnoreCase("Pass")) {

		}

	}

	/*** This method invokes a function to insert result into the DB ***/

	/**
	 * @param status
	 * @param errorMsg
	 * @param
	 * @param suite
	 * @param line
	 * @param ip
	 * @param op
	 * @param TCname
	 * @param
	 * @return String
	 */

	public void dbtestresult(String status, String errorMsg, String ip, String op) {
		String errscreenshot = null;

	}

	/**
	 * This method verifies if Control name and Element locators are null and
	 * returns error message
	 **/

	/**
	 * @param controlname
	 * @param elelocator
	 * @param
	 * @param suite
	 * @param line
	 * @param ip
	 * @param op
	 * @param TCname
	 * @param
	 * @return String
	 */

	public String verifyvalueinrepository(String controlname, String elelocator) {
		String Status = "Pass";
		if (elelocator == null && controlname == null) {
			/*** Fail if Element Locator & Control name is null ***/
			Status = "Fail";
		} else if (elelocator == null) {
			/*** Fail if Element Locator is null ***/
			Status = "Fail";
		}
		return Status;
	}

	/***
	 * This method splits the complete error stack trace and returns a snippet of it
	 ***/

	/**
	 * @param error
	 * @return String
	 */
	public String splitstacktrace(String error) {
		System.out.println(error);
		String[] msg = error.split("\\(");
		String errmsg = msg[0];
		return errmsg;
	}

	/***
	 * This method asserts two input strings and invokes method to write result
	 ***/

	/**
	 * @param input1
	 * @param input2
	 * @param
	 * @param suite
	 * @param line
	 * @param ip
	 * @param op
	 * @param TCname
	 * @param
	 * @return
	 * @throws IOException
	 */
	public String assertequalandwriteresult(String input1, String input2) {
		String Status = null;
		try {
			assertEquals(input1, input2);
			Status = "Pass";
		} catch (AssertionError e) {
			Status = "Fail";
		}
		return Status;
	}

	/***
	 * This method asserts Contains two input strings and invokes method to write
	 * result
	 ***/

	/**
	 * @param input1
	 * @param input2
	 * @param
	 * @param suite
	 * @param line
	 * @param ip
	 * @param op
	 * @param TCname
	 * @param
	 * @return
	 */
	public String assertcontainsandwriteresult(String input1, String input2) {
		String Status;
		try {
			assertTrue(input1.contains(input2));
			Status = "Pass";

		} catch (AssertionError e) {
			Status = "Fail";

		}
		return Status;
	}

	/*** This method retrieves elements by xpath and returns it as a list ***/

	/**
	 * @param xpath
	 * @param Controlname
	 * @param
	 * @param suite
	 * @param line
	 * @param ip
	 * @param op
	 * @param TCname
	 * @param
	 */
	public List<WebElement> getList(String controlname, String elelocator) {
		System.out.println(elelocator);
		List<WebElement> options = NewAutomation.getDriver().findElements(By.xpath(elelocator));
		return options;
	}

	/***
	 * This method retrieves elements by xpath and returns it as a Boolean Value For
	 * isSelected
	 ***/
	/**
	 * @param xpath
	 * @param Controlname
	 * @param
	 * @param suite
	 * @param line
	 * @param ip
	 * @param op
	 * @param TCname
	 * @param
	 */
	public Boolean IsSelected(String controlname, String elelocator) {
		Boolean sel = null;
		try {
			WebElement value = NewAutomation.getDriver().findElement(By.xpath(elelocator));
			sel = value.isSelected();

		} catch (Exception e) {
			String Status = "Fail";
			String errorMsg = e.getMessage();

		}
		return sel;
	}

	public String getTitle() {
		String title = null;
		title = NewAutomation.getDriver().getTitle();
		return title;
	}

	public String getCurrentUrl() {
		String url = null;
		url = NewAutomation.getDriver().getCurrentUrl();
		return url;
	}

	/*** Quit driver ***/
	public void teardown() {
		NewAutomation.getDriver().quit();
	}

}
