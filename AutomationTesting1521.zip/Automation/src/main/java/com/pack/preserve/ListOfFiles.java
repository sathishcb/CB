package com.pack.preserve;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.testng.annotations.Test;

public class ListOfFiles {
	@Test()
	public ArrayList<String> List() throws IOException {
		// Creating a File object for directory
		String reportFilepath = System.getProperty("user.dir");
		File directoryPath = new File(reportFilepath + "\\Folder 1");
		File directoryPath1 = new File(reportFilepath + "\\Folder 2");
		// List of all files and directories
		String contents[] = directoryPath.list();
		String contents1[] = directoryPath1.list();
		ArrayList<String> files = new ArrayList<String>();
		ArrayList<String> files1 = new ArrayList<String>();
		ArrayList<String> result = new ArrayList<String>();
		System.out.println("List of files and directories in the specified directory:");
		for (int i = 0; i < contents.length; i++) {
			// System.out.println(contents[i]);
			files.add(contents[i]);
			files1.add(contents1[i]);
		}
		System.out.println(files);
		System.out.println(files1);
		for (int i = 0; i < files.size(); i++) {
			for (int k = 0; k < files1.size(); k++) {
				String f = files.get(k);
				String f1 = files.get(i);
				if (f.equals(f1)) {
					System.out.println(f);
					System.out.println(f1);
					result.add(f);
					break;
				}
			}
		}
		return result;
	}

}
