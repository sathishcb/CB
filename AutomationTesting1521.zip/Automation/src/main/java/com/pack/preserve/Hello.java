package com.pack.preserve;

public class Hello {
	public static void main(String[] args) {

		// String opencvpath =
		// "C:/Users/Tester-Sathishkumar/.m2/repository/org/openpnp/opencv/3.2.0-0/opencv-3.2.0-0-sources.jar";

		// System.load(opencvpath + Core.NATIVE_LIBRARY_NAME + ".dll");

		System.out.printf("java.library.path: %s%n", System.getProperty("java.library.path"));
		System.loadLibrary("opencv_java320");

	}
}
