package com.limt.trade;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.Test;

public class TradeCalucation {
	@Test()
	public String totalCalucation(String Amount, String Price, String Fee) {
		double List = Double.parseDouble(Amount);
		double p = Double.parseDouble(Price);
		double f = Double.parseDouble(Fee);
		double r = p * List;
		DecimalFormat df2 = new DecimalFormat("#.########");
		double Fees = r * f / 100;
		String ResultTotal = df2.format(r + Fees);
		return ResultTotal;

	}

	@Test()
	public String feeCalucation(String Amount, String Price, String Fee) {
		double List = Double.parseDouble(Amount);
		double p = Double.parseDouble(Price);
		double f = Double.parseDouble(Fee);
		double r = p * List;
		DecimalFormat df2 = new DecimalFormat("#.########");
		double Fees = r * f / 100;
		String ResultFee = df2.format(Fees);
		return ResultFee;

	}

	@Test()
	public String BalanceCalucation(String Balance, String Amount) {
		double a = Double.parseDouble(Amount);
		double b = Double.parseDouble(Balance);

		DecimalFormat df2 = new DecimalFormat("#.########");
		double resultbalance = b - a;
		String ResultBalance = df2.format(resultbalance);
		return ResultBalance;

	}

	@Test()
	public String ScreenTotalCalucation(String Amount, String Price) {
		double List = Double.parseDouble(Amount);
		double p = Double.parseDouble(Price);
		double r = p * List;
		DecimalFormat df2 = new DecimalFormat("#.########");
		String ResultTotal = df2.format(r);
		return ResultTotal;

	}
	@Test()
	public String CurrentDate() {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String Date = df.format(new Date());
		System.out.println(Date);
		return Date;
	}
}
