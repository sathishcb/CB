package com.limt.trade;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import commonFuncation.DataCollection;
import commonFuncation.SelWebDriverMethods;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import launch.Utility;
import trade.BrowserLaunch;
import walkexBase.ExtentTestManager;

public class LimitBuyOrder {
	/** Object Creation **/

	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	String readexcel = "C:\\Users\\Tester-Sathishkumar\\Desktop\\WalkexXpath.xls";
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Trade");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Trade");

	@Test(priority = 5,enabled=true)
	public void limtBuyOrder() throws IOException, BiffException {
		/** Declaring & Initializing variables **/
		/*** Element locator & Control name collection ***/

		String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w;
		w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("Limt Order");
		String temp = null;
		for (int j = 1; j < sheet.getRows(); j++) {
			String MarketPrice = sheet.getCell(3, j).getContents();
			String Amount = sheet.getCell(4, j).getContents();
			String Fee = sheet.getCell(5, j).getContents();
			// Click Buy Tab
			sel.seleniumAction(controlname.get("Buy Tab Button"), "Click", "id", elelocators.get("Buy Tab Button"), "");
			// Click Limit Tab
			sel.seleniumAction(controlname.get("Limit Tab Button"), "Click", "id", elelocators.get("Limit Tab Button"),
					"");
			// Enter Market Price
			sel.seleniumAction(controlname.get("Buy Price"), "Type", "id", elelocators.get("Buy Price"), MarketPrice);
			// Enter Amount
			sel.seleniumAction(controlname.get("Buy Amount"), "Type", "xpath", elelocators.get("Buy Amount"), Amount);
			sel.seleniumAction(controlname.get("Buy Amount"), "Click", "xpath", elelocators.get("Buy Amount"), "");
			temp = Utility.getScreenshot(BrowserLaunch.getDriver());
			String BuyTotal = sel.getattributevalue(controlname.get("Buy Total"), "xpath",
					elelocators.get("Buy Total"));
			String FeePrecentage = sel.getText(controlname.get("Buy Fee Precentage"), "xpath",
					elelocators.get("Buy Fee Precentage"));
			String FeeAmount = sel.getText(controlname.get("Buy Fee Amount"), "xpath",
					elelocators.get("Buy Fee Amount"));
			String FeeSymbol = sel.getText(controlname.get("Buy Total Pair Symbol"), "xpath",
					elelocators.get("Buy Total Pair Symbol"));

			System.out.println("BuyTotal:" + BuyTotal);
			System.out.println("FeePrecentage:" + FeePrecentage);
			System.out.println("FeeAmount:" + FeeAmount);
			System.out.println("FeeSymbol :" + FeeSymbol);
			TradeCalucation calculation = new TradeCalucation();
			String ResultFee = calculation.feeCalucation(Amount, MarketPrice, Fee);
			System.out.println(ResultFee);
			String ResultTotal = calculation.totalCalucation(Amount, MarketPrice, Fee);
			System.out.println(ResultTotal);

			/* Total Details */
			String BuyTotalResult = sel.assertequalandwriteresult(ResultTotal, BuyTotal);
			if (BuyTotalResult == "Pass") {
				ExtentTestManager.getTest().log(Status.PASS,
						" Actual Total Crypto  :" + BuyTotal + " ## " + " Expected Total Crypto  : " + ResultTotal,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			} else {
				ExtentTestManager.getTest().log(Status.FAIL,
						" Actual Total Crypto  :" + BuyTotal + " ## " + " Expected Total Crypto  : " + ResultTotal,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			}

			/* Fee Precentage Details */
			String FeePrecentageResult = sel.assertcontainsandwriteresult(FeePrecentage, Fee);
			if (FeePrecentageResult == "Pass") {
				ExtentTestManager.getTest().log(Status.PASS,
						" Actual Fee Precentage  :" + FeePrecentage + " ## " + " Expected Fee Precentage  : " + Fee,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			} else {
				ExtentTestManager.getTest().log(Status.FAIL,
						" Actual Fee Precentage   :" + FeePrecentage + " ## " + " Expected Fee Precentage   : " + Fee,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			}
			/* Fee Details */
			String FeeResult = sel.assertcontainsandwriteresult(FeePrecentage, Fee);
			if (FeeResult == "Pass") {
				ExtentTestManager.getTest().log(Status.PASS,
						" Actual Fee Precentage  :" + ResultFee + " ## " + " Expected Fee Precentage  : " + FeeAmount,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			} else {
				ExtentTestManager.getTest().log(Status.FAIL,
						" Actual Fee Precentage   :" + ResultFee + " ## " + " Expected Fee Precentage   : " + FeeAmount,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			}

			String BuyBalance = sel.getText(controlname.get("Buy Balance"), "xpath", elelocators.get("Buy Balance"));
			sel.seleniumAction(controlname.get("Buy Button"), "Click", "xpath", elelocators.get("Buy Button"), "");
			String noti = sel.getText(controlname.get("Notification"), "xpath", elelocators.get("Notification"));
			System.out.println(noti);
			sel.seleniumAction("", "KeypressF5", "", "", "");
			sel.seleniumAction("", "Sleep", "", "", "5");
			sel.Waituntilvisibility(controlname.get("Buy Balance"), "xpath", elelocators.get("Buy Balance"), "10");
			String CalucationResultBalance = calculation.BalanceCalucation(BuyBalance, ResultTotal);
			System.out.println(CalucationResultBalance);
			String AfterTradeBuyBalance = sel.getText(controlname.get("Buy Balance"), "xpath",
					elelocators.get("Buy Balance"));
			temp = Utility.getScreenshot(BrowserLaunch.getDriver());
			String ResultBuyBalance = sel.assertcontainsandwriteresult(AfterTradeBuyBalance, CalucationResultBalance);
			if (ResultBuyBalance == "Pass") {
				ExtentTestManager.getTest().log(Status.PASS,
						" Actual Balance Crypto After Trade  :" + AfterTradeBuyBalance + " ## "
								+ " Expected Balance Crypto After Trade  : " + CalucationResultBalance,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			} else {
				ExtentTestManager.getTest().log(Status.FAIL,
						" Actual Balance Crypto After Trade  :" + AfterTradeBuyBalance + " ## "
								+ " Expected Balance Crypto After Trade  : " + CalucationResultBalance,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			}
		}
	}

}
