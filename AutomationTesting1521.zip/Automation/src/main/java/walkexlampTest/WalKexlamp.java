	package walkexlampTest;

import java.io.IOException;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import launch.Excel;
import launch.Utility;
import walkexBase.ExtentTestManager;
import walkexlampPages.POM_Login;

public class WalKexlamp {
	// static ExtentTest test;
	// static ExtentReports report;
	static ExtentReports extent = new ExtentReports();
	static WebDriver driver;

	@BeforeClass
	public static void startTest() {
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("Osizextent.html");

		extent.attachReporter(htmlReporter);
	}

	@BeforeTest()
	public static void browserLaunch() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("http://walkexlamp.osiztechnologies.in/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	//	WalKexlamp vhpapp= PageFactory.initElements(driver, WalKexlamp.class);

	}

	@Test(priority=1 )
	public static void verifyHomePageTitle() throws IOException {
		ExtentTest test = extent.createTest("verifyHomePageTitle", "Checking the Title");
		POM_Login walk = new POM_Login(driver);
		String actualLink = walk.GetCurrentTitle();
		test.log(Status.INFO, "Actual Title returned :: " + actualLink);
		String expected = "Walkex";
		test.log(Status.INFO, "Expected Title returned:: " + expected);
		Assert.assertEquals(actualLink, expected);
		String temp = Utility.getScreenshot(driver);
		ExtentTestManager.getTest().log(Status.PASS, "details", MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		extent.flush();

	}

	@Test
	public static void LoginButton() throws IOException {
		try {
			Thread.sleep(3000);
		ExtentTest test = extent.createTest("verifyLoginPage", "Checking the Title");
		POM_Login walk = new POM_Login(driver);
		walk.clickOnLoginButton();
		String actualLink = walk.VefiyLoginPage();
		test.log(Status.INFO, "Actual Heading returned :: " + actualLink);
		String expected = "login";
		test.log(Status.INFO, "Expected Heading returned:: " + expected);
		Assert.assertEquals(actualLink, expected);
		String temp = Utility.getScreenshot(driver);
		test.pass("details", MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		extent.flush();
		}
		catch(Exception Ex) {
			System.out.println(Ex);
		}

	}
	@Test(priority=3,enabled=false)
	public static void Login() throws IOException {
		try {
			String file="";
			String sheet="";
		ExtentTest test = extent.createTest("Login With Valid Details", "Checking the Title");
		POM_Login walk = new POM_Login(driver);
		Excel cd=new Excel(driver);
		cd.excelLoop(file, sheet);
		//test.log(Status.INFO, "UserName :: " + actualLink);
		String expected = "login";
		test.log(Status.INFO, "Password" + expected);
		//Assert.assertEquals(actualLink, expected);
		String temp = Utility.getScreenshot(driver);
		test.pass("details", MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		extent.flush();
		}
		catch(Exception Ex) {
			System.out.println(Ex);
		}

	}
}
