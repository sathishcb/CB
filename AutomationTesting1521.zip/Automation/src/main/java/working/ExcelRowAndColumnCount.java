package working;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.hssf.usermodel.HSSFSheet;  
import org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import org.apache.poi.ss.usermodel.Row; 
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.testng.annotations.Test;



public class ExcelRowAndColumnCount {
	HSSFWorkbook workbook = new HSSFWorkbook();
	String reportFilepath = System.getProperty("user.dir");
	String filename = reportFilepath + "\\Extend.xlsx";

	@Test()
	public void Countexc() throws IOException {
		FileInputStream fis = new FileInputStream(filename);
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheet("Goutam");
		HSSFRow row = sheet.getRow(1);
		int colNum = row.getLastCellNum();
	
		System.out.println("Total Number of Columns in the excel is : " + colNum);
		int rowNum = sheet.getLastRowNum() + 1;
		System.out.println("Total Number of Rows in the excel is : " + rowNum);
		Iterator<Row> itr = sheet.iterator();    //iterating over excel file  
		while (itr.hasNext()) 
			//Cell cell = cellIterator.next();  
		{  
		Row rows = itr.next();  
		Iterator<org.apache.poi.ss.usermodel.Cell> cellIterator = rows.cellIterator();
		//System.out.println(cell.getStringCellValue() );
		}
	}
}