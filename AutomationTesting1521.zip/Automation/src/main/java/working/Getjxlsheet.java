package working;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Getjxlsheet {
	HSSFWorkbook workbook = new HSSFWorkbook();
	String reportFilepath = System.getProperty("user.dir");
	String filename = reportFilepath + "\\VBITTradeHistory.xlsx";

	@Test

	public void TradeCancel() throws BiffException, IOException {

		String filePath = "C:\\Users\\Tester-Sathishkumar\\Downloads\\user_trade28.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("Trade");
		String Id = null;
		String OrderedOn = null;
		String OrderedOns = null;
		String Pair = null;
		String Buyer = null;
		String Seller = null;
		String Price = null;
		String Amount = null;
		String Total = null;
		String Status = null;
		String BuyFees = null;
		String SellFess = null;

		// creating an instance of HSSFWorkbook class

		File files = new File(filename);
		Boolean File = files.exists();
		System.out.println(File);
		if (!files.exists()) {
			// Create file system using specific name
			FileOutputStream out = new FileOutputStream(new File(filename));

			System.out.println("createworkbook.xlsx written successfully");
		}

		ArrayList<String> NameList = new ArrayList<String>();
		try {

			for (int l = 1; l < sheet.getRows(); l++) {

				Buyer = sheet.getCell(3, l).getContents();

				NameList.add(Buyer);

			}
			List newList = NameList.stream().distinct().collect(Collectors.toList());
			System.out.println(NameList.toString());
			System.out.println(newList);
			String ListBuyer = null;
			FileOutputStream out = new FileOutputStream(new File(filename));
			for (int l = 1; l < newList.size(); l++) {
				ListBuyer = newList.get(l).toString();
				ArrayList<String> ExList = new ArrayList<String>();
				System.out.println(
						"=============================================================================================================================================");
				System.out.println(l + " " + ListBuyer);
				System.out.println(
						"=============================================================================================================================================");
				HSSFSheet sheets = workbook.createSheet(ListBuyer);
				for (int exceldata = 1; exceldata < sheet.getRows(); exceldata++) {
					Buyer = sheet.getCell(3, exceldata).getContents();
					Pair = sheet.getCell(2, exceldata).getContents();
					// creating cell by using the createCell() method and setting the values to the
					// cell by using the setCellValue() method
					if (Buyer.contentEquals(ListBuyer)) {
						if (Pair.contains("VBIT")) {
							HSSFRow rowhead = sheets.createRow((short) 0);
							rowhead.createCell(0).setCellValue("Id");
							rowhead.createCell(1).setCellValue("Ordered On");
							rowhead.createCell(2).setCellValue("Pair");
							rowhead.createCell(3).setCellValue("Buyer");
							rowhead.createCell(4).setCellValue("Seller");
							rowhead.createCell(5).setCellValue("Price");
							rowhead.createCell(6).setCellValue("Amount");
							rowhead.createCell(7).setCellValue("BuyFees");
							rowhead.createCell(8).setCellValue("SellFess");
							rowhead.createCell(9).setCellValue("Total");
							rowhead.createCell(10).setCellValue("Status");
						}
					}
					if (Buyer.contentEquals(ListBuyer)) {
						if (Pair.contains("VBIT")) {
							Id = sheet.getCell(0, exceldata).getContents();
							OrderedOn = sheet.getCell(1, exceldata).getContents();
							Pair = sheet.getCell(2, exceldata).getContents();
							Buyer = sheet.getCell(3, exceldata).getContents();
							Seller = sheet.getCell(4, exceldata).getContents();
							Price = sheet.getCell(5, exceldata).getContents();
							Amount = sheet.getCell(6, exceldata).getContents();
							BuyFees = sheet.getCell(7, exceldata).getContents();
							SellFess = sheet.getCell(8, exceldata).getContents();
							Total = sheet.getCell(9, exceldata).getContents();
							Status = sheet.getCell(10, exceldata).getContents();
							System.out.println(
									Id + " " + OrderedOn + " " + Pair + " " + Buyer + " " + Seller + " " + Price + " "
											+ Amount + " " + BuyFees + " " + SellFess + " " + Total + " " + Status);

							HSSFRow row = sheets.createRow((short) ExList.size() + 1); // inserting data in the first
							ExList.add(Id);
							row.createCell(0).setCellValue(Id);
							row.createCell(1).setCellValue(OrderedOn);
							row.createCell(2).setCellValue(Pair);
							row.createCell(3).setCellValue(Buyer);
							row.createCell(4).setCellValue(Seller);
							row.createCell(5).setCellValue(Price);
							row.createCell(6).setCellValue(Amount);
							row.createCell(7).setCellValue(BuyFees);
							row.createCell(8).setCellValue(SellFess);
							row.createCell(9).setCellValue(Total);
							row.createCell(10).setCellValue(Status);

						}

					}

				}
			}
		} catch (Exception ex) {

			FileOutputStream fileOut = new FileOutputStream(filename);
			workbook.write(fileOut); // closing the Stream fileOut.close(); // closing
			workbook.close(); // prints the message on the console
			System.out.println("Excel file has been generated successfully.");
			System.out.println(ex);

		}
	}

	@AfterTest()
	public void filewrite() throws IOException {
		FileOutputStream fileOut = new FileOutputStream(filename);
		workbook.write(fileOut); // closing the Stream fileOut.close(); // closing
		workbook.close(); // prints the message on the console
		System.out.println("Excel file has been generated successfully.");
	}
}