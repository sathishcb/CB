package working;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import java.io.FileInputStream;
 
public class ReadExcelData{
static String reportFilepath = System.getProperty("user.dir");
static String filename = reportFilepath + "\\Extend.xlsx";

    public static void main(String args[]) throws Exception
    {
        FileInputStream fis = new FileInputStream(filename);
        HSSFWorkbook workbook = new HSSFWorkbook(fis);
        HSSFSheet sheet = workbook.getSheet("Goutam");
        HSSFRow row = sheet.getRow(0);
 
        int col_num = -1;
 
        for(int i=0; i < row.getLastCellNum(); i++)
        {
            if(row.getCell(i).getStringCellValue().trim().equals("Total"))
                col_num = i;
        }
 
        row = sheet.getRow(1);
        HSSFCell cell = row.getCell(col_num);
 
        String value = cell.getStringCellValue();
        System.out.println("Value of the Excel Cell is - "+ value);
    }
}
