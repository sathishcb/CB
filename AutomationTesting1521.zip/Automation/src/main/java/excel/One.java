package excel;

import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.testng.annotations.Test;

public class One extends DynamicReport{
	@Override
	@Test(priority=3)
	public void test1() throws IOException {
		HSSFSheet sheet = workbook.createSheet("One");
		HSSFRow rowhead = sheet.createRow((short) 0);
		// creating cell by using the createCell() method and setting the values to the
		// cell by using the setCellValue() method
		rowhead.createCell(0).setCellValue("S.No.");
		rowhead.createCell(1).setCellValue("Customer Name");
		rowhead.createCell(2).setCellValue("Account Number");
		rowhead.createCell(3).setCellValue("e-mail");
		rowhead.createCell(4).setCellValue("Balance");

		System.out.println("Excel file has been generated successfully.");
		
	}
}
