package excel;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.read.biff.BiffException;

public class Srcimage {
	private static WebDriver driver;

	public static WebDriver getDriver() {
		return driver;
	}

	@Test(priority = 0)
	public void BrowserLaunch() throws BiffException, IOException, InterruptedException, AWTException {
		String applicationLink = ("https://www.grootan.com/#built-tech");
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-web-security");
		options.addArguments("--allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.addArguments("--start-maximized");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(applicationLink);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	//	driver.switchTo().frame("drift-frame-controller");
	//	driver.findElement(By.xpath("/html/body/div[3]")).click();
	String st=	driver.findElement(By.xpath("/html/body/div[2]")).getAttribute("visibility");
	System.out.println(st);
	WebDriverWait wait=new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]")));
	Boolean tr=driver.findElement(By.xpath("/html/body/div[2]")).isDisplayed();
	System.out.println(tr);

	}

}
