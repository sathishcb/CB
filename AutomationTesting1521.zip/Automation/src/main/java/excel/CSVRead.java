package excel;

import java.io.FileReader;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class CSVRead {

	// Provide CSV file path. It Is In D: Drive.
	String CSV_PATH = "C:\\Users\\Tester-Sathishkumar\\Desktop\\SBX\\28-11-2020\\user_orders.csv";
	WebDriver driver;

	@Test
 public void csvDataRead() throws IOException, CsvValidationException{
  
  CSVReader reader = new CSVReader(new FileReader(CSV_PATH));
  String [] csvCell;
  //while loop will be executed till the last line In CSV.
  while ((csvCell = reader.readNext()) != null) {  
 System.out.println(reader.getLinesRead()); 
	  String LName = csvCell[1];
 
  System.out.println(LName);
  }  
 }
}
