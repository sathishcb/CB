package excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class FilterGetjxlsheet {
	String reportFilepath = System.getProperty("user.dir");
	String filename = reportFilepath + "\\New Trade Balancess.xlsx";
	HSSFWorkbook workbook = new HSSFWorkbook();
	HSSFSheet sheets;
	@Test

	public void TradeCancel() throws BiffException, IOException {

		String filePath = "C:\\Users\\Tester-Sathishkumar\\Downloads\\user_trade_2020-12-23.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("Trade");
		String Id = null;
		String OrderedOn = null;
		String OrderedOns = null;
		String Pair = null;
		String Buyer = null;
		String Seller = null;
		String Price = null;
		String Amount = null;
		String Total = null;
		String Status = null;
		String BuyFees = null;
		String SellFess = null;

		
		// creating an instance of HSSFWorkbook class
		File files = new File(filename);
		Boolean File = files.exists();
		System.out.println(File);
		if (!files.exists()) {
			// Create file system using specific name
			FileOutputStream out = new FileOutputStream(new File(filename));
			sheets = workbook.createSheet("Result Trade"); 
			HSSFRow rowhead = sheets.createRow((short) 0);
			rowhead.createCell(0).setCellValue("Id");
			rowhead.createCell(1).setCellValue("Ordered On");
			rowhead.createCell(2).setCellValue("Pair");
			rowhead.createCell(3).setCellValue("Buyer");
			rowhead.createCell(4).setCellValue("Seller");
			rowhead.createCell(5).setCellValue("Price");
			rowhead.createCell(6).setCellValue("Amount");
			rowhead.createCell(7).setCellValue("BuyFees");
			rowhead.createCell(8).setCellValue("SellFess");
			rowhead.createCell(9).setCellValue("Total");
			rowhead.createCell(10).setCellValue("Status");
			System.out.println("createworkbook.xlsx written successfully");
		}
		else {
		
		sheets = workbook.createSheet("Result Trade"); 
		HSSFRow rowhead = sheets.createRow((short) 0);
		rowhead.createCell(0).setCellValue("Id");
		rowhead.createCell(1).setCellValue("Ordered On");
		rowhead.createCell(2).setCellValue("Pair");
		rowhead.createCell(3).setCellValue("Buyer");
		rowhead.createCell(4).setCellValue("Seller");
		rowhead.createCell(5).setCellValue("Price");
		rowhead.createCell(6).setCellValue("Amount");
		rowhead.createCell(7).setCellValue("BuyFees");
		rowhead.createCell(8).setCellValue("SellFess");
		rowhead.createCell(9).setCellValue("Total");
		rowhead.createCell(10).setCellValue("Status");
		}
		ArrayList<String> ExList = new ArrayList<String>();
		try {

			for (int l = 1; l < sheet.getRows(); l++) {

				Id = sheet.getCell(0, l).getContents();
				OrderedOn = sheet.getCell(1, l).getContents();
				OrderedOns = sheet.getCell(1, l + 1).getContents();

				String[] parts = OrderedOns.split(":");
				String part1 = parts[0]; // 004
				String part2 = parts[1];

				if (OrderedOn.contains(part1 + ":" + part2)) {
System.out.println(OrderedOn +" "+part1 + ":" + part2);
					Pair = sheet.getCell(2, l).getContents();
					Buyer = sheet.getCell(3, l).getContents();
					Seller = sheet.getCell(4, l).getContents();
					Price = sheet.getCell(5, l).getContents();
					Amount = sheet.getCell(6, l).getContents();
					BuyFees = sheet.getCell(7, l).getContents();
					SellFess = sheet.getCell(8, l).getContents();
					Total = sheet.getCell(9, l).getContents();
					Status = sheet.getCell(10, l).getContents();
					String Ids = sheet.getCell(0, l + 1).getContents();
					String Pair1 = sheet.getCell(2, l + 1).getContents();
					String Buyer1 = sheet.getCell(3, l + 1).getContents();
					String Seller1 = sheet.getCell(4, l + 1).getContents();
					String Price1 = sheet.getCell(5, l + 1).getContents();
					String Amount1 = sheet.getCell(6, l + 1).getContents();
					String BuyFees1 = sheet.getCell(7, l).getContents();
					String SellFess1 = sheet.getCell(8, l).getContents();
					String Total1 = sheet.getCell(9, l + 1).getContents();
					String Status1 = sheet.getCell(10, l + 1).getContents();

					System.out.println(Id + " " + OrderedOn + " " + Pair + " " + Buyer + " " + Seller + " " + Price
							+ " " + Amount + " " + BuyFees + " " + SellFess + " " + Total + " " + Status);
					System.out.println(Ids + " " + OrderedOns + " " + Pair1 + " " + Buyer1 + " " + Seller1 + " "
							+ Price1 + " " + Amount1 + " " + BuyFees1 + " " + SellFess1 + " " + Total1 + " " + Status1);

					HSSFRow row = sheets.createRow((short)ExList.size()+1 );
					ExList.add(Id);
					row.createCell(0).setCellValue(Id);
					row.createCell(1).setCellValue(OrderedOn);
					row.createCell(2).setCellValue(Pair);
					row.createCell(3).setCellValue(Buyer);
					row.createCell(4).setCellValue(Seller);
					row.createCell(5).setCellValue(Price);
					row.createCell(6).setCellValue(Amount);
					row.createCell(7).setCellValue(BuyFees);
					row.createCell(8).setCellValue(SellFess);
					row.createCell(9).setCellValue(Total);
					row.createCell(10).setCellValue(Status);
					HSSFRow rows = sheets.createRow((short)ExList.size()+2 );
					rows.createCell(0).setCellValue(Ids);
					rows.createCell(1).setCellValue(OrderedOns);
					rows.createCell(2).setCellValue(Pair1);
					rows.createCell(3).setCellValue(Buyer1);
					rows.createCell(4).setCellValue(Seller1);
					rows.createCell(5).setCellValue(Price1);
					rows.createCell(6).setCellValue(Amount1);
					rows.createCell(7).setCellValue(BuyFees1);
					rows.createCell(8).setCellValue(SellFess1);
					rows.createCell(9).setCellValue(Total1);
					rows.createCell(10).setCellValue(Status1);
				}

			}
		} catch (Exception ex) {

			FileOutputStream fileOut = new FileOutputStream(filename);
			workbook.write(fileOut); // closing the Stream fileOut.close(); // closing
			workbook.close(); // prints the message on the console
			System.out.println("Excel file has been generated successfully.");

		}
	}
	@AfterTest()
	public void filewrite() throws IOException {
		FileOutputStream fileOut = new FileOutputStream(filename);
		workbook.write(fileOut); // closing the Stream fileOut.close(); // closing
		workbook.close(); // prints the message on the console
		System.out.println("Excel file has been generated successfully.");
	}
}