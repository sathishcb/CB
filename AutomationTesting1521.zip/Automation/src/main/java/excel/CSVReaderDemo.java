package excel;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

public class CSVReaderDemo {
	 
	public static void main(String[] args) throws IOException, CsvException {
		
		String path = "C:\\\\Users\\\\Tester-Sathishkumar\\\\Desktop\\\\SBX\\\\28-11-2020\\\\user_orders.csv";
		
		Reader reader = new FileReader(path);
	
		CSVReader csvreader = new CSVReader(reader);
		
		List<String[]> list = csvreader.readAll();
		
		Iterator<String[]>ite= list.iterator();
		
		while(ite.hasNext()){
			String[] data = ite.next();
			for(int i=0; i<data.length; i++){
				System.out.println(data[i]);
			}
		}
	}
 
}