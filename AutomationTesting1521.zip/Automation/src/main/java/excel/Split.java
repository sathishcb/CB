package excel;

import org.testng.annotations.Test;

public class Split {
	@Test()
	public void splitstring() {
		 String string = "2020-12-23 12:14:09";
		 String[] parts = string.split(":");
		 String part1 = parts[0]; // 004
		 String part2 = parts[1];
		 System.out.println(part1);
		 System.out.println(part2);
		 if(string.contains(part1+":"+part2)) {
			 System.out.println(part1+":"+part2);
		 }
		
	}

}
