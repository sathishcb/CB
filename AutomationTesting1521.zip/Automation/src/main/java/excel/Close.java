package excel;

import java.io.FileOutputStream;
import java.io.IOException;

import org.testng.annotations.Test;

public class Close extends DynamicReport {
	@Override
	@Test(priority = 4)

	public void closeExcel() throws IOException {
		FileOutputStream fileOut = new FileOutputStream(filename);
		workbook.write(fileOut);
		// closing the Stream
		fileOut.close();
		// closing the workbook
		workbook.close();
	}

}
