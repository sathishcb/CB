package sikulis;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class MultipleImportTRX {

	String reportFilepath = System.getProperty("user.dir");

	@Test
	public void TRXImport() throws BiffException, IOException, InterruptedException, AWTException, HeadlessException,
			UnsupportedFlavorException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-web-security");
		options.addArguments("--allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.addArguments("--start-maximized");
		options.addExtensions(
				new File("C:\\Users\\Tester-Sathishkumar\\Downloads\\ibnejdfjmmkpcnlpebklmnkoeoihofec (1).crx"));
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		// driver.get("https://www.google.com/");
		driver.get("chrome-extension://ibnejdfjmmkpcnlpebklmnkoeoihofec/packages/popup/build/index.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/div[1]/input")).sendKeys("Osiz@123");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[2]/div[1]/input")).sendKeys("Osiz@123");

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/button")).click();

		String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w;
		w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("List");
		WebDriverWait wait = new WebDriverWait(driver, 10);
		for (int j = 1; j < sheet.getRows(); j++) {
			String FileName = sheet.getCell(1, j).getContents();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div/input")).sendKeys("TestOsiz");

			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button")).click();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]")).click();

			int lines = 1;
			String filename = reportFilepath + "\\" + FileName + ".txt";
			BufferedReader br = new BufferedReader(new FileReader(filename));
			String st;
			LineNumberReader count = new LineNumberReader(br);
			while ((st = br.readLine()) != null) {
				if (lines != 12) {
					System.out.print(st.toString() + " ");

					driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/textarea"))
							.sendKeys(st.toString() + " ");
					lines++;
				} else {
					driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/textarea"))
							.sendKeys(st.toString());
				}
			}
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[4]/button")).click();

			List<WebElement> NewAddress = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div"));

			for (int l = 0; l < NewAddress.size(); l++) {
				WebElement Check = NewAddress.get(l);
				Check.click();

			}
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/button")).click();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[1]/div/div[2]/div[3]/div[3]")).click();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div[3]/div")).click();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div[5]")).click();

			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div[1]")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div[1]")).click();

			if (j == 1) {
				driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div/img")).click();
				driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[2]/div[1]/div[1]")).click();
			}
			System.out.println(FileName);
			wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[1]/div[2]")));
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[1]/div[2]"))
					.click();

		}
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]")).click();
		String ListXpath = "//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[3]/div";
		List<WebElement> ListAddress = driver.findElements(By.xpath(ListXpath));
		String filenames = reportFilepath + "\\TRX Address2.txt";
		File myObj = new File(filenames);
		myObj.createNewFile();
		FileWriter myWriters = new FileWriter(filenames);

		for (int l = 1; l <= ListAddress.size(); l++) {
			WebElement Check = driver.findElement(By.xpath(ListXpath + "[" + l + "]/div[2]/div/span"));
			Check.click();
			Thread.sleep(500);
			String myText = (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
			myWriters.write(myText + '\n');

		}
		// *[@id="root"]/div/div/div/div/div[2]/div[1]/div[1]/div[3]/div[k]/div[2]/div/span
		myWriters.close();
	}
}