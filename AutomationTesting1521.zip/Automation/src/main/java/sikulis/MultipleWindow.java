package sikulis;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.read.biff.BiffException;

public class MultipleWindow {
	@Test()
	public void broswerLaunch() throws BiffException, IOException, InterruptedException, AWTException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-web-security");
		options.addArguments("--allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.addArguments("--start-maximized");
		options.addExtensions(
				new File("C:\\Users\\Tester-Sathishkumar\\Downloads\\nkbihfbeogaeaoehlefnkodbefgpgknn (1).crx"));
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn/home.html#initialize/select-action");
		// driver.get("https://www.google.com/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"app-content\"]/div/div[3]/div/div/div[2]/div/div[2]/div[2]/button"))
				.click();
		/*
		 * driver.findElement(By.xpath(
		 * "/html/body/div[1]/div/div[3]/div/div/div/div[5]/div[1]/footer/button[2]")).
		 * click();
		 * driver.findElement(By.xpath("//*[@id=\"create-password\"]")).sendKeys(
		 * "Osiz@123");
		 * driver.findElement(By.xpath("//*[@id=\"confirm-password\"]")).sendKeys(
		 * "Osiz@123"); driver.findElement(By.xpath(
		 * "//*[@id=\"app-content\"]/div/div[3]/div/div/div[2]/form/div[3]/div")).click(
		 * ); driver.findElement(By.xpath(
		 * "//*[@id=\"app-content\"]/div/div[3]/div/div/div[2]/form/button")).click();
		 * driver.findElement(By.xpath(
		 * "//*[@id=\"app-content\"]/div/div[3]/div/div/div[2]/div[2]/button[1]")).click
		 * (); driver.findElement(By.xpath(
		 * "//*[@id=\"popover-content\"]/div/div/section/header/div/button")).click();
		 * driver.findElement(By.xpath(
		 * "//*[@id=\"app-content\"]/div/div[1]/div/div[2]/div[1]/div/div/div[3]")).
		 * click(); driver.findElement(By.xpath(
		 * "//*[@id=\"app-content\"]/div/div[3]/div/li[2]/span")).click();
		 */
		((JavascriptExecutor) driver).executeScript("window.open('https://google.com')");
		String parent = driver.getWindowHandle();

		Set<String> s = driver.getWindowHandles();

		// Now iterate using Iterator
		Iterator<String> I1 = s.iterator();
		String child_window = null;
		while (I1.hasNext()) {

			child_window = I1.next();

			if (!parent.equals(child_window)) {
				driver.switchTo().window(child_window);

				System.out.println(driver.switchTo().window(child_window).getTitle());

			}
		}
		driver.switchTo().window(parent);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div/div/div/div[5]/div[1]/footer/button[2]")).click();
		driver.switchTo().window(child_window);
		System.out.println(driver.switchTo().window(child_window).getTitle());
	}

}
