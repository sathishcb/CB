package sikulis;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AddTrxBalance {
	String reportFilepath = System.getProperty("user.dir");

	@Test()
	public void balance() throws IOException {
		String FileName = "TRX Address";

		String filename = reportFilepath + "\\" + FileName + ".txt";
		BufferedReader br = new BufferedReader(new FileReader(filename));
		String st;
		LineNumberReader count = new LineNumberReader(br);
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-web-security");
		options.addArguments("--allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.addArguments("--start-maximized");
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://nileex.io/join/getJoinPage");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		while ((st = br.readLine()) != null) {
			driver.findElement(By.xpath("//*[@id=\"getCoinAddress\"]")).sendKeys(st.toString());
		}

	}
}