package sikulis;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.read.biff.BiffException;

public class Getmetamasks {
	String reportFilepath = System.getProperty("user.dir");

	@Test(enabled = false)
	public void broswerLaunch() throws BiffException, IOException, InterruptedException, AWTException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-web-security");
		options.addArguments("--allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.addArguments("--start-maximized");
		options.addExtensions(
				new File("C:\\Users\\Tester-Sathishkumar\\Downloads\\nkbihfbeogaeaoehlefnkodbefgpgknn (1).crx"));
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn/home.html#initialize/select-action");
		// driver.get("https://www.google.com/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"app-content\"]/div/div[3]/div/div/div[2]/div/div[2]/div[2]/button"))
				.click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div/div/div/div[5]/div[1]/footer/button[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"create-password\"]")).sendKeys("Osiz@123");
		driver.findElement(By.xpath("//*[@id=\"confirm-password\"]")).sendKeys("Osiz@123");
		driver.findElement(By.xpath("//*[@id=\"app-content\"]/div/div[3]/div/div/div[2]/form/div[3]/div")).click();
		driver.findElement(By.xpath("//*[@id=\"app-content\"]/div/div[3]/div/div/div[2]/form/button")).click();
		driver.findElement(By.xpath("//*[@id=\"app-content\"]/div/div[3]/div/div/div[2]/div[2]/button[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"popover-content\"]/div/div/section/header/div/button")).click();
		driver.findElement(By.xpath("//*[@id=\"app-content\"]/div/div[1]/div/div[2]/div[1]/div/div/div[3]")).click();
		driver.findElement(By.xpath("//*[@id=\"app-content\"]/div/div[3]/div/li[2]/span")).click();
	}

	@Test(enabled = true)
	public void TRXImport() throws BiffException, IOException, InterruptedException, AWTException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-web-security");
		options.addArguments("--allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.addArguments("--start-maximized");
		options.addExtensions(
				new File("C:\\Users\\Tester-Sathishkumar\\Downloads\\ibnejdfjmmkpcnlpebklmnkoeoihofec (1).crx"));
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		// driver.get("https://www.google.com/");
		driver.get("chrome-extension://ibnejdfjmmkpcnlpebklmnkoeoihofec/packages/popup/build/index.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/div[1]/input")).sendKeys("Osiz@123");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[2]/div[1]/input")).sendKeys("Osiz@123");

		driver.findElement(By.xpath("	//*[@id=\"root\"]/div/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[1]")).click();

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div/input")).sendKeys("TestOsiz");
		// *[@id="root"]/div/div[3]/div/div/input
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button")).click();
		// driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[1]")).click();
		List<WebElement> getword = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div"));
		System.out.println(getword.size());
		String filename = reportFilepath + "\\TestOsiz9.txt";
		FileWriter myWriter = new FileWriter(filename);
		ArrayList<String> PharseList = new ArrayList<String>();
		for (int l = 0; l < getword.size(); l++) {

			WebElement Result = getword.get(l);
			String FResult = Result.getText().trim();

			File myObj = new File(filename);

			if (myObj.createNewFile()) {
				System.out.println("File created: " + myObj.getName());
				System.out.println(l);
				myWriter.write(FResult + '\n');
				PharseList.add(FResult);

			} else {
				System.out.println("File already exists.");
				System.out.println(l);
				myWriter.write(FResult + '\n');
				PharseList.add(FResult);

			}

		}
		myWriter.close();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/button")).click();
		List<WebElement> Resultgetword = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[4]/div"));
		System.out.println(Resultgetword.size());
		for (int l = 0; l < PharseList.size(); l++) {

			String NextScreenPhare = PharseList.get(l).toString();
			for (int k = 0; k < Resultgetword.size(); k++) {
				WebElement Check = Resultgetword.get(k);

				String ClickResult = Check.getText().trim();

				if (NextScreenPhare.contentEquals(ClickResult)) {

					System.out.println(NextScreenPhare);
					System.out.println(ClickResult);
					Check.click();
				}
			}

		}
		driver.findElement(By.xpath("//*[@id='root']/div/div[2]/div[5]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[2]/div[1]/div[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[1]/div[2]/span"))
				.click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div/input")).sendKeys("TestOsiz2");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]")).click();

		int lines = 1;

		BufferedReader br = new BufferedReader(new FileReader(filename));
		String st;
		LineNumberReader count = new LineNumberReader(br);
		while ((st = br.readLine()) != null) {
			if (lines != 12) {
				System.out.print(st.toString() + " ");

				driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/textarea"))
						.sendKeys(st.toString() + " ");
				lines++;
			} else {
				driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/textarea")).sendKeys(st.toString());
			}
		}
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[4]/button")).click();

		List<WebElement> NewAddress = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div"));

		for (int l = 0; l < NewAddress.size(); l++) {
			WebElement Check = NewAddress.get(l);
			Check.click();

		}
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/button")).click();
		
		
		
		// driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button/span")).click();
		// driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]")).click();

		// driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/textarea")).sendKeys("35efe13eac9712fe6a4673f4a10ff455f124177c0f7f5ca9071a8f469d6a63b8");
		// driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/button/span")).click();

	}

}
