package sikulis;

import java.awt.AWTException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ImportTRX {

	String reportFilepath = System.getProperty("user.dir");

	@Test
	public void TRXImport() throws BiffException, IOException, InterruptedException, AWTException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-web-security");
		options.addArguments("--allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.addArguments("--start-maximized");
		options.addExtensions(
				new File("C:\\Users\\Tester-Sathishkumar\\Downloads\\ibnejdfjmmkpcnlpebklmnkoeoihofec (1).crx"));
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		// driver.get("https://www.google.com/");
		driver.get("chrome-extension://ibnejdfjmmkpcnlpebklmnkoeoihofec/packages/popup/build/index.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/div[1]/input")).sendKeys("Osiz@123");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[2]/div[1]/input")).sendKeys("Osiz@123");

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/button")).click();

		String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w;
		w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("List");
		WebDriverWait wait = new WebDriverWait(driver, 10);
		for (int j = 1; j < sheet.getRows(); j++) {
			String FileName = sheet.getCell(1, j).getContents();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div/input")).sendKeys("TestOsiz");

			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button")).click();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]")).click();

			int lines = 1;
			String filename = reportFilepath + "\\" + FileName + ".txt";
			BufferedReader br = new BufferedReader(new FileReader(filename));
			String st;
			LineNumberReader count = new LineNumberReader(br);
			while ((st = br.readLine()) != null) {
				if (lines != 12) {
					System.out.print(st.toString() + " ");

					driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/textarea"))
							.sendKeys(st.toString() + " ");
					lines++;
				} else {
					driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/textarea"))
							.sendKeys(st.toString());
				}
			}
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[4]/button")).click();

			List<WebElement> NewAddress = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div"));

			for (int l = 0; l < NewAddress.size(); l++) {
				WebElement Check = NewAddress.get(l);
				Check.click();

			}
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/button")).click();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[1]/div/div[2]/div[3]/div[3]")).click();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div[3]/div")).click();
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div[5]")).click();

			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div[1]")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div[1]")).click();

			if (j == 1) {
				driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div/img")).click();
			}

			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[2]/div[1]/div[1]")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[1]/div[2]")));
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[1]/div[2]"))
					.click();
			// *[@id="root"]/div/div/div/div/div[2]/div[1]/div[1]/div[3]/div
			/*
			 * List<WebElement> Resultgetword = driver .findElements(By.xpath(
			 * "//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[3]/div")); for
			 * (int k = 0; k < 2; k++) { WebElement Check = Resultgetword.get(k);
			 * 
			 * String ClickResult = Check.getText().trim(); System.out.println(ClickResult);
			 * Check.click();
			 * 
			 * String Result = driver .findElement(By.xpath(
			 * "//*[@id=\"root\"]/div/div/div/div/div[2]/div[2]/div[2]/span[1]")).getText()
			 * .trim(); System.out.println(Result);
			 * 
			 * 
			 * ((JavascriptExecutor) driver).executeScript(
			 * "window.open('https://mlm_php.osiztechnologies.in/en/earnMoney')"); String
			 * parent = driver.getWindowHandle();
			 * 
			 * Set<String> s = driver.getWindowHandles();
			 * 
			 * // Now iterate using Iterator Iterator<String> I1 = s.iterator(); String
			 * child_window = null; while (I1.hasNext()) {
			 * 
			 * child_window = I1.next();
			 * 
			 * if (!parent.equals(child_window)) { driver.switchTo().window(child_window);
			 * 
			 * System.out.println(driver.switchTo().window(child_window).getTitle());
			 * 
			 * driver.findElement(By.xpath(
			 * "//*[@id=\"page-top\"]/section[1]/div/div/div/div/button")).click();
			 * driver.findElement(By.xpath("//*[@id=\"referrer_value\"]")).sendKeys("");
			 * 
			 * String Add=driver.findElement(By.xpath(
			 * "//*[@id=\"register_form\"]/div[2]/div[1]/div/div/p")).getText().trim();
			 * driver.findElement(By.xpath("//*[@id=\"captcha\"]")).sendKeys("");
			 * 
			 * driver.findElement(By.xpath("//*[@id=\"regis\"]")).click();
			 * 
			 * driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[5]/button[2]")).
			 * click();
			 * 
			 * 
			 * } } driver.switchTo().window(parent);
			 * 
			 * driver.switchTo().window(child_window);
			 * System.out.println(driver.switchTo().window(child_window).getTitle());
			 * 
			 * driver.findElement(By.xpath(
			 * "//*[@id=\"root\"]/div/div/div/div/div[2]/div[2]/div[1]/div[1]")).click();
			 * 
			 * }
			 */
		}
	}
}