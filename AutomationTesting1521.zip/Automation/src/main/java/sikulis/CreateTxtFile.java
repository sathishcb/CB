package sikulis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Scanner;

import org.testng.annotations.Test;

public class CreateTxtFile {
	String reportFilepath = System.getProperty("user.dir");
	String filename = reportFilepath + "\\TestOsiz.txt";

	@Test()
	public void createtxt() {
		try {
			File myObj = new File(filename);
			if (myObj.createNewFile()) {
				System.out.println("File created: " + myObj.getName());
				FileWriter myWriter = new FileWriter(filename);
				myWriter.write("Files in Java might be tricky, but it is fun enough!");
				myWriter.close();
			} else {
				System.out.println("File already exists.");

				File myObjs = new File(filename);
				BufferedReader br = new BufferedReader(new FileReader(filename));
				String st;
				System.out.println();
				int lines = 1;
				LineNumberReader count = new LineNumberReader(br);

				while ((st = br.readLine()) != null) {
					if(lines!=12) {
					System.out.print(st.toString()+" ");
					lines++;
					}
				else {
					System.out.print(st.toString());
				}
				}
				// myWriter.write("Files in Java might be tricky, but it is fun enough!");
				// myWriter.close();

				/*
				 * if (myObjs.exists()) { System.out.println("File name: " + myObjs.getName());
				 * System.out.println("Absolute path: " + myObjs.getAbsolutePath());
				 * System.out.println("Writeable: " + myObjs.canWrite());
				 * System.out.println("Readable " + myObjs.canRead());
				 * System.out.println("File size in bytes " + myObjs.length());
				 * 
				 * } else { System.out.println("The file does not exist."); }
				 */

			}
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
}
