package datadriven;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import com.pack.preserve.ListExcel;

public class HtmlUnitBrowser {
	@Test
	public void Thai() {
		// Creating a new instance of the HTML unit driver

		// WebDriver driver = new HtmlUnitDriver();

		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();

		// driver.get("https://walkexlamp.osiztechnologies.in/login");
		// Navigate to Google
		driver.get("https://www.grootan.com/team");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Locate the searchbox using its name
		ArrayList<String> JuniorList = new ArrayList<String>();
		List<WebElement> element = driver
				.findElements(By.xpath("//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div"));

		for (int i = 1; i <= element.size(); i++) {
			List<WebElement> element1 = driver.findElements(
					By.xpath("//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div" + "[" + i + "]/div"));
			for (int j = 1; j <= element1.size(); j++) {
				try {
					WebElement Name = driver
							.findElement(By.xpath("//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div" + "[" + i
									+ "]/div" + "[" + j + "]/h3"));
					WebElement Prof = driver
							.findElement(By.xpath("//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div" + "[" + i
									+ "]/div" + "[" + j + "]/h5"));
					boolean check = Name.isDisplayed();
					if (check == true) {
						String Result = Name.getText().trim();
						String ProfResult = Prof.getText().trim();
						System.out.println(Result + "---->" + ProfResult);
						if (ProfResult.contains("Junior")) {
							JuniorList.add(Result);

						}
					}
				}

				catch (Exception ex) {

				}
			}

		}
		System.out.println(JuniorList.toString());
		ListExcel lis=new ListExcel();
		lis.ListData(JuniorList, "ResultReport", "Junior Engineers");
		
	}
}
