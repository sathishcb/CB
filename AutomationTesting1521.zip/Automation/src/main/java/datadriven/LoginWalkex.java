package datadriven;

import java.awt.AWTException;

/**
 * @author Sathish Kumar CB 
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import launch.Utility;
import walkexBase.ExtentTestManager;

/**
 * This class consists of steps of Login process
 */

public class LoginWalkex {

	String UserNameXpath = "//*[@id=\"email\"]";
	String PasswordXpath = "//*[@id=\"password\"]";
	String LoginButtonXpath = "//*[@id=\"login_submit\"]";
	String EmailError = "//*[@id=\"email-error\"]";
	String PasswordError = "//*[@id=\"password-error\"]";
	String NotificationError = "//*[@id=\"ui_notifIt\"]";

	@Test
	public void Walkex_Login_Scenarios() throws BiffException, IOException, InterruptedException, AWTException {
		try {
			String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\sathish.xls";
			String sheets = "Login";
			FileInputStream file = new FileInputStream(new File(filePath));
			Workbook w;
			w = Workbook.getWorkbook(file);
			Sheet sheet = w.getSheet(sheets);
			WebDriverWait wait = new WebDriverWait(Launch.getDriver(), 30);

			for (int j = 1; j < sheet.getRows(); j++) {
				String scine = sheet.getCell(1, j).getContents();
				String username = sheet.getCell(2, j).getContents();
				String password = sheet.getCell(3, j).getContents();
				String uError = sheet.getCell(4, j).getContents();
				String pError = sheet.getCell(5, j).getContents();
				String nError = sheet.getCell(6, j).getContents();
				System.out.println(j + "=" + scine);
				System.out.println("UserName :" + username);
				System.out.println("Password :" + password);
				System.out.println("Error Msg 1 : " + uError);
				System.out.println("Error Msg 2 : " + pError);
				System.out.println("Error Noti : " + nError);

				WebElement Un = null;
				WebElement Pa = null;
				WebElement No = null;
				WebElement Ee = null;
				WebElement Pe = null;
				String ScreenNotification = "";
				String ScreenUsernameError = "";
				String ScreenPasseordError = "";
				Thread.sleep(5000);
				ExtentTestManager.getTest().log(Status.INFO, "Login Scenarios : " + scine + "   Login Details " + j
						+ " UserName :" + username +"/"+ "Password :" + password);

				if (username != null && username != "") {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(UserNameXpath)));
					Un = Launch.getDriver().findElement(By.xpath(UserNameXpath));
					Un.sendKeys(username);
					Thread.sleep(500);
				}
				if (password != null && password != "") {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PasswordXpath)));
					Pa = Launch.getDriver().findElement(By.xpath(PasswordXpath));
					Pa.sendKeys(password);
					Thread.sleep(500);
				}
				Launch.getDriver().findElement(By.xpath(LoginButtonXpath)).click();
				if (uError != null && uError != "") {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(EmailError)));
					Ee = Launch.getDriver().findElement(By.xpath(EmailError));
					ScreenUsernameError = Ee.getText().trim();
					Thread.sleep(500);
					String temp = Utility.getScreenshot(Launch.getDriver());
					try {
						Assert.assertEquals(ScreenUsernameError, uError);
						ExtentTestManager.getTest().log(Status.PASS,
								" Actual Username Error :" + ScreenUsernameError +"/"+ " Expected Username Error : " + uError,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
					} catch (AssertionError ex) {
						ExtentTestManager.getTest().log(Status.FAIL,
								" Actual Username Error : " + ScreenUsernameError +"/"+ " Expected Username Error : " + uError
								+"/"+ "Notification Error :" + ScreenNotification,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
					}

				}
				if (pError != null && pError != "") {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PasswordError)));
					Pe = Launch.getDriver().findElement(By.xpath(PasswordError));
					ScreenPasseordError = Pe.getText().trim();
					Thread.sleep(500);
					String temp = Utility.getScreenshot(Launch.getDriver());
					try {

						Assert.assertEquals(ScreenPasseordError, pError);
						ExtentTestManager.getTest()
								.log(Status.PASS, " Expected Password Error : " + ScreenPasseordError
										+"/"+ " Expected Password Error : " + pError,
										MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
					} catch (AssertionError ex) {
						ExtentTestManager.getTest()
								.log(Status.FAIL, " Expected Password Error :" + ScreenPasseordError
										+"/"+ " Expected Password Error : " + pError,
										MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
					}
				}
				if (nError != null && nError != "") {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(NotificationError)));
					No = Launch.getDriver().findElement(By.xpath(NotificationError));
					ScreenNotification = No.getText().trim();
					Thread.sleep(500);
					String temp = Utility.getScreenshot(Launch.getDriver());
					try {
						Assert.assertEquals(ScreenNotification, nError);
						ExtentTestManager.getTest().log(
								Status.PASS, " Expected Notification Error : " + ScreenNotification
								+"/"+ " Expected Notification Error : " + nError,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
					} catch (AssertionError ex) {
						ExtentTestManager.getTest().log(
								Status.FAIL, " Expected Notification Error : " + ScreenNotification
								+"/"+ " Expected Notification Error : " + nError,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
					}
				}

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(UserNameXpath)));
				Un = Launch.getDriver().findElement(By.xpath(UserNameXpath));
				Un.clear();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PasswordXpath)));
				Pa = Launch.getDriver().findElement(By.xpath(PasswordXpath));
				Pa.clear();
				Actions actions = new Actions(Launch.getDriver());
				actions.sendKeys(Keys.F5);
				Thread.sleep(2000);
			}

		}

		catch (Exception ex) {
			System.out.println(ex);
		}

	}
}