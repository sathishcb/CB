package walkexBase;

import java.util.Collections;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {

	public static WebDriver driver;
	public WebDriver getDriver() {
		return driver;
	}

	private void setDriver(String browserType, String appURL) {
		switch (browserType) {
		case "chrome":
			driver = initChromeDriver(appURL);
			break;
		case "firefox":
			driver = initFirefoxDriver(appURL);
			break;
		default:
			System.out.println("browser : " + browserType + " is invalid, Launching Firefox as browser of choice..");
			driver = initFirefoxDriver(appURL);
		}
	}

	private static WebDriver initChromeDriver(String appURL) {
		System.out.println("Launching google chrome with new profile..");
	//	System.setProperty("webdriver.chrome.driver", driverPath + "chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}

	private static WebDriver initFirefoxDriver(String appURL) {
		System.out.println("Launching Firefox browser..");
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}
	public static void waitForElementPresence(WebElement locator) throws InterruptedException {
	    WebDriverWait wait = new WebDriverWait(driver, 300);
	    Thread.sleep(2000);
	    wait.until(ExpectedConditions.visibilityOf(locator));
	}
	
	public static void elementToBeClick(WebElement locator) throws InterruptedException {
	    WebDriverWait wait = new WebDriverWait(driver, 300);
	    Thread.sleep(3000);
	    wait.until(ExpectedConditions.visibilityOf(locator));
	}
	
	public static void invisibility(WebElement locator) throws InterruptedException {
	    WebDriverWait wait = new WebDriverWait(driver, 300);
	    Thread.sleep(3000);
	    wait.until(ExpectedConditions.invisibilityOf(locator));
	}
	
	public static void scrollDown(WebElement locator) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(3000);
		js.executeScript("arguments[0].scrollIntoView();", locator);
	}
	
	public static void sleepM() throws InterruptedException {
		Thread.sleep(7000);
	}
	
	public void waitforEle() throws InterruptedException {
		Thread.sleep(3000);
	}
	@Parameters({ "browserType", "appURL" })
	@BeforeClass
	public void initializeTestBaseSetup(String browserType, String appURL) {
		try {
			setDriver(browserType, appURL);

		} catch (Exception e) {
			System.out.println("Error....." + e.getStackTrace());
		}
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}