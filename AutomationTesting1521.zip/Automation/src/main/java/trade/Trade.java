package trade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import commonFuncation.DataCollection;
import commonFuncation.SelWebDriverMethods;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import launch.Utility;
import walkexBase.ExtentTestManager;

public class Trade {
	/** Object Creation **/

	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	String readexcel = "C:\\Users\\Tester-Sathishkumar\\Desktop\\WalkexXpath.xls";
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Trade");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Trade");

	@Test(priority=3)
	public void TradePageButton() throws IOException, BiffException {
		/** Declaring & Initializing variables **/
		/*** Element locator & Control name collection ***/
		sel.seleniumAction(controlname.get("Tdrop"), "Click", "id", elelocators.get("Tdrop"), "");
		sel.seleniumAction(controlname.get("Trade Button"), "Click", "xpath", elelocators.get("Trade Button"), "");
		String Url = null;
		Url = sel.getCurrentUrl();
		String status = sel.assertequalandwriteresult(Url, Url);
		String temp = Utility.getScreenshot(BrowserLaunch.getDriver());

		if (status == "Pass") {
			ExtentTestManager.getTest().log(Status.PASS, " Actual Url  :" + Url + "/" + " Expected Url  : " + Url,
					MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		} else {
			ExtentTestManager.getTest().log(Status.FAIL, " Actual Url  :" + Url + "/" + " Expected Url  : " + Url,
					MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		}

	}

	@Test(priority=4)
	public void SelectPair() throws IOException, BiffException, InterruptedException {
		/** Declaring & Initializing variables **/
		/*** Element locator & Control name collection ***/
		String status = null;
		String sstatus = null;
		String pair2 = null;
		String pair = null;
		WebDriverWait wait = new WebDriverWait(BrowserLaunch.getDriver(), 20);
		String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w;
		w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("Trade Pair");
		for (int l = 1; l < sheet.getRows(); l++) {
			String Pair = sheet.getCell(1, l).getContents();
			String PairList = sheet.getCell(2, l).getContents();
			List<WebElement> lis = sel.getList(controlname.get("Pair"), elelocators.get("Pair"));
			for (int i = 1; i <= lis.size(); i++) {
				System.out.println(lis.size());
				
				WebElement result = lis.get(i);
				pair = result.getText().trim();
				try {
					assertEquals(pair, Pair);
					Thread.sleep(1000);
					result.click();
					status = "Pass";
					int k = i + 1;
					List<WebElement> lis2 = BrowserLaunch.getDriver().findElements(
							By.xpath(elelocators.get("Pair") + "[" + k + "]" + elelocators.get("Pair List")));

					for (int j = 0; j < lis2.size(); j++) {
						// Thread.sleep(5000);
						WebElement resultpair = lis2.get(j);
						pair2 = resultpair.getText().trim();
						System.out.println(pair2);
						try {
							assertTrue(pair2.contains(PairList));
							resultpair.click();
							sstatus = "Pass";
							Thread.sleep(2000);
							String temp = Utility.getScreenshot(BrowserLaunch.getDriver());
							ExtentTestManager.getTest().log(Status.PASS, "Actual Pair:" + pair + "/n" + "Expected Pair: " + Pair);
							ExtentTestManager.getTest().log(Status.PASS,
									"Actual Pair List  :" + pair2 + "/" + "Expected Pair List  : " + PairList,
									MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
							break;
						} catch (AssertionError e) {
						}
						if (sstatus == "Pass") {
							System.out.println("ss Break");
							break;
						} else if (sstatus != null) {
							String temp = Utility.getScreenshot(BrowserLaunch.getDriver());
							ExtentTestManager.getTest().log(Status.FAIL,
									"Actual Pair List  :" + pair2 + "/" + "Expected Pair List  : " + PairList,
									MediaEntityBuilder.createScreenCaptureFromPath(temp).build());

						}
					}
				} catch (AssertionError e) {

				}

				if (status == "Pass") {
					System.out.println("Break");

					break;

				} else if (status != null) {
					String temp = Utility.getScreenshot(BrowserLaunch.getDriver());
					ExtentTestManager.getTest().log(Status.FAIL,
							"Actual Pair List  :" + pair + "/" + "Expected Pair List  : " + Pair,
							MediaEntityBuilder.createScreenCaptureFromPath(temp).build());

				}
			}
		}

	}
}
