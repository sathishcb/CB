package trade;

import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import api.WalkexApi;
import commonFuncation.DataCollection;
import commonFuncation.SelWebDriverMethods;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import launch.Utility;
import walkexBase.ExtentTestManager;

public class Login {
	/** Object Creation **/

	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	String readexcel = "C:\\Users\\Tester-Sathishkumar\\Desktop\\WalkexXpath.xls";
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Login");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Login");

	@Test(priority=1)
	public void verfiyTitle() throws IOException, BiffException {
		/** Declaring & Initializing variables **/
		/*** Element locator & Control name collection ***/

		String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w;
		w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("Login");
		for (int j = 1; j < sheet.getRows(); j++) {
			String username = sheet.getCell(1, j).getContents();
			String password = sheet.getCell(2, j).getContents();
			sel.seleniumAction(controlname.get("UserName"), "Type", "id", elelocators.get("UserName"), username);
			sel.seleniumAction(controlname.get("Password"), "Type", "id", elelocators.get("Password"), password);
			sel.seleniumAction(controlname.get("Login"), "Click", "id", elelocators.get("Login"), "");

			String Title = null;
			Title = sel.getTitle();
			sel.assertequalandwriteresult(Title, "Walkex");
			String temp = Utility.getScreenshot(BrowserLaunch.getDriver());
			ExtentTestManager.getTest().log(Status.PASS,
					" Actual Title  :" + Title + "/" + " Expected Title  : " + "Walkex",
					MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		}
	}

	@Test(priority=2)
	public void getOTP() throws IOException, BiffException {
		WalkexApi wa = new WalkexApi();
		String opt = wa.getOtp();
		System.out.println(opt);
		sel.seleniumAction(controlname.get("OTP"), "Type", "id", elelocators.get("OTP"), opt);
		sel.seleniumAction(controlname.get("Send"), "Click", "xpath", elelocators.get("Send"), "");
		String noti = sel.getText(controlname.get("Notification"), "xpath", elelocators.get("Notification"));
		sel.assertequalandwriteresult(noti, noti);
		String temp = Utility.getScreenshot(BrowserLaunch.getDriver());
		ExtentTestManager.getTest().log(Status.PASS,
				" Actual Notification  :" + noti + "/" + " Expected Notification  : " + noti,
				MediaEntityBuilder.createScreenCaptureFromPath(temp).build());

	}
}
