package TRX;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.read.biff.BiffException;

public class ImportTRXLiveWithTron {

	String reportFilepath = System.getProperty("user.dir");

	@Test
	public void TRXImport() throws BiffException, IOException, InterruptedException, AWTException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("disable-infobars");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-web-security");
		options.addArguments("--allow-running-insecure-content");
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.addArguments("--start-maximized");
		options.addExtensions(
				new File("C:\\Users\\Tester-Sathishkumar\\Downloads\\ibnejdfjmmkpcnlpebklmnkoeoihofec (1).crx"));
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		// driver.get("https://www.google.com/");
		driver.get("chrome-extension://ibnejdfjmmkpcnlpebklmnkoeoihofec/packages/popup/build/index.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div/a")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/div[1]/input")).sendKeys("Osiz@123");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[2]/div[1]/input")).sendKeys("Osiz@123");

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/button")).click();
		WebDriverWait wait = new WebDriverWait(driver, 20);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div/input")).sendKeys("TestOsiz");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]")).click();
		int lines = 1;
		String filename = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Osiz.txt";
		BufferedReader br = new BufferedReader(new FileReader(filename));
		String st;
		LineNumberReader count = new LineNumberReader(br);
		while ((st = br.readLine()) != null) {
			if (lines != 12) {
				System.out.print(st.toString() + " ");

				driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/textarea"))
						.sendKeys(st.toString() + " ");
				lines++;
			} else {
				driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/textarea")).sendKeys(st.toString());
			}
		}
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[4]/button")).click();

		List<WebElement> NewAddress = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div"));

		for (int l = 0; l < NewAddress.size(); l++) {
			WebElement Check = NewAddress.get(l);
			Check.click();

		}
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/button")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[1]/div/div[2]/div[3]/div[3]")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div[3]/div")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div[3]")).click();

		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div[1]")).click();

		driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div/img")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[2]/div[1]/div[1]")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[1]/div[2]")));
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/div[1]/div[1]/div[3]/div[1]")).click();
		((JavascriptExecutor) driver).executeScript(
				"window.open('https://livewithtron_demo.osiztechnologies.in/refer/TWXaUMXzR1qJxSPZ72LsiUX3n51VifZiAh')");
		String parent = driver.getWindowHandle();
		Set<String> s = driver.getWindowHandles();

		// Now iterate using Iterator
		Iterator<String> I1 = s.iterator();
		String child_window = null;
		String BeforeReject = null;

		while (I1.hasNext()) {

			child_window = I1.next();

			if (!parent.equals(child_window)) {
				driver.switchTo().window(child_window);

				System.out.println(driver.switchTo().window(child_window).getTitle());
				Thread.sleep(2000);
				BeforeReject = driver
						.findElement(By
								.xpath("//*[@id=\"wrapper\"]/div/div[3]/div[1]/div[2]/div/div[2]/div/form/div[5]/div"))
						.getText().trim();

				driver.findElement(By.xpath(
						"//*[@id=\"wrapper\"]/div/div[3]/div[1]/div[2]/div/div[2]/div/form/div[4]/div[1]/button"))
						.click();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@id=\"join\"]")).click();
				Thread.sleep(2000);

			}
		}

		driver.switchTo().window(parent);
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_F5);
		r.keyRelease(KeyEvent.VK_F5);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[5]/button[1]")).click();
		driver.switchTo().window(child_window);

		/*
		 * String op =
		 * driver.findElement(By.xpath("//*[@id=\"growls-default\"]/div/div[3]")).
		 * getText().trim(); System.out.println(op); driver.findElement(By.xpath(
		 * "//*[@id=\"wrapper\"]/div/div[3]/div[1]/div[2]/div/div[2]/div/form/div[5]/div"
		 * )).getText().trim();
		 */
		System.out.println(driver.getCurrentUrl());
		Thread.sleep(2000);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"wrapper\"]/div/div[3]/div[1]/div[2]/div/div[2]/div/form/div[5]/div")));
		WebElement AfterRejects = driver
				.findElement(By.xpath("//*[@id=\"wrapper\"]/div/div[3]/div[1]/div[2]/div/div[2]/div/form/div[5]/div"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", AfterRejects);
		Actions action = new Actions(driver);
		action.moveToElement(AfterRejects);
		String AfterReject = AfterRejects.getText().trim();
		System.out.println(driver.getCurrentUrl());
		try {
			assertEquals(BeforeReject, AfterReject);
			System.out.println(BeforeReject);
			System.out.println(AfterReject);
		} catch (AssertionError ex) {
			System.out.println(BeforeReject);
			System.out.println(AfterReject);
		}
	}
}