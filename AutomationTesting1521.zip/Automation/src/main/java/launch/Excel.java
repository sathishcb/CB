package launch;

import java.io.File;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import walkexlampPages.POM_Login;

public class Excel {
	static WebDriver driver;

	public Excel(WebDriver driver) {
		Excel.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@Test()
	public void excelLoop(String file, String sheet) {
		

		POM_Login cs = new POM_Login(driver);
		try {
			Workbook wb = WorkbookFactory.create(new File(file));
			Sheet st1 = wb.getSheet(sheet);
			for (int i = 1; i <= st1.getLastRowNum(); i++) {
				if (sheet.contentEquals("Login")) {
					Row row = st1.getRow(i);
					int colunmIndex = 0;
					Cell uname = row.getCell(++colunmIndex);
					Cell pass = row.getCell(++colunmIndex);
					String Runame = uname.toString();
					String Rpass = pass.toString();
					cs.setEmail(Runame);
					cs.setPassword(Rpass);
					
					break;
				} else {

				}
			}

		} catch (Exception ex) {

		}
	}

}