package trade;

import org.testng.annotations.Test;

public class BrowserLaunchTest {

  @Test
  public void GetOTPTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void TradePageButtonTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void broswerLaunchTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void getDriverTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void verfiyTitleTest() {
    throw new RuntimeException("Test not implemented");
  }
}
