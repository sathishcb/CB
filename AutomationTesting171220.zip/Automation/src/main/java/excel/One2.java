package excel;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.testng.annotations.Test;

public class One2 extends DynamicReport {
	@Test(priority=2)
	public void test2() throws IOException {
		HSSFSheet sheet = workbook.createSheet("Two");
		HSSFRow row = sheet.createRow((short) 1);
		// inserting data in the first row
		row.createCell(0).setCellValue("1");
		row.createCell(1).setCellValue("John William");
		row.createCell(2).setCellValue("9999999");
		row.createCell(3).setCellValue("william.john@gmail.com");
		row.createCell(4).setCellValue("700000.00");

		System.out.println("Excel file has been generated successfully.");
		FileOutputStream fileOut = new FileOutputStream(filename);
		workbook.write(fileOut);
		fileOut.close();
	}
}
