package excel;

import java.io.*;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class CreateSheet {
	public static void main(String[] args) throws FileNotFoundException, IOException {

		// Creating Workbook instances
		// Workbook wb = new HSSFWorkbook();

		// An output stream accepts output bytes and sends them to sink.
		// OutputStream fileOut = new
		// FileOutputStream("D:\\SATHISH\\Automation\\Automation\\Balance.xlsx");
		FileInputStream fileinp = new FileInputStream("D:\\SATHISH\\Automation\\Automation\\TestingReport.xlsx");
		HSSFWorkbook workbook = new HSSFWorkbook(fileinp);

		// Creating Sheets using sheet object
		Sheet sheet = workbook.getSheet("Januaryy");
		Row rowhead =null;
		int i=1;
		// creating the 0th row using the createRow() method
		
			rowhead = sheet.createRow((short)0);
			// rowhead = sheet.createRow(sheet.getLastRowNum()+i);
			System.out.println(sheet.getLastRowNum());
			rowhead.createCell(1).setCellValue("Rio");
			// creating cell by using the createCell() method and setting the values to the
			// cell by using the setCellValue() method
			// rowhead.createCell(0).setCellValue("S.No.");
			try {
				Boolean result = rowhead.createCell(i).getStringCellValue().isEmpty();
				System.out.println(result);
			} catch (Exception ex) {
				System.out.println(ex);
			}
		
		/*
		 * rowhead.createCell(1).setCellValue("Customer Name");
		 * rowhead.createCell(2).setCellValue("Account Number");
		 * rowhead.createCell(3).setCellValue("e-mail");
		 * rowhead.createCell(4).setCellValue("Balance");
		 */

		System.out.println("Sheets Has been Created successfully");
		FileOutputStream fileOut = new FileOutputStream("D:\\SATHISH\\Automation\\Automation\\TestingReport.xlsx");
		workbook.write(fileOut);
		fileOut.close();
		workbook.close();
	}
}