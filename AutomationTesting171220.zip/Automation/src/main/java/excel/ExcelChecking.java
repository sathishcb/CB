package excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelChecking {
	@Test()
	public void get() throws EncryptedDocumentException, IOException {

		String path = "D:\\SATHISH\\Automation\\Automation\\Balance.xlsx";
		FileInputStream fileinp = new FileInputStream(path);
		HSSFWorkbook workbook = new HSSFWorkbook(fileinp);
		//workbook.createSheet("Checking");
		//Sheet sheet3 = workbook.createSheet("Febs");
		Sheet sheet3 = null;
		DataFormatter fmt = new DataFormatter();

		for(int sn=0; sn<workbook.getNumberOfSheets(); sn++) {
		   Sheet sheet = workbook.getSheetAt(sn);
		   for (int rn=sheet.getFirstRowNum(); rn<=sheet.getLastRowNum(); rn++) {
		      Row row = sheet.getRow(rn);
		      if (row == null) {
		         // There is no data in this row, handle as needed
		    	  Row rowhead = sheet3.createRow((short) sn);
		  		// creating cell by using the createCell() method and setting the values to the
		  		// cell by using the setCellValue() method
		  		rowhead.createCell(0).setCellValue("S.No.");
		  		rowhead.createCell(1).setCellValue("Customer Name");
		  		rowhead.createCell(2).setCellValue("Account Number");
		  		rowhead.createCell(3).setCellValue("e-mail");
		  		rowhead.createCell(4).setCellValue("Balance"); 
		      } else {
		         // Row "rn" has data
		         for (int cn=0; cn<row.getLastCellNum(); cn++) {
		            Cell cell = row.getCell(cn);
		            if (cell == null) {
		              // This cell is empty/blank/un-used, handle as needed
		            } else {
		               ;
		               // Do something with the value
		            }
		         }
		      }
		   }
		}
		// creating the 0th row using the createRow() method
		
		FileOutputStream fileOut = new FileOutputStream(path);
		workbook.write(fileOut);
		fileOut.close();
		System.out.println("File is written successfully");
		fileOut.close();
	}
}
