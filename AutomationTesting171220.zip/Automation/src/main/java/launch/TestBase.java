package launch;

import java.io.IOException;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;;

public class TestBase {
	public static WebDriver driver = null; 
	 @BeforeSuite
	public void initialize() throws IOException {
				System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		WebDriver driver = new ChromeDriver(options);

		driver.manage().window().maximize();

		driver.get("http://walkexlamp.osiztechnologies.in/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("Osizextent.html");

		// create ExtentReports and attach reporter(s)
		ExtentReports extent = new ExtentReports();

		extent.attachReporter(htmlReporter);

		// creates a toggle for the given test, adds all log events under it
		ExtentTest test = extent.createTest("verifyHomePageTitle", "Checking the Title");

		// log(Status, details)
		test.log(Status.INFO, "Chrome Browser Launched Successfully");

		test.log(Status.INFO, "Navigated to URL");
		System.out.println(driver.getTitle());
		String actual = driver.getTitle().trim();
		test.log(Status.INFO, "Actual Title returned :: " + actual);

		String expected = "Walkex";
		test.log(Status.INFO, "Expected Title returned:: " + expected);

		Assert.assertEquals(actual, expected);

		// log with snapshot
		String temp = Utility.getScreenshot(driver);
		test.pass("details", MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		extent.flush();
		//driver.close();
	}

}
