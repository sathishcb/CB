package com.pack.preserve;

import java.io.*;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFRow;

public class CheExlFile {
	public static void main(String[] args) {
		try {
			String reportFilepath = System.getProperty("user.dir");
			String filename = reportFilepath+"\\Balance.xlsx";
			//String filename = "C:/NewExcelFile.xls";
			File file = new File("Geeks.xlsx"); 
			  
	        // Create a FileInputStream object 
	        // for getting the information of the file 
	        FileInputStream fip = new FileInputStream(file); 
	        HSSFWorkbook workbook = new HSSFWorkbook();
			FileOutputStream fileOut = new FileOutputStream(filename);
	        // Getting the workbook instance for XLSX file 
	     
	  
	        // Ensure if file exist or not 
	        if (file.isFile() && file.exists()) { 
	            System.out.println("Geeks.xlsx open"); 
	        } 
	        else { 
	            System.out.println("Geeks.xlsx either not exist"
	                               + " or can't open"); 
	        } 
			
	        workbook.write(fileOut);
            fileOut.close();
            workbook.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}
}