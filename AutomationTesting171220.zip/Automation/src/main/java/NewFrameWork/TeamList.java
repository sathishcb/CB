package NewFrameWork;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.pack.preserve.ListExcel;

import commonFuncation.DataCollection;
import commonFuncation.SelWebDriverMethods;

public class TeamList {
	String reportFilepath = System.getProperty("user.dir");
	File files = new File(reportFilepath);
	String readexcel = reportFilepath + "\\WalkexXpath.xls";
	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Grootan");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Grootan");

	@Test(priority = 4)
	public void Team() {

		String ScreenMenu;
		File file2 = new File(reportFilepath + "\\Folder 2");
		if (!file2.exists()) {
			System.out.println("Folder Is Not Present");
		} else {
			List<WebElement> lis = sel.getList(controlname.get("List Menu"), elelocators.get("List Menu"));
			for (int i = 1; i <= lis.size(); i++) {
				ScreenMenu = sel.getText(controlname.get("List Menu"), "xpath",
						elelocators.get("List Menu") + "[" + i + "]");
				String result = sel.assertequalandwriteresult(ScreenMenu, "Team");
				if (result == "Pass") {
					sel.Waituntilvisibility(controlname.get("List Menu"), "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");
					sel.seleniumAction(controlname.get("List Menu"), "Click", "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");

				}

			}
			ArrayList<String> JuniorList = new ArrayList<String>();
			List<WebElement> element = sel.getList(controlname.get("Team List"), elelocators.get("Team List"));

			for (int i = 1; i <= element.size(); i++) {
				List<WebElement> element1 = sel.getList(controlname.get("Team List"),
						elelocators.get("Team List") + "[" + i + "]/div");

				for (int j = 1; j <= element1.size(); j++) {

					try {
						// more-to-come

						if (i == element.size() && j == element1.size()) {

						} else {
							String Result = sel.getText(controlname.get("Team List"), "xpath",
									elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/h3");
							String ProfResult = sel.getText(controlname.get("Team List"), "xpath",
									elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/h5");

							boolean check = sel.verifyelementdisplayed(controlname.get("Team List"), "xpath",
									elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/h3");

							if (check == true) {

								System.out.println(Result + "---->" + ProfResult);
								if (ProfResult.contains("Junior")) {
									JuniorList.add(Result);

								}
							}
						}
					}

					catch (Exception ex) {

					}
				}

			}
			System.out.println(JuniorList.toString());
			ListExcel liss = new ListExcel();
			liss.ListData(JuniorList, "TestingReport", "Junior Engineers");

		}
	}
}