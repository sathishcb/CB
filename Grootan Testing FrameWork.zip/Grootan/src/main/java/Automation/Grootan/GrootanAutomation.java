package Automation.Grootan;

import java.awt.AWTException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.read.biff.BiffException;
import Automation.CommonFunction.*;
import Automation.CommonReport.ExtentTestManager;
import Automation.CommonReport.Utility;

public class GrootanAutomation {
	private static WebDriver driver;

	public static WebDriver getDriver() {
		return driver;
	}

	String applicationLink = ("https://www.grootan.com");
	String Browser = "chrome".toLowerCase();
	SelWebDriverMethods sel = new SelWebDriverMethods();
	TestcaseInsertExcel insert=new TestcaseInsertExcel();
	DataCollection DC = new DataCollection();
	String reportFilepath = System.getProperty("user.dir");
	String readexcel = reportFilepath + "\\WalkexXpath.xls";
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Grootan");
	HashMap<String, String> Case = DC.getEleRep(readexcel, "Moduel Description");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Grootan");
	File file;
	File file2;
	String Folder1Status;
	String Folder2Status;
	String FirstTime;

	@BeforeSuite
	public void TestResultFolder() throws IOException {
		String reportFilepath = System.getProperty("user.dir");
		file = new File(reportFilepath + "\\Folder 1");
		file2 = new File(reportFilepath + "\\Folder 2");

		
		String path = reportFilepath + "\\TestingReport.xlsx";
		File file3 = new File(path);
		Boolean File = file3.exists();
		System.out.println(File);
		if (!file3.exists()) {
			// Create file system using specific name
			HSSFWorkbook workbook = new HSSFWorkbook();
			FileOutputStream out = new FileOutputStream(new File(path));

			Sheet sheet = workbook.createSheet("TSR");
			Row rowhead = sheet.createRow((short) 0);
			rowhead.createCell(0).setCellValue("Test Case.No");
			rowhead.createCell(1).setCellValue("Module");
			rowhead.createCell(2).setCellValue("Description");
			rowhead.createCell(3).setCellValue("Test Case Status");
			// write operation workbook using file out object
			workbook.write(out);
			out.close();
			System.out.println("createworkbook.xlsx written successfully");
		} else {
			System.out.println("Alread Created");
		}

		if (!file.exists()) {
			Folder1Status = "Yes";

		} else {
			System.out.println("Folder1 Present");
			Folder1Status = "No";
		}
		if (!file2.exists()) {
			Folder2Status = "Yes";
		} else {
			System.out.println("Folder2 Present");
			Folder2Status = "No";
		}

	}

	@Test(priority = 0)
	public void BrowserLaunch() throws BiffException, IOException, InterruptedException, AWTException {

		switch (Browser) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			options.setExperimentalOption("prefs", prefs);
			options.addArguments("disable-infobars");
			options.addArguments("--disable-popup-blocking");
			options.addArguments("--disable-web-security");
			options.addArguments("--allow-running-insecure-content");
			options.setExperimentalOption("useAutomationExtension", false);
			options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			options.addArguments("--start-maximized");
			driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.get(applicationLink);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			/*ExtentTestManager.getTest().log(Status.INFO,
					"Module : Browser Launch ## TestCase Description :  " + Case.get("Browser Launch"));*/
			Boolean result = sel.verifyelementdisplayed(controlname.get("Cookies"), "xpath",
					elelocators.get("Cookies"));
			if (result == true) {
				sel.seleniumAction(controlname.get("Cookies"), "Click", "xpath", elelocators.get("Cookies"), "");
			}
			String temp = Utility.getScreenshot(driver);
			String ResultUrl = sel.getCurrentUrl();
			String sat = sel.assertcontainsandwriteresult(ResultUrl, applicationLink);
		
			
			if (sat == "Pass") {
				
				ExtentTestManager.getTest().log(Status.PASS,
						" Actual Url :" + ResultUrl + " ## " + " Expected Url  : " + applicationLink,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
				insert.TestSteps("Browser Launch", Case.get("Browser Launch"), "Pass");

			} else {
				ExtentTestManager.getTest().log(Status.FAIL,
						" Actual Url :" + ResultUrl + " ## " + " Expected Url  : " + applicationLink,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
				insert.TestSteps("Browser Launch", Case.get("Browser Launch"), "Fail");
			}
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.get(applicationLink);

		}

	}

	@Test(priority = 1)
	public void GrootanMenuPage() throws IOException, InterruptedException {
		String ScreenMenu;
		
		if (Folder1Status == "Yes") {
			System.out.println("Folder A Is Not Present");
			if (file.mkdir()) {
				System.out.println("Folder/Directory is created successfully");
				Folder2Status = "No";
				List<WebElement> lis = sel.getList(controlname.get("List Menu"), elelocators.get("List Menu"));
				for (int i = 1; i <= lis.size(); i++) {
					ScreenMenu = sel.getText(controlname.get("List Menu"), "xpath",
							elelocators.get("List Menu") + "[" + i + "]");
					sel.seleniumAction(controlname.get("List Menu"), "Click", "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");

					sel.Waituntilvisibility(controlname.get("List Menu"), "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");

					sel.seleniumAction("", "Sleep", "", "", "8000");
					/*
					 * sel.Waituntilvisibility(controlname.get("Chat"), "xpath",
					 * elelocators.get("Chat"), "5"); boolean gets =
					 * sel.verifyelementdisplayed(controlname.get("Chat"),
					 * "xpath", elelocators.get("Chat")); if (gets = true) {
					 * sel.seleniumAction(controlname.get("ChatClose"), "Click",
					 * "xpath", elelocators.get("ChatClose"), ""); }
					 */
					ExtentTestManager.getTest().log(Status.INFO, "Module : Grootan Menu Page ## TestCase Description : "
							+ ScreenMenu + " " + Case.get("Grootan Menu Page"));
					String ResultUrl = sel.getCurrentUrl();
					String temp = Utility.getScreenshot(driver);
					if (ResultUrl.contains(ScreenMenu)) {
						ExtentTestManager.getTest().log(Status.FAIL,
								" Menu Actual Url :" + ScreenMenu + " ## " + " Menu Expected Url  : " + ResultUrl,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
						insert.TestSteps("Grootan Menu Page", Case.get("Grootan Menu Page"), "Pass");
					} else if (ResultUrl.contains(applicationLink)) {
						ExtentTestManager.getTest().log(Status.FAIL,
								"Menu Actual Url :" + ScreenMenu + " ## " + "Menu Expected Url  : " + ResultUrl,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
						insert.TestSteps("Grootan Menu Page", Case.get("Grootan Menu Page"), "Pass");
					} else {
						ExtentTestManager.getTest().log(Status.FAIL,
								" Actual Url :" + ResultUrl + " ## " + " Expected Url  : " + ResultUrl,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
						insert.TestSteps("Grootan Menu Page", Case.get("Grootan Menu Page"), "Fail");
					}

					File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(screenshotFile, new File(file.toString() + "\\" + ScreenMenu + ".png"));
					sel.seleniumAction(controlname.get("Logo"), "Click", "xpath", elelocators.get("Logo"), "");

				}
			} else {
				System.out.println("Already Created");
			}
		}
		if (Folder2Status == "Yes") {
			System.out.println("Folder B Is Not Present");
			if (file2.mkdir()) {
				System.out.println("Folder/Directory is created successfully");
				List<WebElement> lis = sel.getList(controlname.get("List Menu"), elelocators.get("List Menu"));
				for (int i = 1; i <= lis.size(); i++) {
					ScreenMenu = sel.getText(controlname.get("List Menu"), "xpath",
							elelocators.get("List Menu") + "[" + i + "]");
					sel.seleniumAction(controlname.get("List Menu"), "Click", "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");

					sel.Waituntilvisibility(controlname.get("List Menu"), "xpath",
							elelocators.get("List Menu") + "[" + i + "]", "");
					sel.seleniumAction("", "Sleep", "", "", "8000");
					/*
					 * sel.Waituntilvisibility(controlname.get("Chat"), "xpath",
					 * elelocators.get("Chat"), "5"); boolean gets =
					 * sel.verifyelementdisplayed(controlname.get("Chat"),
					 * "xpath", elelocators.get("Chat")); if (gets = true) {
					 * sel.seleniumAction(controlname.get("ChatClose"), "Click",
					 * "xpath", elelocators.get("ChatClose"), ""); }
					 */
					ExtentTestManager.getTest().log(Status.INFO, "Module : Grootan Menu Page ## TestCase Description : "
							+ ScreenMenu + " " + Case.get("Grootan Menu Page"));
					String ResultUrl = sel.getCurrentUrl();
					String temp = Utility.getScreenshot(driver);
					if (ResultUrl.contains(ResultUrl)) {
						ExtentTestManager.getTest().log(Status.PASS,
								" Menu Actual Url :" + ScreenMenu + " ## " + " Menu Expected Url  : " + ResultUrl,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
						insert.TestSteps("Grootan Menu Page", Case.get("Grootan Menu Page"), "Pass");
					} else if (ResultUrl.contains(applicationLink)) {
						ExtentTestManager.getTest().log(Status.PASS,
								"Menu Actual Url :" + ScreenMenu + " ## " + "Menu Expected Url  : " + ResultUrl,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
						insert.TestSteps("Grootan Menu Page", Case.get("Grootan Menu Page"), "Pass");
					} else {
						ExtentTestManager.getTest().log(Status.FAIL,
								" Actual Url :" + ResultUrl + " ## " + " Expected Url  : " + ResultUrl,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
						insert.TestSteps("Grootan Menu Page", Case.get("Grootan Menu Page"), "Fail");
					}

					File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(screenshotFile, new File(file2.toString() + "\\" + ScreenMenu + ".png"));
					sel.seleniumAction(controlname.get("Logo"), "Click", "xpath", elelocators.get("Logo"), "");

				}
			} else {
				System.out.println("Directory/Folder creation failed!!!");
			}
		}

	}

	@AfterSuite
	public void QuitBrowser() {
		driver.quit();

	}
}