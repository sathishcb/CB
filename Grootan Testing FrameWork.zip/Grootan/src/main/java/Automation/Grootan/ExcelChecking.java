package Automation.Grootan;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.testng.annotations.Test;

public class ExcelChecking {
	@Test()
	public void get() throws EncryptedDocumentException, IOException {
		
		String reportFilepath = System.getProperty("user.dir");
		String path = reportFilepath+"\\Data.xlsx";
		FileOutputStream out = new FileOutputStream(new File(path));
		FileInputStream fileinp = new FileInputStream("D:\\SATHISH\\Automation\\Automation\\TestingReport.xlsx");
		HSSFWorkbook workbook = new HSSFWorkbook(fileinp);
		HSSFWorkbook workbook = new HSSFWorkbook();
		Sheet sheet = workbook.getSheet("TSR");
		Row rowhead = sheet.createRow((short) 0);
		rowhead.createCell(0).setCellValue("Test Case.No");
		rowhead.createCell(1).setCellValue("Module");
		rowhead.createCell(2).setCellValue("Description");
		rowhead.createCell(3).setCellValue("Test Case Status");
		FileOutputStream fileOut = new FileOutputStream(path);
		workbook.write(fileOut);
		fileOut.close();
		workbook.close();
		System.out.println("File is written successfully");
	}
}
