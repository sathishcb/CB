package Automation.CommonFunction;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.testng.annotations.Test;

public class TestcaseInsertExcel {
	@Test()
	public void TestSteps(String Module,String Description,String st) throws IOException {

		String reportFilepath = System.getProperty("user.dir");
		String path = reportFilepath + "\\TestingReport.xlsx";
		FileInputStream fileinp = new FileInputStream(path);
		HSSFWorkbook workbook = new HSSFWorkbook(fileinp);

		// Creating Sheets using sheet object
		Sheet sheet = workbook.getSheet("TSR");
		Row rowhead = null;
		int i = 1;
		
		rowhead = sheet.createRow(sheet.getLastRowNum() + i);
		System.out.println(sheet.getLastRowNum());
	
		try {
			Boolean result = rowhead.createCell(i).getStringCellValue().isEmpty();
			System.out.println(result);
		//	rowhead.createCell(0).setCellValue(sheet.getLastRowNum()+i);
			rowhead.createCell(1).setCellValue(Module);
			rowhead.createCell(2).setCellValue(Description);
			rowhead.createCell(3).setCellValue(st);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		System.out.println("Sheets Has been Created successfully");
		FileOutputStream fileOut = new FileOutputStream(path);
		workbook.write(fileOut);
		fileOut.close();
		workbook.close();
	}
}

