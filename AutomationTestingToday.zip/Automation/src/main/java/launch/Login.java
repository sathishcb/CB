package launch;

public class Login extends TestBase {

}
