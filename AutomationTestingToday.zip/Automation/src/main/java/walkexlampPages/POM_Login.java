package walkexlampPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class POM_Login {
	
	WebDriver driver;
	public POM_Login(WebDriver driver){
	this.driver=driver;
	}

	// Login Button Xpath
	@FindBy(xpath = "//*[@id=\"navbarSupportedContent\"]/ul[2]/li[1]/a")
	 WebElement LoginButton;

	// Login Form-Xpath
	@FindBy(xpath = "//*[@id=\"login_form\"]/h4")
	private WebElement LoginForm;
	// Username/Email Id- Xpath/Id
	@FindBy(id = "email")
	private WebElement emailTextBox;

	// Passowrd- Xpath/Id
	@FindBy(id = "password")
	private WebElement passwordTextBox;
	// Login Button Xpath
	@FindBy(xpath = "login_submit")
	private WebElement SubmitLoginButton;

	// This method is to click on Login Button Button
	public void clickOnLoginButton() {
		LoginButton.click();
	}

	// This method is to Verify Login Page
	public String VefiyLoginPage() {
		String ActualHeading = LoginForm.getText().trim();
		return ActualHeading;
	}

	// This method is to set Email in the email text box
	public void setEmail(String strEmail) {
		emailTextBox.sendKeys(strEmail);
	}

	// This method is to set Password in the password text box
	public void setPassword(String strPassword) {
		passwordTextBox.sendKeys(strPassword);
	}

	// This method is to click on Next Button
	public void clickOnNextButton() {
		SubmitLoginButton.click();
	}

	public String GetCurrentTitle() {
		String actual = driver.getTitle().trim();
		return actual;
	}
}
