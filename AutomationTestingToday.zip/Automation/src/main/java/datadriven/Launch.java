package datadriven;

import java.io.File;

/**
 * @author Sathish Kumar CB 
 */

import java.io.IOException;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import launch.Utility;
import ru.yandex.qatools.ashot.Screenshot;
import walkexBase.ExtentTestManager;

/**
 * This class consists of steps of Login process
 */

public class Launch {
	static WebDriver driver;

	public static WebDriver getDriver() {
		return driver;
	}

	@Test
	public void WalkexLaunch() throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://walkexlamp.osiztechnologies.in/login");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		ExtentTestManager.getTest().log(Status.INFO, "Chrome Browser Launch With Walkexilamp Url");
		String actual = driver.getTitle().trim();
		String expected = "Walkex";
		Thread.sleep(2000);
		String temp = Utility.getScreenshot(driver);


		try {
			Assert.assertEquals(actual, expected);
			ExtentTestManager.getTest().log(Status.PASS, "Expected Title :" + expected +"-"+ "Actual Title :" + actual , 
					MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		} catch (AssertionError ex) {
			ExtentTestManager.getTest().log(Status.FAIL, "Expected Title :" + expected +"-"+ "Actual Title :" + actual,
					MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		}

	}

}