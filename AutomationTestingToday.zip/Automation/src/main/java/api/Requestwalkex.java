package api;

import java.io.IOException;

import org.json.JSONObject;
import org.testng.annotations.Test;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.request.HttpRequestWithBody;
import com.mashape.unirest.request.body.Body;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Requestwalkex {
	@Test(enabled=false)
	public void getresult() throws IOException {
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("text/plain");
		RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
				.addFormDataPart("api_key", "87AA7E-E40B66-31F528-F0E495-CD77FD")
				.addFormDataPart("api_secret", "11Bbv8WCi56YBCnU2fW7754ofBg39VDQ").addFormDataPart("pair", "LTC_BTC")
				.build();
		Request request = new Request.Builder().url(
				"https://walkexlamp.osiztechnologies.in/api/getActiveOrders?api_key=87AA7E-E40B66-31F528-F0E495-CD77FD&api_secret=11Bbv8WCi56YBCnU2fW7754ofBg39VDQ&pair=LTC_BTC")
				.method("POST", body).addHeader("Cookie", "__cfduid=df4bcb789b266a20c7c3f1e5fa47e448e1606372745")
				.build();
		Response response = client.newCall(request).execute();
		String responseBody = response.body().string();
		// System.out.println(responseBody);
		JSONObject jsonObj = new JSONObject(responseBody);
		String name = jsonObj.getString("orders");
		System.out.println(name);

	}

	@Test(enabled=true)
	public void UnirestException() {
		try {
			Unirest.setTimeouts(0, 0);
			HttpResponse<String> response = Unirest.post(
					"https://walkexlamp.osiztechnologies.in/api/getActiveOrders?api_key=87AA7E-E40B66-31F528-F0E495-CD77FD&api_secret=11Bbv8WCi56YBCnU2fW7754ofBg39VDQ&pair=LTC_BTC")
					.header("Cookie", "__cfduid=df4bcb789b266a20c7c3f1e5fa47e448e1606372745")
					.field("api_key", "87AA7E-E40B66-31F528-F0E495-CD77FD")
					.field("api_secret", "11Bbv8WCi56YBCnU2fW7754ofBg39VDQ").field("pair", "LTC_BTC").asString();
			String responseBody = response.getBody();
			JSONObject jsonObj = new JSONObject(responseBody);
			String name = jsonObj.getString("orders");
			System.out.println(name);
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	

	@Test(enabled=false)
	public void GetOTPException() {
		try {
			Unirest.setTimeouts(0, 0);
			HttpRequestWithBody response = Unirest.post("https://walkexlamp.osiztechnologies.in/otpapi/sathishkumar.c.b@fit4bond.net");
			Body responseBody = response.getBody();
			System.out.println(responseBody.toString());
			JSONObject jsonObj = new JSONObject(responseBody);
			String name = jsonObj.getString("mail_otp");
			System.out.println(name);
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

}