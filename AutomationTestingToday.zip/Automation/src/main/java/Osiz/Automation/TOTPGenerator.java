package Osiz.Automation;
import org.jboss.aerogear.security.otp.Totp;

public class TOTPGenerator {
	public static void main(String[] args) {
		Totp totp = new Totp("GRXDY43TJF5UIJSY"); 
		String twoFactorCode = totp.now();
		System.out.println(twoFactorCode);

	}
}
