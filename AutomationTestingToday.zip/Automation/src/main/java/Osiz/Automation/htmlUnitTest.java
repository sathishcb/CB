package Osiz.Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class htmlUnitTest {				
	public static void main(String[] args) {
       
         
        WebDriver driver = new HtmlUnitDriver();
         
		    
     //   driver.get("https://walkexlamp.osiztechnologies.in/otpapi/sathishkumar.c.b@fit4bond.net");					
      driver.get("http://google.com");
			
        WebElement element = driver.findElement(By.xpath("html/body"));	
		/*
		 * JSONParser jsonParser = new JSONParser(); FileReader reader = new
		 * FileReader("Testdata.json");
		 */
        //Read JSON file
    //    Object obj = jsonParser.parse(reader);

       // Enter a search query		
     String OTP=  element.getText().trim();
      
      
       System.out.println("OPT is: " + OTP);		
       
       driver.quit();			
}		
}

