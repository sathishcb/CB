package walkexlampTest;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import launch.TestBase;
import walkexlampPages.POM_Login;

public class Login extends TestBase {
	@Test
	public void init() throws Exception {

		POM_Login loginpage = PageFactory.initElements(driver, POM_Login.class);
		loginpage.setEmail("cbsathish");
		loginpage.setEmail("Pass");

	}
}
