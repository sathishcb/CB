package com.pack.preserve;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.Test;

public class ClassOne {

	/*
	 * @Test public void firstTestCase() {
	 * System.out.println("im in first test case from ClassOne Class"); }
	 */

	@Test(enabled=false)
	public void secondTestCase() {
		// 0.00073975
		double List = 77.99990005;
		double p = 0.00073975;
		double r = List - p;
		String t = "0.00000053400";
		// double a = Integer.parseInt(String.valueOf(t));
		DecimalFormat df2 = new DecimalFormat("#.#########");
		double Fee = r * 0.10 / 100;
		System.out.println(df2.format(r));
		System.out.println(df2.format(Fee));
		double rs = r + Fee;
		System.out.println(r + df2.format(rs));
		String ResultTotal = df2.format(r + Fee);
		System.out.println(ResultTotal);

	}

	@Test
	public void CurrentDate() {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String formatted = df.format(new Date());
		System.out.println(formatted);
		
		//SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	}
}
