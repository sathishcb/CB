package com.pack.preserve;

import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.testng.annotations.Test;

public class ListExcel {
	@Test()
	public  void ListData(List list,String Filename,String Sheetname) {
		try {
			// declare file name to be create
			String reportFilepath = System.getProperty("user.dir");
			String filename = reportFilepath + "\\"+Filename+".xlsx";
			// creating an instance of HSSFWorkbook class
			HSSFWorkbook workbook = new HSSFWorkbook();
			// invoking creatSheet() method and passing the name of the sheet to be created
			HSSFSheet sheet = workbook.createSheet(Sheetname);
			// creating the 0th row using the createRow() method
			HSSFRow rowhead = sheet.createRow((short) 0);
			// creating cell by using the createCell() method and setting the values to the
			// cell by using the setCellValue() method
			rowhead.createCell(0).setCellValue("S.No.");
			rowhead.createCell(1).setCellValue("Name");
			// creating the 1st row
			for (int i = 0; i < list.size(); i++) {
				HSSFRow row = sheet.createRow((short) i+1);
				// inserting data in the first row
				row.createCell(0).setCellValue(i+1);
				row.createCell(1).setCellValue(list.get(i).toString());
			}
			FileOutputStream fileOut = new FileOutputStream(filename);
			workbook.write(fileOut);
			// closing the Stream
			fileOut.close();
			// closing the workbook
			workbook.close();
			// prints the message on the console
			System.out.println("Excel file has been generated successfully.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
