package com.limt.trade;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import commonFuncation.DataCollection;
import commonFuncation.SelWebDriverMethods;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import launch.Utility;
import trade.BrowserLaunch;
import walkexBase.ExtentTestManager;

public class CancelTrade {
	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	String readexcel = "C:\\Users\\Tester-Sathishkumar\\Desktop\\WalkexXpath.xls";
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Trade");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Trade");

	@Test(priority = 8, enabled = true)
	public void TradeCancel() throws BiffException, IOException {

		new WebDriverWait(BrowserLaunch.getDriver(), 20);
		String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("Cancel Trade");
		String ScreenAmount = null;
		String ScreenDate = null;
		String ScreenType = null;
		String ScreenPrice = null;
		String ScreenTotal = null;
		String ScreenFee = null;
		String ScreenStatus = null;
		String status = null;
		String temp = null;
		for (int l = 1; l < sheet.getRows(); l++) {
			String OrderType = sheet.getCell(1, l).getContents().toLowerCase();
			String TDate = sheet.getCell(2, l).getContents();
			String TType = sheet.getCell(3, l).getContents();
			String TAmount = sheet.getCell(4, l).getContents();
			String TPrice = sheet.getCell(5, l).getContents();
			String TTotal = sheet.getCell(6, l).getContents();
			String TFee = sheet.getCell(7, l).getContents();
			String TStatus = sheet.getCell(8, l).getContents();
			String Notification = sheet.getCell(9, l).getContents();
			if(OrderType!=null||OrderType!="")
			switch (OrderType) {
			case "open order":
				sel.seleniumAction(controlname.get("Open Order Tab"), "Click", "xpath",
						elelocators.get("Open Order Tab"), "");
				List<WebElement> lis = sel.getList(controlname.get("Open Order Book"),
						elelocators.get("Open Order Book"));
				for (int i = 1; i <= lis.size(); i++) {
					ScreenDate = sel.getText(controlname.get("Open Order Book"), "xpath",
							elelocators.get("Open Order Book") + "[" + i + "]/td[1]");
					ScreenType = sel.getText(controlname.get("Open Order Book"), "xpath",
							elelocators.get("Open Order Book") + "[" + i + "]/td[2]/span");
					ScreenAmount = sel.getText(controlname.get("Open Order Book"), "xpath",
							elelocators.get("Open Order Book") + "[" + i + "]/td[3]");
					ScreenPrice = sel.getText(controlname.get("Open Order Book"), "xpath",
							elelocators.get("Open Order Book") + "[" + i + "]/td[4]");
					ScreenTotal = sel.getText(controlname.get("Open Order Book"), "xpath",
							elelocators.get("Open Order Book") + "[" + i + "]/td[5]");
					ScreenFee = sel.getText(controlname.get("Open Order Book"), "xpath",
							elelocators.get("Open Order Book") + "[" + i + "]/td[6]");
					ScreenStatus = sel.getText(controlname.get("Open Order Book"), "xpath",
							elelocators.get("Open Order Book") + "[" + i + "]/td[7]");
					System.out.println("1:" + ScreenDate);
					System.out.println("2:" + ScreenType);
					System.out.println("3:" + ScreenAmount);
					System.out.println("4:" + ScreenPrice);
					System.out.println("5:" + ScreenTotal);
					System.out.println("6:" + ScreenFee);
					System.out.println("7:" + ScreenStatus);

					System.out.println("1:" + TDate);
					System.out.println("2:" + TType);
					System.out.println("3:" + TAmount);
					System.out.println("4:" + TPrice);
					System.out.println("5:" + TTotal);
					System.out.println("6:" + TFee);
					System.out.println("7:" + TStatus);
					try {

						assertTrue(ScreenType.equals(TType));
						assertTrue(ScreenAmount.equals(TAmount));
						assertTrue(ScreenDate.contains(TDate));
						assertTrue(ScreenPrice.equals(TPrice));
						assertTrue(ScreenTotal.equals(TTotal));
						assertTrue(ScreenFee.equals(TFee));
						assertTrue(ScreenStatus.equals(TStatus));
						sel.seleniumAction(controlname.get("Open Order Book"), "Click", "xpath",
								elelocators.get("Open Order Book") + "[" + i + "]/td[8]/a", "");
						sel.seleniumAction(controlname.get("Cancel Yes Button"), "Click", "id",
								elelocators.get("Cancel Yes Button"), "");
						String noti = sel.getText(controlname.get("Notification"), "xpath",
								elelocators.get("Notification"));
						System.out.println(noti);
						assertTrue(noti.equals(Notification));
						temp = Utility.getScreenshot(BrowserLaunch.getDriver());
						sel.seleniumAction("", "KeypressF5", "", "", "");

						status = "pass";

						ExtentTestManager.getTest().log(Status.PASS,
								" Date :" + ScreenDate + " ## " + "Type  : Buy" + "Amount  :" + ScreenAmount + " ## "
										+ "Price: " + ScreenPrice + " ## " + "Total :" + ScreenTotal + " ## " + "Fee : "
										+ ScreenFee + " ## " + "Status : " + ScreenStatus,
								MediaEntityBuilder.createScreenCaptureFromPath(temp).build());

					} catch (AssertionError ex) {
						status = "fail";
					}
					System.out.println(ScreenPrice);

				}
				if (status != "pass") {
					temp = Utility.getScreenshot(BrowserLaunch.getDriver());
					ExtentTestManager.getTest().log(Status.FAIL,
							" Date :" + ScreenDate + " ## " + "Type  : Buy" + "Amount  :" + ScreenAmount + " ## "
									+ "Price: " + ScreenPrice + " ## " + "Total :" + ScreenTotal + " ## " + "Fee : "
									+ ScreenFee + " ## " + "Status : " + ScreenStatus,
							MediaEntityBuilder.createScreenCaptureFromPath(temp).build());

				}
				break;
			}
		}
	}

	@Test(priority = 8, enabled = false)
	public void TradeCancelnew() throws BiffException, IOException, InterruptedException {
		BrowserLaunch.getDriver().findElement(By.xpath("//*[@id=\"activeContent\"]/tr[1]/td[8]/a")).click();

		Thread.sleep(1000);
		BrowserLaunch.getDriver().findElement(By.xpath("//*[@id=\"close_no\"]")).click();

	}

}
