package com.limt.trade;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import commonFuncation.DataCollection;
import commonFuncation.SelWebDriverMethods;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import launch.Utility;
import trade.BrowserLaunch;
import walkexBase.ExtentTestManager;

public class VerfiyBuyLimitTrade {
	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	String readexcel = "C:\\Users\\Tester-Sathishkumar\\Desktop\\WalkexXpath.xls";
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Trade");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Trade");
	// Excel Data Details

	@Test(priority = 6)
	public void BuyOrderBook() throws IOException, BiffException {
		WebDriverWait wait = new WebDriverWait(BrowserLaunch.getDriver(), 20);
		String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("Limt Order");
		String ScreenAmount = null;
		String ScreenPrice = null;
		String status = null;
		String temp = null;
		for (int l = 1; l < sheet.getRows(); l++) {
			String Price = sheet.getCell(3, l).getContents();
			String Amount = sheet.getCell(4, l).getContents();

			List<WebElement> lis = sel.getList(controlname.get("Buy Order Book"), elelocators.get("Buy Order Book"));
			for (int i = 1; i <= lis.size(); i++) {
				ScreenPrice = sel.getText(controlname.get("Buy Order Book"), "xpath",
						elelocators.get("Buy Order Book") + "[" + i + "]/span[1]");
				ScreenAmount = sel.getText(controlname.get("Buy Order Book"), "xpath",
						elelocators.get("Buy Order Book") + "[" + i + "]/span[2]");
				temp = Utility.getScreenshot(BrowserLaunch.getDriver());
				try {
					assertTrue(ScreenPrice.equals(Price));
					assertTrue(ScreenAmount.equals(Amount));

					ExtentTestManager.getTest().log(Status.PASS,
							" Actual Price  :" + ScreenPrice + " ## " + " Expected Price  : " + Price
									+ " Actual Amount  :" + ScreenAmount + " ## " + " Expected Amount  : " + Amount,
							MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
					status = "pass";

				} catch (AssertionError ex) {
					status = "fail";
				}
				System.out.println(ScreenPrice);

			}
			if (status != "pass") {
				ExtentTestManager.getTest().log(Status.FAIL,
						" Actual Price  :" + ScreenPrice + " ## " + " Expected Price  : " + Price + " Actual Amount  :"
								+ ScreenAmount + " ## " + " Expected Amount  : " + Amount,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			}
		}

	}

	@Test(priority = 7)
	public void OpenOrderBook() throws IOException, BiffException {
		WebDriverWait wait = new WebDriverWait(BrowserLaunch.getDriver(), 20);
		String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
		FileInputStream file = new FileInputStream(new File(filePath));
		Workbook w = Workbook.getWorkbook(file);
		Sheet sheet = w.getSheet("Limt Order");
		String ScreenAmount = null;
		String ScreenDate = null;
		String ScreenType = null;
		String ScreenPrice = null;
		String ScreenTotal = null;
		String ScreenFee = null;
		String ScreenStatus = null;
		String status = null;
		String temp = null;
		String ResultFee = null;
		String ResultTotal = null;
		String Resultdate=null;
		for (int l = 1; l < sheet.getRows(); l++) {
			String Price = sheet.getCell(3, l).getContents();
			String Amount = sheet.getCell(4, l).getContents();
			String Fee = sheet.getCell(5, l).getContents();

			List<WebElement> lis = sel.getList(controlname.get("Open Order Book"), elelocators.get("Open Order Book"));
			for (int i = 1; i <= lis.size(); i++) {
				ScreenDate = sel.getText(controlname.get("Open Order Book"), "xpath",
						elelocators.get("Open Order Book") + "[" + i + "]/td[1]");
				ScreenType = sel.getText(controlname.get("Open Order Book"), "xpath",
						elelocators.get("Open Order Book") + "[" + i + "]/td[2]/span");
				ScreenAmount = sel.getText(controlname.get("Open Order Book"), "xpath",
						elelocators.get("Open Order Book") + "[" + i + "]/td[3]");
				ScreenPrice = sel.getText(controlname.get("Open Order Book"), "xpath",
						elelocators.get("Open Order Book") + "[" + i + "]/td[4]");
				ScreenTotal = sel.getText(controlname.get("Open Order Book"), "xpath",
						elelocators.get("Open Order Book") + "[" + i + "]/td[5]");
				ScreenFee = sel.getText(controlname.get("Open Order Book"), "xpath",
						elelocators.get("Open Order Book") + "[" + i + "]/td[6]");
				ScreenStatus = sel.getText(controlname.get("Open Order Book"), "xpath",
						elelocators.get("Open Order Book") + "[" + i + "]/td[7]");
				System.out.println("1:" + ScreenDate);
				System.out.println("2:" + ScreenType);
				System.out.println("3:" + ScreenAmount);
				System.out.println("4:" + ScreenPrice);
				System.out.println("5:" + ScreenTotal);
				System.out.println("6:" + ScreenFee);
				System.out.println("7:" + ScreenStatus);

				try {
					
					assertTrue(ScreenType.equals("Buy"));
					assertTrue(ScreenAmount.equals(Amount));
					TradeCalucation calculation = new TradeCalucation();
					Resultdate=calculation.CurrentDate();
					assertTrue(ScreenDate.contains(Resultdate));
					ResultFee = calculation.feeCalucation(Amount, Price, Fee);
					System.out.println(ResultFee);
					ResultTotal = calculation.ScreenTotalCalucation(Amount, Price);
					System.out.println(ResultTotal);
					assertTrue(ScreenTotal.equals(ResultTotal));
					assertTrue(ScreenFee.equals(ResultFee));
					assertTrue(ScreenStatus.equals("active"));
					temp = Utility.getScreenshot(BrowserLaunch.getDriver());
					ExtentTestManager.getTest().log(Status.PASS,
							" Date :" + Resultdate + " ## " + "Type  : Buy" + "Amount  :" + Amount + " ## "
									+ "Price: " + Price + " ## " + "Total :" + ResultTotal + " ## " + "Fee : "
									+ ResultFee + " ## " + "Status : " + ScreenStatus,
							MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
					status = "pass";

				} catch (AssertionError ex) {
					status = "fail";
				}
				System.out.println(ScreenPrice);

			}
			if (status != "pass") {
				temp = Utility.getScreenshot(BrowserLaunch.getDriver());
				ExtentTestManager.getTest().log(Status.FAIL,
						" Date :" + ScreenDate + " ## " + "Type  : Buy" + "Amount  :" + ScreenAmount + " ## "
								+ "Price: " + ScreenPrice + " ## " + "Total :" + ResultTotal + " ## " + "Fee : "
								+ ResultFee + " ## " + "Status : " + ScreenStatus,
						MediaEntityBuilder.createScreenCaptureFromPath(temp).build());

			}
		}

	}
}