package excel;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

public class CreateReportExcel {
   public static void main(String[] args)throws Exception {

      //Create Blank workbook
      HSSFWorkbook workbook = new HSSFWorkbook();
      String reportFilepath = System.getProperty("user.dir");
		String path = reportFilepath+"\\TestingReport.xlsx";
		File file = new File(path);
		Boolean File =file.exists();
		System.out.println(File);
		if(!file.exists()) {
			 //Create file system using specific name
		      FileOutputStream out = new FileOutputStream(
		         new File(path));
		      
		      Sheet sheet = workbook.createSheet("TSR");
		     Row rowhead = sheet.createRow((short)0);
		     rowhead.createCell(0).setCellValue("Test Case.No");
		     rowhead.createCell(1).setCellValue("Module");
		     rowhead.createCell(2).setCellValue("Test Case Status");
		      //write operation workbook using file out object
		      workbook.write(out);
		      out.close();
		      System.out.println("createworkbook.xlsx written successfully");	
		}
     
   }
}