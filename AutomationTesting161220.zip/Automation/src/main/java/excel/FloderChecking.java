package excel;

import java.io.File;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class FloderChecking {
	File file;
	File file2;

	@BeforeSuite
	public void checkfolder() {
		String reportFilepath = System.getProperty("user.dir");
		file = new File(reportFilepath + "\\" + "Tester");
		file2 = new File(reportFilepath + "\\" + "Tester2");
		if (!file.exists()) {

		} else {
			System.out.println("Folder1 Present");
		}
		if (!file2.exists()) {

		} else {
			System.out.println("Folder2 Present");
		}

	}

	@Test
	public void ceching() {
		if (file.exists() == false) {
			System.out.println("Folder A Is Not Present");
			if (file.mkdir()) {
				System.out.println("Folder/Directory is created successfully");
			} else {
				System.out.println("Directory/Folder creation failed!!!");
			}
		}
	}

	@Test
	public void ceching2() {
		if (file2.exists() == false) {
			System.out.println("Folder B Is Not Present");
			if (file2.mkdir()) {
				System.out.println("Folder/Directory is created successfully");
			} else {
				System.out.println("Directory/Folder creation failed!!!");
			}
		}
	}
}
