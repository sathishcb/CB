package com.pack.preserve;
import org.testng.annotations.Test;

public class ClassTwo {

	@Test
	public void firstTestCase() {
		System.out.println("im in first test case from ClassOne Class");
	}

	@Test
	public void secondTestCase() {
		System.out.println("im in second test case from ClassOne Class");
	}

}