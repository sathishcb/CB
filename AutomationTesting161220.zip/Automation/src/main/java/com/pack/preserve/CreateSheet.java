package com.pack.preserve;

import java.io.*; 
import org.apache.poi.hssf.usermodel.HSSFWorkbook; 
import org.apache.poi.ss.usermodel.Sheet; 
import org.apache.poi.ss.usermodel.Workbook; 
  
public class CreateSheet { 
    public static void main(String[] args)  
      throws FileNotFoundException, IOException 
    { 
  
        // Creating Workbook instances 
        Workbook wb = new HSSFWorkbook(); 
  
        // An output stream accepts output bytes and sends them to sink. 
        OutputStream fileOut = new FileOutputStream("Geeks.xlsx"); 
          
        // Creating Sheets using sheet object 
        Sheet sheet = wb.createSheet("Array"); 
        
          
  
System.out.println("Sheets Has been Created successfully"); 
  
        wb.write(fileOut); 
    } 
} 
