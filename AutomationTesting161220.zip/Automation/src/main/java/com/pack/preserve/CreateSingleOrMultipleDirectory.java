package com.pack.preserve;

import java.io.File;

public class CreateSingleOrMultipleDirectory {
	public static void main(String[] args) {
//To create single directory
		
		String reportFilepath = System.getProperty("user.dir");
		File file = new File(reportFilepath+"\\"+"Tester");
		if (!file.exists()) {
			if (file.mkdir()) {
				System.out.println("Folder/Directory is created successfully");
			} else {
				System.out.println("Directory/Folder creation failed!!!");
			}
		}
		else {
			System.out.println("Folder Present");
		}

	}
}