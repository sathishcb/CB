package com.pack.preserve;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestScreenshotUsingAshot {
	private static WebDriver driver;

	public static void main(String[] args) throws IOException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		driver = new ChromeDriver(options);

		driver.get("http://demo.guru99.com/test/guru99home/");
		driver.manage().window().maximize();
		String reportFilepath = System.getProperty("user.dir");
		File Folder1 = new File(reportFilepath + "\\" + "Tester");
		File Folder2 = new File(reportFilepath + "\\" + "Tester2");
		boolean f1 = Folder1.exists();
		boolean f2 = Folder2.exists();
		if (f1 && f2 == true) {
			FileUtils.deleteDirectory(new File(Folder1.toString()));
			FileUtils.deleteDirectory(new File(Folder2.toString()));
		} else if (f1 == true) {
			File file = new File(reportFilepath + "\\" + "Tester2");
			System.out.println(file.exists());
			if (!file.exists()) {
				if (file.mkdir()) {
					System.out.println("Folder/Directory is created successfully");
					File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(screenshotFile, new File(file.toString() + "\\" + "First.png"));

				} else {
					System.out.println("Directory/Folder creation failed!!!");
				}
			} else {
				File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(screenshotFile, new File(file.toString() + "\\" + "First.png"));
			}
		} else {
			File file = new File(reportFilepath + "\\" + "Tester");
			if (!file.exists()) {
				if (file.mkdir()) {
					System.out.println("Folder/Directory is created successfully");
					File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(screenshotFile, new File(file.toString() + "\\" + "First.png"));
				} else {
					System.out.println("Directory/Folder creation failed!!!");
				}
			} else {
				System.out.println("Folder Present");

			}

		}
	}
}
