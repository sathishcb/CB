package walkexlampTest;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import walkexBase.ExtentTestManager;
import walkexBase.TestBase;
import walkexlampPages.BasePage;
import walkexlampPages.CreateAccountPage;
import walkexlampPages.SignInPage;

public class CreateAccountTest extends TestBase {
	private WebDriver driver;
	private SignInPage signInPage;
	private BasePage basePage;
	private TestBase testbase;
	private CreateAccountPage createAccountPage;

	@BeforeClass
	public void setUp() {
		driver = getDriver();
	}

	@Test
	public void verifyCreateAnAccountPage() {
		try {
			System.out.println("Create An Account page test...");
			basePage = new BasePage(driver);
			signInPage = basePage.clickSignInBtn();
			ExtentTestManager.getTest().log(Status.INFO, "Create Account Page Title :" + basePage.getPageTitle());

		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	@Test
	public void createAccountExample1() throws InterruptedException {
		Thread.sleep(4000);
		createAccountPage = new CreateAccountPage(driver);
		Assert.assertTrue(createAccountPage.verifyPageTitle(), "Page title not matching");
		Assert.assertTrue(createAccountPage.verifyCreateAccountPageText(), "Page text not matching");
		ExtentTestManager.getTest().log(Status.INFO, "Create Account Page Title :" + createAccountPage.getPageTitle());
		ExtentTestManager.getTest().log(Status.INFO,
				"Create Account Page Title :" + createAccountPage.verifyCreateAccountPageText());

	}

	
}