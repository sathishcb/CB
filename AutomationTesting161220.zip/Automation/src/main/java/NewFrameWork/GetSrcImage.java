package NewFrameWork;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import commonFuncation.DataCollection;
import commonFuncation.SelWebDriverMethods;

public class GetSrcImage {

	String readexcel = "C:\\Users\\Tester-Sathishkumar\\Desktop\\WalkexXpath.xls";
	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Grootan");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Grootan");

	@Test()
	public void getSrcImageScreenshot() throws EncryptedDocumentException, IOException {

		String ScreenMenu;
		List<WebElement> lis = sel.getList(controlname.get("List Menu"), elelocators.get("List Menu"));
		for (int i = 1; i <= lis.size(); i++) {
			ScreenMenu = sel.getText(controlname.get("List Menu"), "xpath",
					elelocators.get("List Menu") + "[" + i + "]");
			String result = sel.assertequalandwriteresult(ScreenMenu, "Team");
			if (result == "Pass") {
				sel.Waituntilvisibility(controlname.get("List Menu"), "xpath",
						elelocators.get("List Menu") + "[" + i + "]", "");
				sel.seleniumAction(controlname.get("List Menu"), "Click", "xpath",
						elelocators.get("List Menu") + "[" + i + "]", "");

			}

		}
		List<WebElement> element = sel.getList(controlname.get("Team List"), elelocators.get("Team List"));
		String File = null;
		String sheet = null;
		Workbook wb = WorkbookFactory.create(new File(File));
		Sheet st1 = wb.getSheet(sheet);
		for (int l = 1; l <= st1.getLastRowNum(); l++) {
			if (sheet.contentEquals("Login")) {
				Row row = st1.getRow(l);
				int colunmIndex = 0;
				Cell pass = row.getCell(++colunmIndex);
				String NameSrc = pass.toString();

				for (int i = 1; i <= element.size(); i++) {
					List<WebElement> element1 = sel.getList(controlname.get("Team List"),
							elelocators.get("Team List") + "[" + i + "]/div");
					/*
					 * List<WebElement> element1 = NewAutomation.getDriver().findElements(
					 * By.xpath("//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div" + "[" + i
					 * + "]/div"));
					 */
					for (int j = 1; j <= element1.size(); j++) {
						try {

							String Result = sel.getText(controlname.get("Team List"), "xpath",
									elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/img");

							System.out.println(Result + "---->" + NameSrc);
							if (Result.contains(NameSrc)) {
								// JuniorList.add(Result);

							}
						}

						catch (Exception ex) {

						}
					}

				}
			}

		}
	}
}