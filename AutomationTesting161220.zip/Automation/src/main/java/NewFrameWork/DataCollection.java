package NewFrameWork;

/***
 * @author Sathish Kumar C.B
 * Description : Created to collect data from External Source (Excel) 
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class DataCollection {

	HashMap<String, String> eleRepHM;
	HashMap<String, String> controlnameHM;
	Sheet sheet;
	Workbook wb;

	/** Constructor **/

	public DataCollection() {
		System.out.println("**** Data Collection ****");
		this.eleRepHM = new HashMap<>();
		this.controlnameHM = new HashMap<>();
	}

	/**
	 * This method retrieves the path
	 */

	/**
	 * @return Properties
	 */

	public Properties getBrowserPath() {
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("Appconfig.properties")));
		} catch (FileNotFoundException fe) {
			try {
				prop.load(this.getClass().getClassLoader().getResourceAsStream("Appconfig.properties"));
				prop.store(new FileOutputStream(new File("Appconfig.properties")), "Appconfig Properties");
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prop;
	}

	/**
	 * This method reads an excel and returns the values(element id & locator) in a
	 * Hashmap
	 */

	/**
	 * @param filename
	 * @param sheetname
	 * @return hashmap
	 */

	public HashMap<String, String> getEleRep(String filepath, String sheetname) {
		try {
			wb = Workbook.getWorkbook(new File(filepath));
			sheet = wb.getSheet(sheetname);
			for (int row = 1; row < sheet.getRows(); row++) {
				eleRepHM.put(sheet.getCell(0, row).getContents(), sheet.getCell(1, row).getContents());
			}
		} catch (Exception e) {
			System.out.println("Error  :" + e);
		} finally {
			wb.close();
		}
		return eleRepHM;
	}

	/**
	 * This method reads an excel and returns the values((element id & control
	 * name)) in a Hashmap
	 */

	/**
	 * @param filename
	 * @param sheetname
	 * @return hashmap
	 */

	public HashMap<String, String> getControlname(String filepath, String sheetname) {
		try {
			wb = Workbook.getWorkbook(new File(filepath));
			sheet = wb.getSheet(sheetname);
			for (int row = 1; row < sheet.getRows(); row++) {
				controlnameHM.put(sheet.getCell(0, row).getContents(), sheet.getCell(2, row).getContents());
			}
		} catch (IOException | BiffException e) {
			System.out.println("Error  :" + e);
		} finally {
			wb.close();
		}
		return controlnameHM;
	}
}
