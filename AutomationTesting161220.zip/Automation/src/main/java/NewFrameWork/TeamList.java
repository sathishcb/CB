package NewFrameWork;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.pack.preserve.ListExcel;

import commonFuncation.DataCollection;
import commonFuncation.SelWebDriverMethods;

public class TeamList {
	String readexcel = "C:\\Users\\Tester-Sathishkumar\\Desktop\\WalkexXpath.xls";
	SelWebDriverMethods sel = new SelWebDriverMethods();
	DataCollection DC = new DataCollection();
	HashMap<String, String> elelocators = DC.getEleRep(readexcel, "Grootan");
	HashMap<String, String> controlname = DC.getControlname(readexcel, "Grootan");

	@Test
	public void Team() {

		String ScreenMenu;
		List<WebElement> lis = sel.getList(controlname.get("List Menu"), elelocators.get("List Menu"));
		for (int i = 1; i <= lis.size(); i++) {
			ScreenMenu = sel.getText(controlname.get("List Menu"), "xpath",
					elelocators.get("List Menu") + "[" + i + "]");
			String result = sel.assertequalandwriteresult(ScreenMenu, "Team");
			if (result == "Pass") {
				sel.Waituntilvisibility(controlname.get("List Menu"), "xpath",
						elelocators.get("List Menu") + "[" + i + "]", "");
				sel.seleniumAction(controlname.get("List Menu"), "Click", "xpath",
						elelocators.get("List Menu") + "[" + i + "]", "");

			}
			/*
			 * File screenshotFile = ((TakesScreenshot)
			 * NewAutomation.getDriver()).getScreenshotAs(OutputType.FILE);
			 * FileUtils.copyFile(screenshotFile, new File(file.toString() +
			 * "\\" + ScreenMenu + ".png")); sel.seleniumAction(controlname.get("Logo"),
			 * "Click", "xpath", elelocators.get("Logo"), "");
			 */

		}
		ArrayList<String> JuniorList = new ArrayList<String>();
		List<WebElement> element = sel.getList(controlname.get("Team List"), elelocators.get("Team List"));

		for (int i = 1; i <= element.size(); i++) {
			List<WebElement> element1 = sel.getList(controlname.get("Team List"),
					elelocators.get("Team List") + "[" + i + "]/div");
			/*
			 * List<WebElement> element1 = NewAutomation.getDriver().findElements(
			 * By.xpath("//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div" + "[" + i
			 * + "]/div"));
			 */
			for (int j = 1; j <= element1.size(); j++) {
				try {

					String Result = sel.getText(controlname.get("Team List"), "xpath",
							elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/h3");
					String ProfResult = sel.getText(controlname.get("Team List"), "xpath",
							elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/h5");
					/*
					 * WebElement Name = NewAutomation.getDriver() .findElement(By.xpath(
					 * "//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div" + "[" + i +
					 * "]/div" + "[" + j + "]/h3")); WebElement Prof = NewAutomation.getDriver()
					 * .findElement(By.xpath(
					 * "//*[@id=\"root\"]/div/section[2]/div/div/div/div/div/div" + "[" + i +
					 * "]/div" + "[" + j + "]/h5"));
					 */
					boolean check = sel.verifyelementdisplayed(controlname.get("Team List"), "xpath",
							elelocators.get("Team List") + "[" + i + "]/div" + "[" + j + "]/h3");

					if (check == true) {

						System.out.println(Result + "---->" + ProfResult);
						if (ProfResult.contains("Junior")) {
							JuniorList.add(Result);

						}
					}
				}

				catch (Exception ex) {

				}
			}

		}
		System.out.println(JuniorList.toString());
		ListExcel liss = new ListExcel();
		liss.ListData(JuniorList, "ResultReport", "Junior Engineers");

	}
}
