package api;

import java.io.File;
import java.io.FileInputStream;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import jxl.Sheet;
import jxl.Workbook;

public class WalkexApi {
	
	String otp = null;

	@Test
	public String getOtp() {
		try {
			String filePath = "C:\\Users\\Tester-Sathishkumar\\Desktop\\Data.xls";
			String sheets = "OTP";
			FileInputStream file = new FileInputStream(new File(filePath));
			Workbook w;
			w = Workbook.getWorkbook(file);
			Sheet sheet = w.getSheet(sheets);

			for (int j = 1; j < sheet.getRows(); j++) {
				String url = sheet.getCell(1, j).getContents();
				String username = sheet.getCell(2, j).getContents();
				RestAssured.baseURI = url;
				RequestSpecification httpRequest = RestAssured.given();
				Response response = httpRequest.get(username);
				RequestSpecification request = RestAssured.given();
				request.header("Content-Type", "application/json");
				System.out.println(response.contentType());
				ResponseBody responseBody = response.getBody();
				JsonPath name = responseBody.jsonPath();
				otp = name.getString("mail_otp");
				System.out.println(otp);
				System.out.println("Response Body is: " + responseBody.asString());
			}
		} catch (Exception ex) {

		}
		return otp;
	}

}
